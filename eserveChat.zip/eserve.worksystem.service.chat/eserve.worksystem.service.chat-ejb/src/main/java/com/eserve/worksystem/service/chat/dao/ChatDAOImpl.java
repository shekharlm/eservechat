package com.eserve.worksystem.service.chat.dao;

import java.io.Serializable;
import java.sql.SQLException;

import javax.ejb.LocalBean;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.eserve.marketplace.common.entity.TempCompanyChatSettings;
import com.eserve.marketplace.common.exception.NotFoundException;
import com.eserve.marketplace.common.persistenceservice.AbsPersistenceService;

/**
 * Session Bean implementation class ChatDAOImpl
 */
@Stateless
@Remote
public class ChatDAOImpl extends AbsPersistenceService<Serializable> implements IChatDAO{
	
	EntityManager entityManager;
	
	/**
	 * Default constructor.
	 */
	public ChatDAOImpl() {

	}

	/**
	 * This method retrieves the Chat Settings for a company.
	 * 
	 * @param iCompanyId -- The company Id
	 * @return Returns an object of {@link TempCompanyChatSettings} 
	 * @throws NotFoundException Incase the Company Chat Settings are not found
	 */
	@Override
	public TempCompanyChatSettings getCompanyChatSetting(int iCompanyId) throws NotFoundException {
		entityManager=getEntityManager();
		Query settingsQuery = null;
		TempCompanyChatSettings chatSettings = null;
		try{
			settingsQuery = entityManager.createQuery("from TempCompanyChatSettings t where t.companyId=:companyId");
			settingsQuery.setParameter("companyId", iCompanyId);
			chatSettings = (TempCompanyChatSettings) settingsQuery.getSingleResult();
			return chatSettings;					
		}catch(Exception e){
			throw new NotFoundException();
		}
	}

}