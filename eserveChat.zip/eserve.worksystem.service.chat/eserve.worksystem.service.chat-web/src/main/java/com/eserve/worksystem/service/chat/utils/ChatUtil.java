package com.eserve.worksystem.service.chat.utils;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.eserve.worksystem.service.chat.dao.IChatDAO;

public class ChatUtil {
	
	
	private static IChatDAO chatDAO;
	

	public static IChatDAO getChatDao() throws NamingException{
/*		 Properties properties=new Properties();
		properties.put("java.naming.factory.initial",
	                "org.jnp.interfaces.NamingContextFactory");
	            properties.put("java.naming.factory.url.pkgs",
	                "org.jboss.naming rg.jnp.interfaces");
	            properties.put("java.naming.provider.url", "jnp://localhost:1099");		
	    
	    Context ctx = new InitialContext(properties);*/	   
		Context ctx=new InitialContext();
		chatDAO=(IChatDAO) ctx.lookup("java:app/eserve.worksystem.service.chat-ejb-0.0.1-SNAPSHOT/ChatDAOImpl");
		System.out.println(chatDAO);
		return chatDAO;
	}
}
