package com.eserve.worksystem.service.chat.rest;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

import com.eserve.worksystem.service.chat.utillityobjects.BroadcastContent;
import com.eserve.worksystem.service.chat.utillityobjects.Data;

public interface IChatServices {
	
	/**
	 * This rest API should be used to send messaged in the Chat Module
	 * 
	 * @param data - The Outgoing data that will be sent as a message
	 * @return - The response status of this Method
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	@POST
	@Path("/chat")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response chat(BroadcastContent<?> data);

	/**
	 * 
	 * @param data
	 * @return
	 */
	@POST
	@Path("/toggle")
	public Response toggle(String data);

	public void notifySubscribersGroup(Object notificationData, String groupId);

	/**
	 * This Rest API method should be used to retrieve the chat setting information about a company.
	 * 
	 * @param strCompanyID -- The comoany ID of the company
	 * @return -- Response which includes  @see CompanyChatTemplate object
	 */
	@Path("/company/{companyID}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCompanyInformation(@PathParam(value = "companyID") String strCompanyID);
	
	
	/**
	 * This rest API should be used to get a Random Unique Identifier
	 * @return Respone in HTML_TEXT with the Unique Identifier
	 */
	@Path("/session")
	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response getChatSessionID();
	
}
