package com.eserve.worksystem.service.chat.manager;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Default;
import javax.inject.Inject;
import javax.naming.NamingException;
import javax.ws.rs.core.MediaType;

import org.jboss.resteasy.client.ClientRequest;
import org.jboss.resteasy.client.ClientResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eserve.marketplace.common.entity.TempCompanyChatSettings;
import com.eserve.marketplace.common.exception.NotFoundException;
import com.eserve.worksystem.service.chat.dao.IChatDAO;
import com.eserve.worksystem.service.chat.temp.data.CompanyChatSettingInformation;
import com.eserve.worksystem.service.chat.temp.data.CompanyChatTemplate;
import com.eserve.worksystem.service.chat.utillityobjects.BroadcastContent;
import com.eserve.worksystem.service.chat.utils.ChatTopicProducer;
import com.eserve.worksystem.service.chat.utils.ChatUtil;

@Stateless
@LocalBean
public class ChatManagerImpl implements IChatManager {
	
	private @EJB IChatDAO chatDAO;
	private static Logger logger=LoggerFactory.getLogger(ChatTopicProducer.class);
	
	public ChatManagerImpl() throws NamingException {
//		chatDAO=ChatUtil.getChatDao();
	}
	
	/**
	 *  This method should be used to retrieve the CompanyChatSettings information
	 * @param strCompanyID
	 * @return
	 * @throws NotFoundException 
	 * @throws NumberFormatException 
	 */
	@Override	
	public CompanyChatSettingInformation getCompanyChatSettings(String strCompanyID) throws NumberFormatException, NotFoundException {
		//Retrieve the Temporary Chat Settings for the company
		TempCompanyChatSettings tempCompanyChatSettings=chatDAO.getCompanyChatSetting(Integer.parseInt(strCompanyID));
		CompanyChatSettingInformation chatSettingInformation=new CompanyChatSettingInformation(tempCompanyChatSettings.getCompanyId()	, tempCompanyChatSettings.getTimeZone(), tempCompanyChatSettings.getCompanyStartWorkHours(), tempCompanyChatSettings.getCompanyEndWorkHours());
		return chatSettingInformation; 
	}

	/**
	 * This method verifies whether the current hour falls within the workin hours of the company Id  
	 * @param strCompanyID -- The company Id
	 * @return -- Whether the request has been sent within the wotking hours.
	 * @throws NotFoundException 
	 * @throws NumberFormatException 
	 */
	@Override
	public boolean verifyWorkingHours(final String strCompanyID) throws NumberFormatException, NotFoundException {
		//Make a repository call to retrieve the company settings details
		//Following is a mock to retrieve the company information
		CompanyChatSettingInformation companyDataSet=getCompanyChatSettings(strCompanyID);
		
		//Generating company working hours according ti the time zone.
		Calendar companyTimeZoneTime=new GregorianCalendar(TimeZone.getTimeZone(companyDataSet.getStrTimeZone()));
		int currentTimeZoneHour=companyTimeZoneTime.get(Calendar.HOUR)+1;
		
		//Verifying the working hours
		return ((currentTimeZoneHour >= companyDataSet.getiCompanyWorkStartHour())  && (currentTimeZoneHour < companyDataSet.getiCompanyWorkEndHours()));
	}

	/**
	 * This returns the companyChatTemplate
	 * @param strCompanyID
	 * @return
	 */
	@Override
	public CompanyChatTemplate provideCompanyChatTemplate(String strCompanyID) {		
		CompanyChatTemplate  companyInformation=null;
		//Mock Template Information
		if(strCompanyID.equalsIgnoreCase("1")){
			companyInformation=new CompanyChatTemplate();
			companyInformation.setFlgCanProcessRequest(true);
			companyInformation.setStrBackGround("Pink");
		}else if(strCompanyID.equalsIgnoreCase("2")){
			companyInformation=new CompanyChatTemplate();
			companyInformation.setFlgCanProcessRequest(true);
			companyInformation.setStrBackGround("Blue");			
		}else if(strCompanyID.equalsIgnoreCase("3")){
			companyInformation=new CompanyChatTemplate();
			companyInformation.setFlgCanProcessRequest(true);
			companyInformation.setStrBackGround("Yellow");			
		}else{
			companyInformation=new CompanyChatTemplate();
			companyInformation.setFlgCanProcessRequest(true);
			companyInformation.setStrBackGround("default");						
		}		
		return companyInformation;
	}

	@Override
	public void sendNotificationToAgent(BroadcastContent<?> data) {
        System.out.println("Calling notification API");
        ClientRequest request=new ClientRequest("http://localhost:8080/notificationresttest/rest/notification/subscribe");
        System.out.println("Calling notification API");
        request.body(MediaType.APPLICATION_JSON, data);
        System.out.println("Calling notification API");
		try {
	        request.post(BroadcastContent.class);
	    } catch (Exception e) {
			e.printStackTrace();
		}
	}

}
