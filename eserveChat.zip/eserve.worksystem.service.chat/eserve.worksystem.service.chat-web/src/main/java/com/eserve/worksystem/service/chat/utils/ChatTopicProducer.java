package com.eserve.worksystem.service.chat.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.naming.Context;
import javax.naming.NamingException;

import org.hornetq.api.core.TransportConfiguration;
import org.hornetq.core.remoting.impl.netty.NettyConnectorFactory;
import org.hornetq.integration.transports.netty.TransportConstants;
import org.hornetq.jms.client.HornetQConnectionFactory;
import org.hornetq.jms.client.HornetQTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ChatTopicProducer implements Cloneable{

private static Logger logger=LoggerFactory.getLogger(ChatTopicProducer.class);
private static Properties properties=null;
private final String strTopicName,strHornetQPort,strHornetQServer;
private Context context=null;
private Connection connection = null;
private Session session = null;
private Topic topic =null;
private MessageProducer sender =null;
private static ChatTopicProducer chatTopicUtil;

	static{
		if(properties==null){
				properties=new Properties();
				try {
					properties.load(ChatTopicProducer.class.getClassLoader().getResourceAsStream("CHAT_TOPIC_CONFIG.properties"));
				} catch (IOException e) {
					e.printStackTrace();
					logger.error(e.toString());
				}			
		}
	}
    
	/**
	 * 
	 * @throws JMSException
	 * @throws NamingException
	 */
	private ChatTopicProducer() throws JMSException, NamingException{
		    //Fetching the configuration parameters from property file
			strTopicName=properties.getProperty("TOPIC_NAME");
			strHornetQPort=properties.getProperty("HORNETQ_SERVER_PORT");
			strHornetQServer=properties.getProperty("HORNETQ_SERVER_IP");
			
			//Cerating the connection to the Standalone HornetQ Server
			Map<String, Object> connectionParams = new HashMap<String, Object>();
			connectionParams.put(TransportConstants.PORT_PROP_NAME, Integer.parseInt(strHornetQPort));
			connectionParams.put(TransportConstants.HOST_PROP_NAME, strHornetQServer);

			//Creates a transport configuration using the nettyconnector factory and the connection parameters
			TransportConfiguration transportConfiguration = new TransportConfiguration(
					NettyConnectorFactory.class.getName(), connectionParams);

			 
			if(transportConfiguration!=null){
				connection =  new HornetQConnectionFactory(false, transportConfiguration).createConnection();
				connection.start();
				session =connection.createSession(false,QueueSession.AUTO_ACKNOWLEDGE);
				topic = new HornetQTopic(strTopicName);
				sender = session.createProducer(topic);
		}
	}
	
	/**
	 * This method publishes the incoming message as a Text message to the Chat Topic
	 * @param strMessage
	 * @return
	 * @throws JMSException
	 */
	public boolean publishTextMessageToTopic(String strMessage) throws JMSException{
		TextMessage textMessage = session.createTextMessage();
		textMessage.setText(strMessage);
		sender.send(textMessage);
		return true;		
	}
		
	/**
	 * Factory Static method which creates and returns only one instance of this class.
	 *  
	 * @return
	 * @throws JMSException
	 * @throws NamingException
	 */
	public static ChatTopicProducer createChatTopicUtil() throws JMSException, NamingException{
		if(chatTopicUtil==null){
			chatTopicUtil=new ChatTopicProducer();
		}
		return chatTopicUtil;		
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("This class cannot be Cloned");
	}
	
}
