package com.eserve.worksystem.service.chat.handler;

import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.atmosphere.cache.UUIDBroadcasterCache;
import org.atmosphere.cpr.ApplicationConfig;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.AtmosphereResourceEvent;
import org.atmosphere.cpr.AtmosphereResourceEventListener;
import org.atmosphere.cpr.Broadcaster;
import org.atmosphere.cpr.BroadcasterCache;
import org.atmosphere.cpr.BroadcasterFactory;
import org.atmosphere.cpr.BroadcasterLifeCyclePolicyListener;
import org.atmosphere.cpr.BroadcasterListener;
import org.atmosphere.cpr.HeaderConfig;
import org.atmosphere.handler.AbstractReflectorAtmosphereHandler;
import org.atmosphere.websocket.WebSocketEventListenerAdapter;

public class EserveChatAtmosphereHandler extends AbstractReflectorAtmosphereHandler {

	/**
	 * This method is called whenever a new request is sent to this Atmosphere handler.
	 * 
	 * This method accepts a CHAT_SESSION_ID and creates and/or looksup for a broadcaster associated with this handler.
	 */
	@Override
	public void onRequest(AtmosphereResource atmosphereResource) throws IOException {
		
		HttpServletRequest req = atmosphereResource.getRequest();
		HttpServletResponse res = atmosphereResource.getResponse();
		String method = req.getMethod();
		String strChatSessionId = req.getParameter("subscriberId");

		//Looking up for a broadcaster
		Broadcaster b=lookupBroadcaster(strChatSessionId);
		
		//adding the Atmosphere resource to the broadcaster
		atmosphereResource.setBroadcaster(b);
	
//		 Suspend the response.
		if ("GET".equalsIgnoreCase(method)) {
			// Log all events on the console, including WebSocket events.
			atmosphereResource.addEventListener(new AtmosphereResourceEventListener() {				
				@Override
				public void onThrowable(AtmosphereResourceEvent event) {
				}
				@Override
				public void onSuspend(AtmosphereResourceEvent event) {
				}
				@Override
				public void onResume(AtmosphereResourceEvent event) {
				}
				@Override
				public void onDisconnect(AtmosphereResourceEvent event) {
				}
				@Override
				public void onBroadcast(AtmosphereResourceEvent event) {
				}
			});
			res.setContentType("text/html;charset=ISO-8859-1");
			if (b != null) {
				b.addBroadcasterListener(new BroadcasterListener() {
					@Override
					public void onPreDestroy(Broadcaster b) {
					}
					@Override
					public void onPostCreate(Broadcaster b) {
					}
					@Override
					public void onComplete(Broadcaster b) {
						//b.destroy();
					}
				});
				b.addBroadcasterLifeCyclePolicyListener(new BroadcasterLifeCyclePolicyListener() {
					@Override
					public void onIdle() {
					}
					@Override
					public void onEmpty() {
					}
					@Override
					public void onDestroy() {
					}
				});
			}
			String atmoTransport = req.getHeader(HeaderConfig.X_ATMOSPHERE_TRANSPORT);

			if (atmoTransport != null
					&& !atmoTransport.isEmpty()
					&& atmoTransport.equalsIgnoreCase(HeaderConfig.LONG_POLLING_TRANSPORT)) {
				req.setAttribute(ApplicationConfig.RESUME_ON_BROADCAST, Boolean.TRUE);
				atmosphereResource.resumeOnBroadcast(true);
				atmosphereResource.getBroadcaster().getBroadcasterConfig().setBroadcasterCache(new UUIDBroadcasterCache());
				atmosphereResource.suspend(-1,false);
			}
			else {
				atmosphereResource.suspend(-1);
			}
		}
	}
	@Override
	public void destroy() {
	}

	/**
	 * This 
	 */
	@Override
	public void onStateChange(AtmosphereResourceEvent event)
	            throws IOException {
		super.onStateChange(event);
		@SuppressWarnings("unchecked")
		List<Object> cachedMessages = (List<Object>) event.getMessage();
	}
	
	/**
	 * Looks up for an existing broadcaster
	 * @param strChatSessionId --  The CHAT_SESSION_ID which will be used to lookup the broadcaster
	 */
	private Broadcaster lookupBroadcaster(String strChatSessionId) {
		Broadcaster b = null;
		b = BroadcasterFactory.getDefault().lookup(strChatSessionId,true);
		return b;
	}
}
