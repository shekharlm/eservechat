package com.eserve.worksystem.service.chat.temp.data;

/**
 * This class should be used as a data transfer object to transfer data from the repository view.
 *  
 * @author Ariveguru
 *
 */
public class CompanyChatSettingInformation {
	
	/**
	 * The company Id
	 */
	private int iCompanyID;
	
	/**
	 * The timezone selected by the company
	 */
	private String strTimeZone;
	
	/**
	 * The Start working hours.
	 */
	private int iCompanyWorkStartHour;
	
	/**
	 * The end working hours
	 */
	private int iCompanyWorkEndHours;
	
	public int getiCompanyID() {
		return iCompanyID;
	}
	
	
	
	public CompanyChatSettingInformation(int iCompanyID, String strTimeZone,
			int iCompanyWorkStartHour, int iCompanyWorkEndHours) {
		super();
		this.iCompanyID = iCompanyID;
		this.strTimeZone = strTimeZone;
		this.iCompanyWorkStartHour = iCompanyWorkStartHour;
		this.iCompanyWorkEndHours = iCompanyWorkEndHours;
	}



	public void setiCompanyID(int iCompanyID) {
		this.iCompanyID = iCompanyID;
	}
	
	public String getStrTimeZone() {
		return strTimeZone;
	}
	
	public void setStrTimeZone(String strTimeZone) {
		this.strTimeZone = strTimeZone;
	}
	
	public int getiCompanyWorkStartHour() {
		return iCompanyWorkStartHour;
	}
	
	public void setiCompanyWorkStartHour(int iCompanyWorkStartHour) {
		this.iCompanyWorkStartHour = iCompanyWorkStartHour;
	}
	
	public int getiCompanyWorkEndHours() {
		return iCompanyWorkEndHours;
	}
	
	public void setiCompanyWorkEndHours(int iCompanyWorkEndHours) {
		this.iCompanyWorkEndHours = iCompanyWorkEndHours;
	}
	
}
