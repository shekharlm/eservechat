package com.eserve.worksystem.service.chat.utils;

public interface IChatListener {

	public void  notifySubscribers(String strMessage, String subscriberId);
}
