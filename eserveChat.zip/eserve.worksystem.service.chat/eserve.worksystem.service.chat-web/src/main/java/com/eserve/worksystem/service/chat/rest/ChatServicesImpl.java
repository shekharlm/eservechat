package com.eserve.worksystem.service.chat.rest;

import java.util.Date;
import java.util.UUID;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.atmosphere.cpr.MetaBroadcaster;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eserve.marketplace.common.exception.NotFoundException;
import com.eserve.marketplace.common.util.JsonUtils;
import com.eserve.worksystem.service.chat.manager.IChatManager;
import com.eserve.worksystem.service.chat.temp.data.CompanyChatSettingInformation;
import com.eserve.worksystem.service.chat.temp.data.CompanyChatTemplate;
import com.eserve.worksystem.service.chat.utillityobjects.BroadcastContent;
import com.eserve.worksystem.service.chat.utillityobjects.Data;
import com.eserve.worksystem.service.chat.utils.ChatTopicProducer;

/**
 * 
 * @author Ariveguru
 *
 */
@Path("/subscribe")
@Stateless
@LocalBean
public class ChatServicesImpl implements IChatServices {

	private @Context
	HttpServletRequest request;
	
	private @Inject IChatManager chatManager;
	private ChatTopicProducer chatTopicUtil;
	private static Logger logger;
	
	static{
		logger=LoggerFactory.getLogger(ChatServicesImpl.class);
	}


	@SuppressWarnings("unchecked")
	public Response chat(BroadcastContent broadcastContent) {
		Data data = null;
		String strChatSessionId = broadcastContent.getSubscriberId();
		data = new ObjectMapper().convertValue(broadcastContent.getMessage(), Data.class);
		data.setTimeStamp(new Date().getTime());

		//Checking the type of requests for an agent request
		if (broadcastContent.getMessageType().equals("agent:request")) {
//						
//			//If an agent request message is being sent
//			strChatSessionId = "agents";
			broadcastContent.setMessage(data);
			
			//This is required for the Notifications API
			broadcastContent.setAgentSupId(broadcastContent.getSubscriberId());
			
			//notifying to the agents group is sent
			notifySubscribersGroup(broadcastContent, strChatSessionId);
//			The below code will broadcast the notification 
//			chatManager.sendNotificationToAgent(broadcastContent);
			return Response.status(Response.Status.OK).build();
		} else {
			
			strChatSessionId = data.getChatId();
			if (broadcastContent.getGroupId() != null) {
				strChatSessionId = "/" + broadcastContent.getGroupId() + "/"
						+ strChatSessionId;
			}
			broadcastContent.setMessage(data);
			try {				
				notifySubscribers(broadcastContent, strChatSessionId);
				return Response.status(Response.Status.OK).build();
				
			} catch (JMSException  e) {				
				logger.debug("Exception thrown while notifying broadcaster:  {}",e.toString());
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
				
			}catch(NamingException e1){
				logger.debug("Exception thrown while notifying broadcaster:  {}",e1.toString());
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
				
			}
		}
	}

	
	/**
	 * This method should be used to publish chat message
	 * 
	 * @param notificationData -- The incoming data which will be sent as a message.
	 * @param strChatSessionId -- The subscriberId
	 * @throws JMSException 
	 * @throws NamingException 
	 */
	private void notifySubscribers(Object notificationData, String strChatSessionId) throws JMSException, NamingException {
		    String strMessage=JsonUtils.toJson(notificationData);
			chatTopicUtil=ChatTopicProducer.createChatTopicUtil();
			chatTopicUtil.publishTextMessageToTopic(strMessage);
			logger.info("Messaged Published to Topic");
//		Broadcaster broadcaster = BroadcasterFactory.getDefault().lookup(
//				subscriberId, false);
//		if (broadcaster != null){
//			broadcaster.broadcast(strMessage);			
//		}
	}

	public void notifySubscribersGroup(Object notificationData, String groupId) {
		MetaBroadcaster.getDefault().broadcastTo("/" + groupId + "/*",
				JsonUtils.toJson(notificationData));
	}

	public Data getMessage() {
		return new Data();
	}

	public Response toggle(String data) {
		try {
			notifySubscribers(data, "subscribe");
		} catch (JMSException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return Response.ok().build();
	}

	
	public Response getCompanyInformation(@PathParam(value = "companyID") String strCompanyID) {
		/*
		 * The following information will be used to verify that the request is
		 * originated from a valid Host Makes a call to the Security API
		 */
		String strRemoteAddress = request.getRemoteAddr();
		String strRemoteHost = request.getRemoteHost();

		// Make a call to a Security API to ensure that the Chat request has
		// been originated from an eServe Client (Currently Setting it to true)
		boolean flgVerifyRequest = true;

		if (!flgVerifyRequest) {
			return Response.status(Response.Status.UNAUTHORIZED).build();
		}

/* The below code is being handled thru Injection and will be deleted while commiting	
 * 	try {
			chatManager = new ChatManagerImpl();
		} catch (NamingException e) {
			logger.debug("Error while creating ChatManagerImpl: {]",e.toString());
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
*/
		// Retrieving the Company Settings information
		try {
			CompanyChatSettingInformation companyDataSet = chatManager.getCompanyChatSettings(strCompanyID);
		} catch (NumberFormatException e) {
			return Response.status(Response.Status.BAD_REQUEST).build();			
		} catch (NotFoundException e) {
			return Response.status(Response.Status.BAD_REQUEST).build();			
		}

		// Verifying the company working hours
		boolean flgWithinWorkingHours=false;
		try {
			flgWithinWorkingHours = chatManager.verifyWorkingHours(strCompanyID);
		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).build();			
		} 

		// Call to retrieve the ChatTemplateInformation
		CompanyChatTemplate companyInformation = chatManager
				.provideCompanyChatTemplate(strCompanyID);

		if (!flgWithinWorkingHours) {
			companyInformation.setFlgCanProcessRequest(false);
			return Response.status(Response.Status.OK).entity(companyInformation).build();
		}else{
			// Create a Response with the created CompanyInformation
			companyInformation.setFlgCanProcessRequest(true);
			return Response.status(Response.Status.OK).entity(companyInformation)
					.build();			
		}
	}
	
	public Response getChatSessionID() {
		//Generating a new UUID number
		StringBuilder stbUCBID=new StringBuilder("UBCID").append(UUID.randomUUID().toString());
		return Response.status(Response.Status.OK).entity(stbUCBID.toString()).build();
	}

}