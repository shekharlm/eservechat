package com.eserve.worksystem.service.chat.mdb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.atmosphere.cpr.Broadcaster;
import org.atmosphere.cpr.BroadcasterFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.eserve.marketplace.common.util.JsonUtils;
import com.eserve.worksystem.service.chat.utillityobjects.BroadcastContent;
import com.eserve.worksystem.service.chat.utils.IChatListener;


/**
 * Message-Driven Bean implementation class for: ChatStatusTopic
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "chatStatusTopic"),
		@ActivationConfigProperty(propertyName = "reconnectAttempts", propertyValue = "-1")})
public class ChatStatusTopic implements MessageListener {

	@Inject IChatListener chatBroadcast;
	
	private static Logger logger=LoggerFactory.getLogger(ChatStatusTopic.class);

	/**
	 * Default constructor.
	 */
	public ChatStatusTopic() {
	}

	/**
	 * @see MessageListener#onMessage(Message)
	 */
	public void onMessage(Message message){
		TextMessage textMessage=(TextMessage) message;
        try {
			logger.info("Message Recieved: {}"+textMessage.getText());
			BroadcastContent broadcastContent=JsonUtils.fromJson(textMessage.getText(), BroadcastContent.class);
		    chatBroadcast.notifySubscribers(textMessage.getText(), broadcastContent.getSubscriberId());
		} catch (JMSException e1) {
			e1.printStackTrace();
			logger.debug(e1.toString());
		}
                
	}
	
}