package com.eserve.worksystem.service.chat.manager;

import com.eserve.marketplace.common.exception.NotFoundException;
import com.eserve.worksystem.service.chat.temp.data.CompanyChatSettingInformation;
import com.eserve.worksystem.service.chat.temp.data.CompanyChatTemplate;
import com.eserve.worksystem.service.chat.utillityobjects.BroadcastContent;

public interface IChatManager {

	/**
	 *  This method should be used to retrieve the CompanyChatSettings information
	 * @param strCompanyID
	 * @return
	 * @throws NotFoundException 
	 * @throws NumberFormatException 
	 */
	public CompanyChatSettingInformation getCompanyChatSettings(final String strCompanyID) throws NumberFormatException, NotFoundException;
	
	/**
	 * This method verifies whether the current hour falls within the workin hours of the company Id  
	 * @param strCompanyID -- The company Id
	 * @return -- Whether the request has been sent within the wotking hours.
	 * @throws NotFoundException 
	 * @throws NumberFormatException 
	 */
	public boolean verifyWorkingHours(final String strCompanyID) throws NumberFormatException, NotFoundException;
	
	/**
	 * This returns the companyChatTemplate
	 * @param strCompanyID
	 * @return
	 */
	public CompanyChatTemplate provideCompanyChatTemplate(final String strCompanyID);
	
	public void sendNotificationToAgent(BroadcastContent<?> data);
		
}
