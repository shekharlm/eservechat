package com.eserve.worksystem.service.chat.temp.data;

public class CompanyChatTemplate {
private String strBackGround;
private boolean flgCanProcessRequest;

public String getStrBackGround() {
	return strBackGround;
}

public void setStrBackGround(String strBackGround) {
	this.strBackGround = strBackGround;
}

public boolean isFlgCanProcessRequest() {
	return flgCanProcessRequest;
}

public void setFlgCanProcessRequest(boolean flgCanProcessRequest) {
	this.flgCanProcessRequest = flgCanProcessRequest;
}

}
