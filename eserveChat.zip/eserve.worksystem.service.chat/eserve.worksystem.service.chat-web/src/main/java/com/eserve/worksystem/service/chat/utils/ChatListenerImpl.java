package com.eserve.worksystem.service.chat.utils;

import org.atmosphere.cpr.Broadcaster;
import org.atmosphere.cpr.BroadcasterFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChatListenerImpl implements IChatListener {

	Logger logger = LoggerFactory.getLogger(ChatListenerImpl.class);
	@Override
	public void notifySubscribers(String strMessage, String subscriberId) {
		Broadcaster broadcaster = BroadcasterFactory.getDefault().lookup(subscriberId, false);
		if (broadcaster != null){
			broadcaster.broadcast(strMessage);			
		}
	}

}
