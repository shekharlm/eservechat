
	
	 var options = {
				
	    onFail: function() {
			for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
			{
				 $($myform.getInvalid()[errlen]).addClass('invalid')
				 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
			}
	    },
	    onSuccess: function() {
			$('#signupsubmit').trigger('click');
	    },
	
	    inputs: {
	      'password': {
	        filters: 'required password',
	      },
	      'username': {
	        filters: 'required username',
	        data: {
	         
	        }
	      },
	      'file': {
	        filters: 'extension',
	        data: { extension: ['jpg'] }
	      },
	
	      'comments': {
	        filters: 'min max',
	        data: { min: 50, max: 200 }
	      },
	      'country': {
	        filters: 'exclude',
	        data: { exclude: ['default'] },
	        errors : {
	          exclude: 'Select a Country.'
	        }
	      },
	      'langs[]': {
	        filters: 'min max',
	        data: { min: 1, max: 1 },
	        errors: {
	          min: 'Please Accept the term and condition.',
	          max: 'Please Accept the term and condition.'
	        }
	      }
	    }
	  };
	
	  var $myform = $('#my-form').idealforms(options).data('idealforms');