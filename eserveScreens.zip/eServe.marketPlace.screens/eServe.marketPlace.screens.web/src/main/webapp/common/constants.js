var SUCCESS = "success"; // Ajax Response Success
var FAIL = "fail"; // Ajax Response Failure
var FAILED = "failed"; // Ajax Response Failure
var RESENT = "resent"; // REsent the activation link to email id
var ACTIVE = "active"; // Account Active
var INACTIVE = "inactive"; //Account Status inactive
var LOCKED = "locked"; // Account Status whether account is active (or) locked etc..
var BLOCKED = "blocked"; // Eserve admin blocked the account
var ACCOUNTTYPEPROVIDERID = "1"; // Account Type Selection
var ACCOUNTTYPEPROVIDERBUSINESSID = "2";
var ACCOUNTTYPEPROVIDERBUSSINESSID = "3";
var AJAXERROR = "Ajax Processing Error"; //Json structure (or) due to some other ajax execution error
var ACCEPTED = "accepted"; // Invitation Accepted Status
var NOTEXPIRED = "notexpired"; // Invitation Expired date
var EXISTS = "exists"; // Email ID Not Exists
var INVALID = "invalid"; //Email ID Not Valid
var SECURITYQUESTION = "securityquestion"; // Checking whether Security question Available or not
var CLOSED = "closed"; //Account Status'
var SELECTED1 = "selected";

function logout(){
	 $.ajax({
		 url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/logout/logoutcheck",
		 type: "GET",
		 dataType: "JSON",
		 headers: {'Content-type': 'application/json' },
		 success: function(resp) {
			 window.location = '/eServe.marketPlace.screens.web/'+'index.jsp';
		 },
		 error: function(resp){
			 error('Json Error');
		 }
	  });
}


//Dropdown select common function... Need to look in angular js

function selectOption() {
	for( var l = 0; l < $('select').length; l++ ) {
		for( var ol = 0; ol < $('select')[1].options.length; ol++ ) {
			if( $('select')[l].options[ol] != undefined )
			{
				if( $('select')[l].options[ol].getAttribute('status') != null )
				{
					if( $('select')[l].options[ol].getAttribute('status') == 0 )
					{
						$('select')[l].options[ol].selected = false;
					}else
					{
						$('select')[l].options[ol].selected = true;
					}
				}
			}
		}
	}
}
