function DialogCtrl($scope, $dialog){

  // Inlined template for demo
  var t = '<div class="modal-header">'+
          '<h3>Thanks for signing up!</h3>'+
          '</div>'+
          '<div class="modal-body">'+
          '<p>To complete your registration, Please check your mail and click the link to activate.</p>'+
          '</div>'+
          '<div class="modal-footer">'+
          '<button ng-click="Ok()" class="btn btn-success" >Ok</button>'+
          '</div>';

  $scope.opts = {
    backdrop: true,
    keyboard: true,
    backdropClick: true,
    backdropFade: true,
    dialogFade: true,
    template:  t, // OR: templateUrl: 'path/to/view.html',
    controller: 'DialogController'
  };

  $scope.openDialog = function(){
    var d = $dialog.dialog($scope.opts);
    d.open().then(function(result){
      if(result)
      {
        //alert('dialog closed with result: ' + result);
      }
    });
  };

  $scope.openMessageBox = function(){
    var title = 'This is a message box';
    var msg = 'This is the content of the message box';
    var btns = [{result:'cancel', label: 'Cancel'}, {result:'ok', label: 'OK', cssClass: 'btn-primary'}];

    $dialog.messageBox(title, msg, btns)
      .open()
      .then(function(result){
        //alert('dialog closed with result: ' + result);
    });
  };
}

// the dialog is injected in the specified controller
function DialogController($scope, dialog){
  $scope.close = function(result){
    dialog.close(result);
  };
  $scope.Ok = function(result){
	  dialog.close(result);
  };
}