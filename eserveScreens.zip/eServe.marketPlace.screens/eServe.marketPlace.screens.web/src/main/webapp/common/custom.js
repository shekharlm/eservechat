
$().ready(function() {
$().acknowledgeinput();


$('#category').change(function() {
 var value = $("#category option:selected").val();
 if(value != '')
   {
   $('#subcategory').show();
   $('#skills').show();
   }
   else
   { 
   $('#subcategory').hide();
   $('#skills').hide();
   }
});






});

$('#hourlyrate').click(function() {

   $('#hourlyratepanel').show();
   $('#setworkarrangementsfixed').hide();
  
});

$('#fixedrate').click(function() {

   $('#hourlyratepanel').hide();
   $('#setworkarrangementsfixed').show();
  
});








function countChar(val) {
        var len = val.value.length;
        if (len >= 500) {
          val.value = val.value.substring(0, 500);
        } else {
          $('#charNum').text(500 - len);
        }
      };