/*Opening a chat window based on the id*/
function openChat(response){
	 var scope = angular.element(".chat-window-overlay").scope();
	 scope.$apply(function() {
		   scope.chatInfo = response;
		   scope.chatWindow.show = true;
		   scope.activeChats.count = 1;
	    });
}

/* Add message to chat window  */

function addMessage(response) {
	 var scope = angular.element(".chat-window-overlay").scope();	
	 scope.$apply(function() {
		  
		   scope.messages.push(response.message);	
		   scope.messageStatus ={};
	    });
	 $(".chat-log").animate({ scrollTop: $(".chat-log").get(0).scrollHeight}, "slow");
}


function chatStatusMessage(response) {
	var scope = angular.element(".chat-window-overlay").scope();
	scope.$apply(function(){
		scope.messageStatus = response.message;
	});
}

function removeStatusMessage(response) {
	var scope = angular.element(".chat-window-overlay").scope();
	response.message.author.firstName = "";
	scope.$apply(function(){
		scope.messageStatus = response.message;
	});
}