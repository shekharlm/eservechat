
 
function chatStatusCtrl($scope,$http,$rootScope,chatStatusData) {
	
	$scope.activeChats= {};
	$rootScope.activeChats = 0;
	$rootScope.waitingReply = 0;
	$scope.activeChat = 0;
	$scope.activeChats = chatStatusData;
	$scope.chatWindow = {};
	$scope.chatWindow = chatStatusData
	
};


function chatCtrl($scope,$http,$rootScope,$compile) {
	
	
	$http({
  		url: "http://localhost:8080/eserve.worksystem.service.chat-web/chatservice/subscribe/company/1", 
  		method: "GET",
  		dataType:"JSON", 
  		headers: {'Content-type': 'application/json'} }).
  	    success(function (resp) {
  	    		if(resp.flgCanProcessRequest==true){
  	    			$('.chat-box-body').empty();
      	    		$('.chat-box-body').append( $compile("<div id='chat_form'>"
							+"<label style='float:left;font-size:11px;margin-left: 8px;'>Display Name</label>"
							+"<input type='text' name='' placeHolder='enter display name' style='height:30px;margin-left: 8px;' id='displayName' /><br>"
							+"<button id='submit' ng-click='post()' style='margin-left: 8px;' class='btn btn-success'>Submit</button> </div>")($scope));
      	    		
  	    		}else{
  	    			$(".chat-log").css('display','none');
      	        	$(".chat-input").css('display','none');
      	        	 $(".chat-box-body").append( $compile("<div id='chat_msg_form'>"
      	        			 +"<label style='color:red;font-size: 11px;'>No agents available at this time .Please fill the form</label>"
 							+"<label style='font-size: 11px;margin-left: 8px;'>Name:</label><input type='text' name='' placeHolder='enter name' style='height:25px;margin-left: 8px;' id='form_msg_name' /><br>"
 							+"<label style='font-size: 11px;margin-left: 8px;'>Email:</label><input type='email' name='' placeHolder='enter email' style='height:25px;margin-left: 8px;' id='form_msg_email' /><br>"
 							+"<label style='font-size: 11px;margin-left: 8px;'>Mobile:</label><input type='text' name='' placeHolder='enter mobile' style='height:25px;margin-left: 8px;' id='form_msg_mobile' /><br>"
 							+"<label style='font-size: 11px;margin-left: 8px;'>Post query:</label><textarea placeHolder='enter query' style='margin-left: 8px;'  class='ng-pristine ng-valid'></textarea><br>"
 							+"&nbsp;&nbsp<button id='form_msg_submit' ng-click='formSubmit()' class='btn btn-success'>Send</button>" +
 									"&nbsp &nbsp<button id='form_msg_callback' ng-click='callback()' class='btn btn-success'>Call back</button> </div>")($scope) );
  	    		}
  	        }).
  	        error(function(resp) {
  	        	alert("error ");
  	        	 return false;
  	        });
  	 $scope.post = function(){
  		var displayName = $('#displayName').val();
  		if(displayName.length>0){
  			$('.chat-box-body').empty();
  		//	$('.chat-name').text(displayName);
	    		/*$('.chat-box-body').append($compile("<div class='chat-log'></div>" +
	    				"<div class='chat-status-message-cont'>" +
	    				"<div class='chat-status-message'></div>" +
	    				"<img class='iconClip' src='img/icon-clip.png'/></div>"+
	    				"<div class='chat-input'><textarea class='ng-valid ng-dirty' on-focus='addStatus()' on-blur='removeStatus()' on-keyup='addStatus()' ng-model='messageText' ui-keypress='{13:'postMessage()'}></textarea></div>")($scope));
	    */		
  	 		var status = setNameText(displayName);
  	 		//alert(agentAccepted);
  	 	 	/*if(status){
  	 	 		$('.ui-widget').remove();
  	 	  		
  	 	 	}else{
  	 	 		console.log("agent not accepting.........");
  	 	 		alert("agent not accepting.........");
  	 	 	}*/
  		}else{
  			alert("please enter display name.....");
  		}
    };
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	$scope.loggedUserName = "";//localStorageService.get('loggedUserName');
	$scope.chatWindow = {};
	//$scope.chatWindow = chatStatusData;
	
	//$scope.activeChats = {};
	
    $scope.messages = [];
    $scope.authorInfo= "";
    $scope.subscriberIdGlobal = "";
    $scope.postMsg = {};
    $scope.broadcastData = {
            version : null,
            subscriberId : null,
            groupId : null,
            messageType : null,
            message : null
    };
    
   // $scope.activeChats =chatStatusData; 
   
    
    
    
    
    
    //Assigning values for posting message,
    
     
     
    
    
    
    $scope.sendMessage = function() {
      
    	$scope.post();
    	//alert($scope.messageText);
        $scope.messageText = "";
    };
    
    //Request to send message 
    
       $scope.postMessage = function() {
    	     
    	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
    	 $scope.postMsg.messageTxt = $scope.messageText;
    	 $scope.postMsg.author = {} ; 
    	 $scope.postMsg.author.firstName = $scope.loggedUserName;   
    	 $scope.postMsg.author.lastName = "";   
    	 $scope.postMsg.author.photoUrl = "";   
    	 $scope.postMsg.timeStamp = ""; 
    	 
    	 
    	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
    	 $scope.broadcastData.messageType = "chat:post";
    	 $scope.broadcastData.message = $scope.postMsg; 
    	 
    	 $scope.post();
    	 $scope.addMessage();
   };
   
   $scope.addMessage = function() {
	   
	   $scope.postMsg.timeStamp = Date.now();
	   $scope.messages.push($scope.postMsg);
	   $scope.messageText = "";
	   $scope.postMsg ={};
   };
   
   
   $scope.addStatus = function() {
      
	 $scope.postMsg.chatId = "";//$scope.$scope.loggedUserName = localStorageService.get('loggedUserName');
		$scope.chatWindow = {};
		//$scope.chatWindow = chatStatusData;
		
		$scope.activeChats = {};
		
	    $scope.messages = [];
	    $scope.authorInfo= "";
	    $scope.subscriberIdGlobal = "";
	    $scope.postMsg = {};
	    $scope.broadcastData = {
	            version : null,
	            subscriberId : null,
	            groupId : null,
	            messageType : null,
	            message : null
	    };
	    
	   // $scope.activeChats =chatStatusData; 
	   
	    
	    
	    
	    
	    
	    //Assigning values for posting message,
	    
	     
	     
	    
	    
	    
	    $scope.sendMessage = function() {
	      
	    	$scope.post();
	    	//alert($scope.messageText);
	        $scope.messageText = "";
	    };
	    
	    //Request to send message 
	    
	       $scope.postMessage = function() {
	    	     
	    	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
	    	 $scope.postMsg.messageTxt = $scope.messageText;
	    	 $scope.postMsg.author = {} ; 
	    	 $scope.postMsg.author.firstName = $scope.loggedUserName;   
	    	 $scope.postMsg.author.lastName = "";   
	    	 $scope.postMsg.author.photoUrl = "";   
	    	 $scope.postMsg.timeStamp = ""; 
	    	 
	    	 
	    	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
	    	 $scope.broadcastData.messageType = "chat:post";
	    	 $scope.broadcastData.message = $scope.postMsg; 
	    	 
	    	 $scope.post();
	    	 $scope.addMessage();
	   };
	   
	   $scope.addMessage = function() {
		   
		   $scope.postMsg.timeStamp = Date.now();
		   $scope.messages.push($scope.postMsg);
		   $scope.messageText = "";
		   $scope.postMsg ={};
	   };
	   
	   
	   $scope.addStatus = function() {
	      
		 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
	  	 $scope.postMsg.messageTxt = "is typing ...";
	  	 $scope.postMsg.author = {} ; 
	  	 $scope.postMsg.author.firstName = $scope.loggedUserName;
	  	 $scope.postMsg.author.lastName = "";   
	  	 $scope.postMsg.author.photoUrl = "";   
	  	 $scope.postMsg.timeStamp = ""; 
	  	 
	  	 
	  	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
	  	 $scope.broadcastData.messageType = "chat:status";
	  	 $scope.broadcastData.message = $scope.postMsg;
		   
	  	 $scope.post();
	  	 
	  	 
		   
	     };
	     $scope.removeStatus = function() {
	         
	    	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
	      	 $scope.postMsg.messageTxt = "";
	      	 $scope.postMsg.author = {} ; 
	      	 $scope.postMsg.author.firstName = "";   
	      	 $scope.postMsg.author.lastName = "";   
	      	 $scope.postMsg.author.photoUrl = "";   
	      	 $scope.postMsg.timeStamp = ""; 
	      	 
	      	 
	      	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
	      	 $scope.broadcastData.messageType = "chat:remove";
	      	 $scope.broadcastData.message = $scope.postMsg;
	      	 $scope.post();
	         };chatInfo.subscriberId;
  	 $scope.postMsg.messageTxt = "is typing ...";
  	 $scope.postMsg.author = {} ; 
  	 $scope.postMsg.author.firstName = $scope.loggedUserName;
  	 $scope.postMsg.author.lastName = "";   
  	 $scope.postMsg.author.photoUrl = "";   
  	 $scope.postMsg.timeStamp = ""; 
  	 
  	 
  	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
  	 $scope.broadcastData.messageType = "chat:status";
  	 $scope.broadcastData.message = $scope.postMsg;
	   
  	 $scope.post();
  	 
  	 
	   
     };
     $scope.removeStatus = function() {
         
    	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
      	 $scope.postMsg.messageTxt = "";
      	 $scope.postMsg.author = {} ; 
      	 $scope.postMsg.author.firstName = "";   
      	 $scope.postMsg.author.lastName = "";   
      	 $scope.postMsg.author.photoUrl = "";   
      	 $scope.postMsg.timeStamp = ""; 
      	 
      	 
      	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
      	 $scope.broadcastData.messageType = "chat:remove";
      	 $scope.broadcastData.message = $scope.postMsg;
      	 $scope.post();
         };
   
     
   $scope.postAgent = function(){
	   $http({
   		url: "http://localhost:8080/eserve.worksystem.service.chat-web/chatservice/subscribe/chat", 
   		method: "POST",
   		dataType:"JSON", 
   		data:$scope.broadcastData,
   		headers: {'Content-type': 'application/json'} }).
   	    success(function (resp) {
   	    		//$scope.addMessage();
   	    		
	        }).
	        error(function(resp) {
	        	alert("Request  Failed : while sending message");
	        	return false;
	        });
   };
    	 
 }