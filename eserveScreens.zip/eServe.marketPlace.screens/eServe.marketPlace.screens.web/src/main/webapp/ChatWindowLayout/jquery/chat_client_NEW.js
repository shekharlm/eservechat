	
	var hostAddress = "localhost";
    var requestMaps = null;
    var postMsg = {
            chatId : null,
            messageTxt : null,
            author : {
                    firstName:null,
                    lastName:null,
                    photoUrl:null
            },
            timeStamp : null
    };
    var broadcastData = {
            version : null,
            subscriberId : null,
            groupId : null,
            messageType : null,
            message : null
    };
    var atmosphereUtils;
    $(document).ready(function(){
              atmosphereUtils = new AtmosphereUtils();
    });
     
    var subscriberId = null;

    Array.prototype.remove = function(el) {
            return this.splice(this.indexOf(el), 1);
    };
     
    function agentRequest(subId) {
            subscriberId= subId;
            postMsg.messageTxt = " is requesting an agent.";
            broadcastData.messageType = "agent:request";
            broadcastData.subscriberId = subId;
            broadcastData.message = postMsg;
            atmosphereUtils.initRequest(subscriberId,this.callback);
            post(broadcastData);
    }
    // jquery.atmosphere.response
    function callback(response) {
            if (response.transport != 'polling' && response.state == 'messageReceived') {
                    $.atmosphere.log('info', [ "response.responseBody: "
                                    + response.responseBody ]);
                    if (response.status == 200) {
                            displayChat(response.responseBody);
                    }
            }
    }
     
    function displayChat(data) {
            response = JSON.parse(data);
            if (response.messageType.match("chat:status") != null
                    && (response.message.author.firstName != postMsg.author.firstName)) {
            	chatStatusMessage(response);
            } else if (response.messageType.match("chat:remove") != null
                    && (response.message.author.firstName != postMsg.author.firstName)) {
    			removeStatusMessage(response);
            } else if (response.messageType.match("chat:post") != null) {
            	 addMessage(response);
            } else if (response.messageType.match("agent:accept") != null) {
                    agentAccepted(response);
            }
    }
    
    function post(object) {
            var request = $.ajax({
                    url : 'http://'+hostAddress+':8080/eserve.worksystem.service.chat-web/chatservice/subscribe/chat',
                    type : 'POST',
                    data : JSON.stringify(object),
                    contentType : "application/json; charset=utf-8",
            });
            request.fail(function(jqXHR, textStatus) {
                    alert("Request failed: " + textStatus);
            });
    }
    
    function setNameText(varName,chatId){
		postMsg.chatId = chatId;
        postMsg.author.firstName = varName;
        broadcastData.groupId = "agents";
        agentRequest(chatId);
    }
    
    // when chat is closed , to destroy the atmosphere resources from the browser and server side
    function closeChat(subId){
            var req =requestMaps.get(subId);
            if (req != null){
                    req.close();
            }
    }
    // when agent is accepted the request ,this method will open the chat window
	function agentAccepted(response) {
		 var scope = angular.element(".chat-window-overlay").scope();
		 scope.$apply(function() {
			   scope.chatInfo = response;
		    });
	}