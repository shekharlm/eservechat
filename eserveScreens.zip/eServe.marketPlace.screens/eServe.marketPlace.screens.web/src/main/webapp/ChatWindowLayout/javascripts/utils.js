/**
 * Map
 */
function Map() {
this.keys = new Array();
this.data = new Object();

this.put = function(key, value) {
    if(this.data[key] == null){
        this.keys.push(key);
    }
    this.data[key] = value;
};

this.get = function(key) {
    return this.data[key];
};

this.remove = function(key) {
    this.keys.remove(key);
    this.data[key] = null;
};

this.each = function(fn){
    if(typeof fn != 'function'){
        return;
    }
    var len = this.keys.length;
    for(var i=0;i<len;i++){
        var k = this.keys[i];
        fn(k,this.data[k],i);
    }
};

this.entrys = function() {
    var len = this.keys.length;
    var entrys = new Array(len);
    for (var i = 0; i < len; i++) {
        entrys[i] = {
            key : this.keys[i],
            value : this.data[i]
        };
    }
    return entrys;
};

this.isEmpty = function() {
    return this.keys.length == 0;
};

this.size = function(){
    return this.keys.length;
};
};

//configuring atmosphere attributes
function AtmosphereUtils(){
	var socket = $.atmosphere;
	this.requests= new Map();
	this.url = $.url();
	this.request = new $.atmosphere.AtmosphereRequest();
	this.path = '/eserve.worksystem.service.chat-web/chathandler/subscribe';
	
	this.initRequest = function(varSubscriberId,callbackMethod){
		//varSubscriberId = this.getSessionId();	
		  this.request.url = this.url.attr('protocol') + '://' + this.url.attr('host') + ':'
			+ this.url.attr('port')
			+ this.path+"?subscriberId="+varSubscriberId;
		  
		  this.request.contentType = "application/json";
		  this.request.transport = 'long-polling';
		  this.request.fallbackTransport = 'long-polling';
		  this.request.enableProtocol = true;
	      if (typeof(callbackMethod) == 'function') {
               this.request.callback = callbackMethod;
	      }
		  var connection = socket.subscribe(this.request);
		  this.requests.put(varSubscriberId, connection);
		return connection;
	};
	  
	this.setPath = function(varPath){
		this.path = varPath;
	};
	
	this.getRequest = function(subId){
		return this.requests.get(subId);
	};
	
	this.close = function(subId){
		var req =this.requests.get(subId);
		if (req != null){
			socket.unsubscribeUrl(req.getUrl());
		}
	};
	
	this.clearStorage=function(){
		this.requests.each(this.processRequests);
	};
	this.processRequests = function(key,value,index){
		//console.log(key,value,index);
		value.clearStorage();
	};
	
	this.getSessionId = function() {
		var res = "hi";
			$.get("http://"+hostAddress+":8080/eserve.worksystem.service.chat-web/chatservice/subscribe/session",
					function(msg){
				//alert('under atmosphereUtils '+msg);
				res = msg;
			});
		return res;
	};
};
  
