
chatClientApp = angular.module('chatClientApp1',['ui.keypress']);
chatClientApp.directive('onKeyup', function() {
    return function(scope, elm, attrs) {
        elm.bind('keypress', function(evt) {
            //if no key restriction specified, always fire
            if (evt.which != 13 && evt.target.value.length == 3) {
            	scope.$apply(attrs.onKeyup);
            } else if(evt.which == 13) {
            	
            	$(".chat-log").animate({ scrollTop: $(".chat-log").get(0).scrollHeight}, "slow");
            	evt.preventDefault();
            }
        });
    };
});
chatClientApp.directive('onBlur', function() {
    return function(scope, elm, attrs) {
        elm.bind('blur', function(evt) {
            //if no key restriction specified, always fire
            
            	scope.$apply(attrs.onBlur);
            
        });
    };
});
chatClientApp.directive('onFoucs', function() {
    return function(scope, elm, attrs) {
        elm.bind('focus', function(evt) {
            //if no key restriction specified, always fire
            
        	if(evt.target.value.length > 3) {
        	
            	scope.$apply(attrs.onFocus);
        	}
            
        });
    };
});

// Service for chat , to make communication between different controllers
	

chatClientApp.factory('chatStatusData', function(){
	return {
		count : 0,
		show :false
		
	};
});
function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) == variable) {
            return decodeURIComponent(pair[1]);
        }
    }
    console.log('Query variable %s not found', variable);
};

function chatControllerAgent($scope, $compile,$http,$location) {
		var subscriberId=getQueryVariable('subscriberId');
		var displayName = "C1";
		localStorage["ls.loggedUserName"] = displayName;
		alert(subscriberId);
		$('.chat-box-body').empty();
			var chatBodyContent = "<div class='chat-log'><div class='chat-conversation' ng-repeat='message in messages'>"+
			"<div class='chat-heading'><span id='chatName'>{{message.author.firstName}}</span>said:<span class='chat-time pull-right'>{{message.timeStamp | date:'h:mm a' |lowercase}}</span></div>" 
			+"<div class='chat-conversation-body'>"
			+"	{{message.messageTxt}}"
			+"</div>"
		+"</div>"
	
		+"</div>"
		+"<div class='chat-status-message-cont'>"
		+"<div class='chat-status-message'>{{messageStatus.author.firstName}} {{messageStatus.messageTxt}}</div>"
		+"<img class='iconClip' src='assets/Img/icon-clip.png'/>"
		+"</div>"
		+"<form>"
		+"<div class='chat-input'>"
		+"	<textarea ui-keypress='{13:\"postMessage()\"}' ng-model='messageText' on-keyup='addStatus()' on-blur='removeStatus()' on-foucs='addStatus()'></textarea>"
		+"</div>"
		+"</form>";
  	 	 $('.chat-box-body').append($compile(chatBodyContent)($scope));
  	 	 
 	 	  

   	 	
	 		/**********************************************
	 					copied from old chat jagan agent
	 		
	 		***************************************************/
	 	$scope.messages = [];
	    $scope.authorInfo= "";
	    $scope.subscriberIdGlobal = "";
	    $scope.postMsg = {};
	    $scope.broadcastData = {
	            version : null,
	            subscriberId : null,
	            groupId : null,
	            messageType : null,
	            message : null
	    };
	    $scope.postMsg.author = {};

	    
	    //Request to send message 
	    
	       $scope.postMessage = function() {
	    	     
	    	 $scope.postMsg.chatId = subscriberId;
	    	 $scope.postMsg.messageTxt = $scope.messageText;
	    	 $scope.postMsg.author = {} ; 
	    	 $scope.postMsg.author.firstName = localStorage["ls.loggedUserName"];   
	    	 $scope.postMsg.author.lastName = "";   
	    	 $scope.postMsg.author.photoUrl = "";   
	    	 $scope.postMsg.timeStamp = ""; 
	    	 
	    	$scope.broadcastData.groupId =null;
	    	 $scope.broadcastData.subscriberId = subscriberId;
	    	 $scope.broadcastData.messageType = "chat:post";
	    	 $scope.broadcastData.message = $scope.postMsg; 
	    	 
	    	 $scope.post();
	    	 $scope.addMessage();
	   };
	   
	   $scope.addMessage = function() {
		   
		   $scope.postMsg.timeStamp = Date.now();
		   //$scope.messages.push($scope.postMsg);
		   $scope.messageText = "";
		   $scope.postMsg ={};
	   };
	   
	   
	    $scope.sendMessage = function() {
	      
	    	$scope.post();
	    	//alert($scope.messageText);
	        $scope.messageText = "";
	    };
	     
	     
	   $scope.addStatus = function() {
	      
			 $scope.postMsg.chatId = subscriberId;
		  	 $scope.postMsg.messageTxt = "is typing ...";
		  	 $scope.postMsg.author = {} ; 
		  	 $scope.postMsg.author.firstName = localStorage["ls.loggedUserName"];;
		  	 $scope.postMsg.author.lastName = "";   
		  	 $scope.postMsg.author.photoUrl = "";   
		  	 $scope.postMsg.timeStamp = ""; 
		  	 
		  	$scope.broadcastData.groupId =null;
		  	 $scope.broadcastData.subscriberId = subscriberId;
		  	 $scope.broadcastData.messageType = "chat:status";
		  	 $scope.broadcastData.message = $scope.postMsg;
			   
		  	 $scope.post();
		  	 
		  	 
			   
		     };
		     
	     $scope.removeStatus = function() {
	         
	    	 $scope.postMsg.chatId = subscriberId;
	      	 $scope.postMsg.messageTxt = "";
	      	 $scope.postMsg.author = {} ; 
	      	 $scope.postMsg.author.firstName = localStorage["ls.loggedUserName"];;   
	      	 $scope.postMsg.author.lastName = "";   
	      	 $scope.postMsg.author.photoUrl = "";   
	      	 $scope.postMsg.timeStamp = ""; 

	      	 $scope.broadcastData.groupId =null;
	      	 $scope.broadcastData.subscriberId = subscriberId;
	      	 $scope.broadcastData.messageType = "chat:remove";
	      	 $scope.broadcastData.message = $scope.postMsg;
	      	 $scope.post();
	         };
	 
	       $scope.post = function(){
	  	   $http({
	     		url: "http://"+hostAddress+":8080/eserve.worksystem.service.chat-web/chatservice/subscribe/chat", 
	     		method: "POST",
	     		dataType:"JSON", 
	     		data:$scope.broadcastData,
	     		headers: {'Content-type': 'application/json'} }).
	     	    success(function (resp) {
	     	    		//$scope.addMessage();
	     	    		
	  	        }).
	  	        error(function(resp) {
	  	        	alert("Request  Failed : while sending message");
	  	        	return false;
	  	        });
	     };
	     
	     
  	 	$scope.broadcastData.subscriberId = subscriberId;
  	 	$scope.broadcastData.messageType = "agent:accept"; 
  	 	
  	 	$scope.postMsg.author.firstName = localStorage["ls.loggedUserName"];
  	 	$scope.postMsg.chatId = subscriberId;
  	 	$scope.postMsg.messageTxt= " is accepted";
  	 	$scope.broadcastData.message = $scope.postMsg;
		   $scope.chatInfo = $scope.broadcastData;
		   //$scope.chatWindow.show = true;
		  // $scope.activeChats.count = 1;
  		 /*var uuid =atmosphereUtils.requests.get("/agents/"+subscriberId).getUUID();
  		$.get("http://"+hostAddress+":8080/eserve.worksystem.service.chat-web/chatservice/subscribe/session/addresource/"+uuid+"/"+response.message.chatId,
  				function(msg){
  			post(broadcastData);
  		});*/
		$scope.callback = function(response){
			 if (response.transport != 'polling' && response.state == 'messageReceived') {
                 $.atmosphere.log('info', [ "response.responseBody: "
                                 + response.responseBody ]);
                 if (response.status == 200) {
                         displayChat(response.responseBody);
                 }
         }
		};
		if (atmosphereUtils == null){
			atmosphereUtils = new AtmosphereUtils();
		}
  		atmosphereUtils.initRequest(subscriberId,$scope.callback);
  		$scope.post();

  	 	 
  	 	 
/*    		$('.chat-box-body').append( $compile("<div id='chat_form'>"
				+"<label style='float:left;font-size:11px;margin-left: 8px;'>Display Name</label>"
				+"<input type='text' name='' placeHolder='enter display name' style='height:30px;margin-left: 8px;' id='displayName' /><br>"
				+"<button id='submit' ng-click='postDisplayName()' style='margin-left: 8px;' class='btn btn-success'>Submit</button> </div>")($scope));*/
		
     /*   $(".chat-conversation-body").append( $compile("<div id='chat_form'>"
							+"<label style='float:left'>Display Name</label>"
							+"<input type='text' name='' value='ravi' style='height:30px' id='displayName' /><br>"
							+"<button id='submit' ng-click='post()' class='btn btn-success'>Submit</button> </div>")($scope) );*/
        
/*      	   $http({
      		url: "http://"+hostAddress+":8080/eserve.worksystem.service.chat-web/chatservice/subscribe/company/1", 
      		method: "GET",
      		dataType:"JSON", 
      		headers: {'Content-type': 'application/json'} }).
      	    success(function (resp) {
      	    		if(resp.flgCanProcessRequest==true){
      	    			$('.chat-box-body').empty();
          	    		$('.chat-box-body').append( $compile("<div id='chat_form'>"
    							+"<label style='float:left;font-size:11px;margin-left: 8px;'>Display Name</label>"
    							+"<input type='text' name='' placeHolder='enter display name' style='height:30px;margin-left: 8px;' id='displayName' /><br>"
    							+"<button id='submit' ng-click='postDisplayName()' style='margin-left: 8px;' class='btn btn-success'>Submit</button> </div>")($scope));
          	    		
      	    		}else{
      	    			$(".chat-log").css('display','none');
          	        	$(".chat-input").css('display','none');
          	        	 $(".chat-box-body").append( $compile("<div id='chat_msg_form'>"
          	        			 +"<label style='color:red;font-size: 11px;'>No agents available at this time .Please fill the form</label>"
     							+"<label style='font-size: 11px;margin-left: 8px;'>Name:</label><input type='text' name='' placeHolder='enter name' style='height:25px;margin-left: 8px;' id='form_msg_name' /><br>"
     							+"<label style='font-size: 11px;margin-left: 8px;'>Email:</label><input type='email' name='' placeHolder='enter email' style='height:25px;margin-left: 8px;' id='form_msg_email' /><br>"
     							+"<label style='font-size: 11px;margin-left: 8px;'>Mobile:</label><input type='text' name='' placeHolder='enter mobile' style='height:25px;margin-left: 8px;' id='form_msg_mobile' /><br>"
     							+"<label style='font-size: 11px;margin-left: 8px;'>Post query:</label><textarea placeHolder='enter query' style='margin-left: 8px;'  class='ng-pristine ng-valid'></textarea><br>"
     							+"&nbsp;&nbsp<button id='form_msg_submit' ng-click='formSubmit()' class='btn btn-success'>Send</button>" +
     									"&nbsp &nbsp<button id='form_msg_callback' ng-click='callback()' class='btn btn-success'>Call back</button> </div>")($scope) );
      	    		}
      	        }).
      	        error(function(resp) {
      	        	alert("error " + resp);
      	        	 return false;
      	        });
*/    
      };
