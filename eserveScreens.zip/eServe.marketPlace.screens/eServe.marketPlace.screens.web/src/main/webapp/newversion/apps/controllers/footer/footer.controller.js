(function( ng, app ){

	"use strict";

	app.controller(
		"footer.controller",
		function( $scope, $http, localize, requestContext, _ ) {

			this.scope = $scope;
			this.ajax = $http;
			this.scope.setEnglishLanguage = function() {
		        localize.setLanguage('en-US');
		    };

		    this.scope.setPigLatinLanguage = function() {
		        localize.setLanguage('es-es');
		    };
		}
	);

})( angular, eServe );

