
 
function chatStatusCtrl($scope,$http,$rootScope,chatStatusData) {
	
	$scope.activeChats= {};
	$rootScope.activeChats = 0;
	$rootScope.waitingReply = 0;
	$scope.activeChat = 0;
	$scope.activeChats = chatStatusData;
	$scope.chatWindow = {};
	$scope.chatWindow = chatStatusData
	
};


function chatCtrl($scope,$http,$rootScope,chatStatusData, localStorageService) {
	
	$scope.loggedUserName = localStorageService.get('loggedUserName');
	$scope.chatWindow = {};
	$scope.chatWindow = chatStatusData;
	
	$scope.activeChats = {};
	
    $scope.messages = [];
    $scope.authorInfo= "";
    $scope.subscriberIdGlobal = "";
    $scope.postMsg = {};
    $scope.broadcastData = {
            version : null,
            subscriberId : null,
            groupId : null,
            messageType : null,
            message : null
    };
    
    $scope.activeChats =chatStatusData; 
   
    
    
    
    
    
    //Assigning values for posting message,
    
     
     
    
    
    
    $scope.sendMessage = function() {
      
    	$scope.post();
    	//alert($scope.messageText);
        $scope.messageText = "";
    };
    
    //Request to send message 
    
       $scope.postMessage = function() {
    	     
    	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
    	 $scope.postMsg.messageTxt = $scope.messageText;
    	 $scope.postMsg.author = {} ; 
    	 $scope.postMsg.author.firstName = $scope.loggedUserName;   
    	 $scope.postMsg.author.lastName = "";   
    	 $scope.postMsg.author.photoUrl = "";   
    	 $scope.postMsg.timeStamp = ""; 
    	 
    	 
    	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
    	 $scope.broadcastData.messageType = "chat:post";
    	 $scope.broadcastData.message = $scope.postMsg; 
    	 
    	 $scope.post();
    	 $scope.messageText = "";
    	 $scope.addMessage();
   };
   
   $scope.addMessage = function() {
	   
	   $scope.postMsg.timeStamp = Date.now();
	   //$scope.messages.push($scope.postMsg);
	   $scope.messageText = "";
	   $scope.postMsg ={};
   };
   
   
   $scope.addStatus = function() {
      
	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
  	 $scope.postMsg.messageTxt = "is typing ...";
  	 $scope.postMsg.author = {} ; 
  	 $scope.postMsg.author.firstName = $scope.loggedUserName;
  	 $scope.postMsg.author.lastName = "";   
  	 $scope.postMsg.author.photoUrl = "";   
  	 $scope.postMsg.timeStamp = ""; 
  	 
  	 
  	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
  	 $scope.broadcastData.messageType = "chat:status";
  	 $scope.broadcastData.message = $scope.postMsg;
	   
  	 $scope.post();
  	 
  	 
	   
     };
     $scope.removeStatus = function() {
         
    	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
      	 $scope.postMsg.messageTxt = "";
      	 $scope.postMsg.author = {} ; 
      	 $scope.postMsg.author.firstName = "";   
      	 $scope.postMsg.author.lastName = "";   
      	 $scope.postMsg.author.photoUrl = "";   
      	 $scope.postMsg.timeStamp = ""; 
      	 
      	 
      	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
      	 $scope.broadcastData.messageType = "chat:remove";
      	 $scope.broadcastData.message = $scope.postMsg;
      	 $scope.post();
         };
   
     
   $scope.post = function(){
	   $http({
   		url: "http://localhost:8080/eserve.worksystem.service.chat-web/chatservice/subscribe/chat", 
   		method: "POST",
   		dataType:"JSON", 
   		data:$scope.broadcastData,
   		headers: {'Content-type': 'application/json'} }).
   	    success(function (resp) {
   	    		//$scope.addMessage();
   	    		
	        }).
	        error(function(resp) {
	        	alert("Request  Failed : while sending message");
	        	return false;
	        });
   };
    	 
 }