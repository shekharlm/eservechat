	
(function( ng, app ){
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        var actToken = window.location.href.split('/').pop();
        this.localStorageService = localStorageService;
    	 this.ajax({url: "../../accountmanagement-r-web/eServe/profiles/invitationAccepts", method: "POST", headers: {'Content-type': 'application/json', 'activationToken':actToken } }).success(function (resp, $scope) {
    		 $rootScope.empInvitationData = resp;
    		 $rootScope.empInvitationData.profileType = "4";
    		 localStorageService.add('empInvitationData',JSON.stringify($rootScope.empInvitationData));
         }).error(function (resp) {
	        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
	       });
    	this.scope.empExistLoginAcc = {
    			"emailId": "",
    			"password": "",
    			"virtualAccountId": "",
    			"profileType": "4"
    	}; 
    	
    	this.scope.existingLoginOption = "0";   
    	
    	this.scope.existingLoginOptionCntrl = function( value ) {
    		return $scope.existingLoginOption;  
    	};
    	
    	    	
    	this.scope.getInvitationStatus = function() {
    		if( $scope.empInvitationData != undefined ) {
    			return $scope.empInvitationData.status;   
    		}
    	};
    	
    	
        this.scope.successInvitationLoginCntrl = ng.bind( this, this.successInvitationLoginCntrl );
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	
        	successInvitationLoginCntrl: function() {
        		if(this.scope.empExistLoginAcc.emailId != "" && this.scope.empExistLoginAcc.password != "" ){
        			this.localStorageService.add('userEmailId',this.scope.empExistLoginAcc.emailId);
        			this.ajax({url: "../../accountmanagement-w-web/eServe/profiles/profilelogin", method: "POST", headers: {'Content-type': 'application/json', 'emailId': this.scope.empExistLoginAcc.emailId , 'password': this.scope.empExistLoginAcc.password, 'virtualAccountId': this.scope.empInvitationData.virtualAccountId, 'profileType': this.scope.empExistLoginAcc.profileType }  }).success(function (resp) {
        				$("#loginCntrl").trigger('click');
    		        }).error(function (resp) {
    		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
    		        });
    			}
        	}
        };
 
		// Define the Controller as the constructor function.
    app.controller( "empinvitationaccept.controller", Controller );
})( angular, eServe );