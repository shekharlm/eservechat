
(function( ng, app ){
	
	"use strict";
	
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        this.localStorageService = localStorageService;
        if ( JSON.parse(localStorageService.get('signupData')) != null ) {
        	if( JSON.parse(localStorageService.get('signupData')).emailId != undefined && JSON.parse(localStorageService.get('signupData')).emailId != null && JSON.parse(localStorageService.get('signupData')).profileTypeId != "4" ) {
        		this.scope.userEmailId = JSON.parse(localStorageService.get('signupData')).emailId;
        	}
        	else if( JSON.parse(localStorageService.get('signupData')).profileTypeId == "4" || JSON.parse(localStorageService.get('signupData')).profileTypeId == "5"  ) {
        		this.scope.userEmailId = localStorageService.get('userEmailId');
        	}
        }else {
        	this.scope.userEmailId = localStorageService.get('userEmailId');
        }
        	
        //../../accountmanagement-r-web/eServe/registrationread/populatebasicinfo
        //data/user.json
        this.ajax({url: "data/user.json", method: "GET", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  } }).success(function (resp, $scope) {
        	$rootScope.viewBasicProfile = resp;
        	if( resp.basicProfileType == 1 ) {
        		$rootScope.accountType = PROFILETYPE1;
        	}else if( resp.basicProfileType == 2 ) {
        		$rootScope.accountType = PROFILETYPE2;
        	}else if( resp.basicProfileType == 3 ) {
        		$rootScope.accountType = PROFILETYPE3;
        	}else if( resp.basicProfileType == 4 ) {
        		$rootScope.accountType = PROFILETYPE4;
        	}else if( resp.basicProfileType == 5 ) {
        		$rootScope.accountType = PROFILETYPE5;
        	}
        	localStorageService.add('loggedUserName',resp.displayName);
        }).error(function (resp) {
    		$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
        });
        
		this.scope.getProfileTypeUser = function () {
			if( $rootScope.accountType == PROFILETYPE2 || $rootScope.accountType == PROFILETYPE3 ) {
				return true;
			}else{
				return false;
			}
		};
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	succesUpdateProfileCntrl: function() {
        		
    			this.ajax({url: "data/success.json", method: "POST", data: JSON.stringify($rootScope.viewProfile) }).success(function (resp) {
    				/*if( resp.status.toLowerCase() == SUCCESS )
					{
						alert(JSON.stringify(this.scope.signData));
			        
					}else if( resp.status.toLowerCase() == FAILED )
					{
						alert("You can't able to signup to eserve. Please try later.");
					}*/
		        });	
        	}
        };
 
		// Define the Controller as the constructor function.
    app.controller( "home.headercontoller", Controller );
})( angular, eServe );

