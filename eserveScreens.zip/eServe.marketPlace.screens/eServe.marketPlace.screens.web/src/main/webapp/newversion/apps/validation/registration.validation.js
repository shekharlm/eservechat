//
//	jQuery Validate example script
//
//	Prepared by David Cochran
//
//	Free for your use -- No warranties, no guarantees!
//

$(document).ready(function(){

	// Validate
	// http://bassistance.de/jquery-plugins/jquery-plugin-validation/
	// http://docs.jquery.com/Plugins/Validation/
	// http://docs.jquery.com/Plugins/Validation/validate#toptions

		$('#reg-form').validate({
	    rules: {
	      firstname: {
	    	minlength: 3,
	        required: true
	      },
	      lastname: {
	    	minlength: 3,
	        required: true
	      },
	      personalnumber: {
	    	  required: true,
	    	  minlength: 10,
	    	  maxlength: 15
	      },
	      providerTitle: {
	    	  minlength: 3,
		      required: true
	      },
	      providerOverview: {
	    	  minlength: 120,
	    	  maxlength: 600,
	    	  required: true
	      },
	      providerServiceDescription: {
	    	  minlength: 120,
	    	  maxlength: 600,
	    	  required: true
	      },
	      providerMinimumHourlyRate: {
	    	  required: true
	      },
	      providerBusinessCompanyName: {
	    	  required: true
	      },
	      providerBusinessTagName: {
	    	  required: true
	      },
	      providerBusinessOverview: {
	    	  minlength: 120,
	    	  maxlength: 600,
	    	  required: true
	      },
	      providerBusinessService: {
	    	  minlength: 120,
	    	  maxlength: 600,
	    	  required: true
	      },
	      providerBusinessCompanyeMailId: {
	    	  required: true,
		      email: true
	      }
	    },
		highlight: function(element) {
			$(element).closest('.control-group').removeClass('success').addClass('error');
		},
		success: function(element) {
			element
			.text('OK!').addClass('valid')
			.closest('.control-group').removeClass('error').addClass('success');
		},
		// specifying a submitHandler prevents the default submit
		submitHandler: function() {
			$('#regPPBSuccess').trigger('click');
		}
	  });

}); // end document.ready