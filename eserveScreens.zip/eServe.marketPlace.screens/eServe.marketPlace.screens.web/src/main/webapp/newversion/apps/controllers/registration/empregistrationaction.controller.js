	
(function( ng, app ){
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        this.localStorageService = localStorageService;
        this.scope.userEmailId = JSON.parse(localStorageService.get('signupData')).emailId;
    	 this.ajax({url: "../../accountmanagement-r-web/eServe/registrationread/populatebasicinfo", method: "GET", headers: {'Content-type': 'application/json', 'emailId':this.scope.userEmailId } }).success(function (resp, $scope) {
    		 $rootScope.empBasicInfo = resp;
    		 $rootScope.virtualAccId = $rootScope.empBasicInfo.id;
    		 if(  $rootScope.empBasicInfo.userContacts != undefined || $rootScope.empBasicInfo.userContacts.length <= 0  ) {
    			 $rootScope.empBasicInfo.userContacts = [
    		                                                    {
    		                                                       "id": "",
    		                                                       "contactNumber": "",
    		                                                       "contactNumberCode": "",
    		                                                       "contactType": "Phone",
    		                                                       "userCompaniesId": 0,
    		                                                       "user": null
    		                                                   }
    		                                               ];
    		 }
    		
         }).error(function (resp) {
	        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
	        });
    	 $http({url: "data/empRegData.json", method: "GET"}).success(function (resp, $scope) {
    		 $rootScope.employeeInfo = resp;
         });
        this.ajax({url: "data/CountryCodes.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.countryList = resp;
        });
        this.ajax({url: "data/empSendJson.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.empSendJson = resp;
        });
       
        
        this.scope.succesEmpRegCntrl = ng.bind( this, this.succesEmpRegCntrl );
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	succesEmpRegCntrl: function() {
        		this.scope.userEmailId = this.scope.empBasicInfo.emailId;
        		this.scope.empBasicInfo.userContacts[0].contactNumber = this.scope.empBasicInfo.userContacts[0].contactNumberCode + this.scope.empBasicInfo.userContacts[0].contactNumber;
        		delete this.scope.empBasicInfo.userContacts[0].contactNumberCode;
        		this.scope.empSendJson.virtualAccount =  this.scope.employeeInfo;
        		this.scope.empSendJson.virtualAccountId =  this.scope.virtualAccId;
        		
        		this.ajax({url: "../../accountmanagement-w-web/eServe/RegistrationWrite/updateuser", method: "POST", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId}, data: JSON.stringify(this.scope.empBasicInfo) }).success(function (resp) {
    				alert('Basic Info Saved Successfully');
    				
		        }).error(function (resp) {
		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
		        });
        		
    			/*this.ajax({url: "../../accountmanagement-w-web/eServe/profiles/createemployeeprofile", method: "PUT", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId }, data: JSON.stringify(this.scope.empSendJson) }).success(function (resp) {
    				
    				alert('Employee Info Saved Successfully');
    				
		        }).error(function (resp) {
		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
		        });
		        */
        		
    			var userHasSkills = [];
     			 for( var sk = 0; sk < $("#listOfSkills").tokenInput('get').length; sk++ )
     			{
     				 userHasSkills.push({
     				        "id": "",
     				        "additionalComments": null,
     				        "relevantExp": 0,
     				        "skillId": $("#listOfSkills").tokenInput('get')[sk].id,
     				        "userId": "",
     				        "skill": null,
     				        "user": null,
     				        "userSkillRatings": []
     				    });
     			}
     			this.ajax({url: "../../accountmanagement-w-web/eServe/skills/saveuserskills", method: "PUT", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(userHasSkills) }).success(function (resp) {
     				
     					alert('Skills Info Saved Successfully');
     					alert('Thanks for Registration...!!! Welcome to eServe');
     					$("#empRegCntrl").trigger('click');
 		        	}).error(function (resp) {
 		        		alert(resp);
 		        }).error(function (resp) {
		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
		        });
        	}
        };
 
		// Define the Controller as the constructor function.
    app.controller( "empregistration.controller", Controller );
})( angular, eServe );