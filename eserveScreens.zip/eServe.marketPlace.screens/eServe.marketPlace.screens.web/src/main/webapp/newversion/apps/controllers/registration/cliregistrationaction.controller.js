	
(function( ng, app ){
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        this.localStorageService = localStorageService;
        this.scope.userEmailId = JSON.parse(localStorageService.get('signupData')).emailId;
        //../../accountmanagement-r-web/eServe/registrationread/populatebasicinfo
        this.ajax({url: "../../accountmanagement-r-web/eServe/registrationread/populatebasicinfo", method: "GET", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  } }).success(function (resp, $scope) {
        	$rootScope.clientBasicInfo = resp;
        	$rootScope.clientBasicInfo.userContacts = [
                             {
                                 "id": 20,
                                 "contactNumber": "",
                                 "contactNumberCode": "",
                                 "contactType": "Phone",
                                 "userCompaniesId": 0,
                                 "user": null
                             }
                         ];
        }).error(function (resp) {
        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
        });
        this.ajax({url: "data/clientbusinessprofile.json", method: "GET"}).success(function (resp, $scope) {
			$rootScope.clientBusinessInfo = resp;
        });
        
        this.ajax({url: "../../accountmanagement-r-web/eServe/profiles/getindustrytypes", method: "GET", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  } }).success(function (resp, $scope) {
        	$rootScope.industryType = resp;
        }).error(function (resp) {
    		alert(resp);
        });
        
        //this.scope.clientBasicInfo.firstName = JSON.parse(localStorageService.get('signupData')).displayName.split(' ')[0];
        //this.scope.clientBasicInfo.lastName = JSON.parse(localStorageService.get('signupData')).displayName.split(' ')[1];
        //this.scope.clientBasicInfo.phoneNumber.name = JSON.parse(localStorageService.get('signupData')).country.countryName;
        
        this.ajax({url: "data/CountryCodes.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.countryList = resp;
        });
		this.scope.succesCliRegCntrl = ng.bind( this, this.succesCliRegCntrl );
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	succesCliRegCntrl: function() {
        		this.scope.clientBasicInfo.userContacts[0].contactNumber = this.scope.clientBasicInfo.userContacts[0].contactNumberCode + this.scope.clientBasicInfo.userContacts[0].contactNumber;
        		delete this.scope.clientBasicInfo.userContacts[0].contactNumberCode;
        		//../../accountmanagement-w-web/eServe/RegistrationWrite/updateuser
        		this.ajax({url: "../../accountmanagement-w-web/eServe/RegistrationWrite/updateuser", method: "POST", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(this.scope.clientBasicInfo) }).success(function (resp) {
    				alert('Basic Info Saved Successfully');
    				
		        }).error(function (resp) {
		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
		        });	
    			//../../accountmanagement-w-web/eServe/profiles/createproviderprofile
    			this.ajax({url: "../../accountmanagement-w-web/eServe/profiles/createclientbusinessprofile", method: "PUT", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(this.scope.clientBusinessInfo) }).success(function (resp) {
    				
    				alert('Provider Profile Info Saved Successfully');
    				$('#regCliBusinessCntrl').trigger('click');
		        }).error(function (resp) {
		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
		        });	
    			
        	}
        };
 
		// Define the Controller as the constructor function.
    app.controller( "cliregistration.controller", Controller );
})( angular, eServe );