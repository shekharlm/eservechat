	
(function( ng, app ){
	function Controller( $scope, $http, $rootScope, localStorageService  ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.localStorageService = localStorageService;
        
		this.scope.logoutCntrl = ng.bind( this, this.logoutCntrl );
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        logoutCntrl: function() {
        	localStorage.clear();
        	this.localStorageService.clearAll();
    	}
 
    };
		// Define the Controller as the constructor function.
    app.controller( "logout.controller", Controller );
})( angular, eServe );