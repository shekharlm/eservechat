//
//	jQuery Validate example script
//
//	Prepared by David Cochran
//
//	Free for your use -- No warranties, no guarantees!
//

$(document).ready(function(){

	// Validate
	// http://bassistance.de/jquery-plugins/jquery-plugin-validation/
	// http://docs.jquery.com/Plugins/Validation/
	// http://docs.jquery.com/Plugins/Validation/validate#toptions

		$('#updateprofile-form').validate({
	    rules: {
	      name: {
	    	minlength: 3,
	        required: true
	      },
	      number: {
	    	  required: true,
	    	  minlength: 10,
	    	  maxlength: 15
	      },
	      signupcondition: {
	    	  required: true
	      },
	      accountType: {
	    	  required:true
	      },
	      countrySelection: {
	    	  required:true
	      }
	    },
		highlight: function(element) {
			$(element).closest('.control-group').removeClass('success').addClass('error');
		},
		success: function(element) {
			element
			.text('OK!').addClass('valid')
			.closest('.control-group').removeClass('error').addClass('success');
		},
		// specifying a submitHandler prevents the default submit
		submitHandler: function() {
			alert('Profile informtion has been successfully updated');
			$('#updateprofilesuccess').trigger('click');
			$("#updateProfileCntrl").trigger('click');
		}
	  });

}); // end document.ready