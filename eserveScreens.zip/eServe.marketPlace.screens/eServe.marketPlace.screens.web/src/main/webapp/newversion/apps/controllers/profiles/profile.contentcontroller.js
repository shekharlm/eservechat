(function( ng, app ){

	"use strict";

	app.controller(
		"profile.ContentController",
		function( $scope, requestContext, _ ) {

			
		}
	);

})( angular, eServe );

