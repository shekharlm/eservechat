
(function( ng, app ){
	
	"use strict";
	
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
       
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        };
 
		// Define the Controller as the constructor function.
    app.controller( "manageaccount.adminController", Controller );
})( angular, eServe );