	
(function( ng, app ){
	function Controller( $scope, $http, $rootScope, localStorageService  ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        this.localStorageService = localStorageService;
		this.scope.loginData = {
					"emailId" : "",
					"password" : "",
		};
		this.scope.successLoginCntrl = ng.bind( this, this.successLoginCntrl );
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
    	successLoginCntrl: function() {
    		if(this.scope.loginData.emailId != "" && this.scope.loginData.password != "" ){
    			this.localStorageService.add('userEmailId',this.scope.loginData.emailId);
    			this.ajax({url: "../../accountmanagement-r-web/eServe/registrationread/login", method: "GET", headers: {'Content-type': 'application/json', 'emailId': this.scope.loginData.emailId, 'password': this.scope.loginData.password  }  }).success(function (resp) {
    				$("#loginCntrl").trigger('click');
		        }).error(function (resp) {
		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
		        });
			}
    	}
 
    };
		// Define the Controller as the constructor function.
    app.controller( "login.controller", Controller );
})( angular, eServe );