
// Create an application module for our demo.
var eServe = angular.module( "eServe", ['localization','LocalStorageModule','ui.bootstrap','scrollApp.directives','ui.keypress'] );

// Configure the routing. The $routeProvider will be automatically injected into 
// the configurator.
eServe.config(
	function( $routeProvider ){

		// Typically, when defining routes, you will map the route to a Template to be 
		// rendered; however, this only makes sense for simple web sites. When you are 
		// building more complex applications, with nested navigation, you probably need 
		// something more complex. In this case, we are mapping routes to render "Actions" 
		// rather than a template.
		$routeProvider
			.when(
				"/action",
				{
					action: "home.action"
				}
			)
			.when(
				"/home",
				{
					action: "home.home"
				}
			)
			.when(
				"/home/signup",
				{
					action: "home.signup"
				}
			)
			.when(
				"/home/registration/1",
				{
					action: "home.provregistration"
				}
			)
			.when(
				"/home/registration/3",
				{
					action: "home.cliregistration"
				}
			)
			.when(
				"/home/registration/4",
				{
					action: "home.empregistration"
				}
			)
			.when(
				"/home/registration/4/:actionToken",
				{
					action: "home.empinvitationaccept"
				}
			)
			.when(
				"/home/registration/5/:actionToken",
				{
					action: "home.constregistration"
				}
			)
			.when(
				"/home/registration/5",
				{
					action: "home.constregistration"
				}
			)
			.when(
				"/dashboard",
				{
					action: "dashboard.home"
				}
			)
			.when(
				"/dashboard/providerprofile",
				{
					action: "dashboard.providerprofile"
				}
			)
			.when(
				"/dashboard/providerprofileedit",
				{
					action: "dashboard.providerprofileedit"
				}
			)
			.when(
				"/dashboard/providerbusinessprofile",
				{
					action: "dashboard.providerbusinessprofile"
				}
			)
			.when(
				"/dashboard/providerbusinessprofileedit",
				{
					action: "dashboard.providerbusinessprofileedit"
				}
			)
			.when(
				"/dashboard/clientbusinessprofile",
				{
					action: "dashboard.clientbusinessprofile"
				}
			)
			.when(
				"/dashboard/clientbusinessprofileedit",
				{
					action: "dashboard.clientbusinessprofileedit"
				}
			)
			.when(
				"/dashboard/employeeprofile",
				{
					action: "dashboard.employeeprofile"
				}
			)
			.when(
				"/dashboard/employeeprofileedit",
				{
					action: "dashboard.employeeprofileedit"
				}
			)
			.when(
				"/dashboard/consultantprofile",
				{
					action: "dashboard.consultantprofile"
				}
			)
			.when(
				"/dashboard/consultantprofileedit",
				{
					action: "dashboard.consultantprofileedit"
				}
			)
			.when(
				"/dashboard/manageaccount",
				{
					action: "dashboard.manageaccount"
				}
			)
			.when(
				"/dashboard/createaccount",
				{
					action: "dashboard.createaccount"
				}
			)
			.when(
				"/dashboard/worksystem",
				{
					action: "dashboard.worksystem"
				}
			)
			.when(
				"/dashboard/caselist",
				{
					action: "dashboard.caselist"
				}
			)
			.when(
				"/dashboard/logout",
				{
					action: "dashboard.logout"
				}
			)
			.otherwise(
				{
					redirectTo: "/home"
				}
			)
		;

	}
);

angular.module('scrollApp.directives', []).
directive('smoothly', function() {
  return function(scope, elm, attr) {
      elm.smoothScroll({offset: -35});
  };
}).
directive('stickyTop', function() {
  return function(scope, elm, attr) {
    // This simply toggles the sticky class when a wrapper for the
    // target element is scrolled past a specified offset.
    elm.waypoint(function(event, direction) {
      elm.toggleClass('sticky', direction === "down");
    }, { offset: 0 });
  };
}).
directive('stickyMenuTop', function() {
  return function(scope, elm, attr) {
    // This simply toggles the sticky class when a wrapper for the
    // target element is scrolled past a specified offset.
    elm.waypoint(function(event, direction) {
      elm.toggleClass('stickyMenu', direction === "down");
    }, { offset: 35 });
  };
});

eServe.directive('ngEnter', function() {
    return function(scope, element, attrs) {
    	element.bind('focusout', function(e) {
    		if( scope.model != "" ) {
    			scope.$apply(attrs.ngEnter);
    		}
    		else
    		{
    			attrs.$$element.css('border','1px solid red');
    		}
    		$('.navbar-fixed-bottom').css('display','block');
        });
    };
});  

eServe.directive('emailVerify', function($http) {
    return function(scope, element, attrs) {
    	element.bind('focusout', function(e) {
    		var emailRejex = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/;
    		if( emailRejex.test(this.value) == true ) {
    			$http({url: "../../accountmanagement-r-web/eServe/registrationread/verifyemail", method: "GET", headers: {'Content-type': 'application/json', 'emailId': this.value }  }).success(function (resp) {
    				$('#emailverify').css('display','none');
    	        }).error(function (resp) {
    	        	$('#emailverify').css('display','block');
    	        });
    		}
        });
    };
}); 


eServe.directive('inlineText', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentText.html',
        scope: {
            model: '=' 
        }
    };
});

eServe.directive('inlineTextUsername', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentUsernameText.html',
        scope: {
            model: '=' 
        }
    };
});

eServe.directive('inlineTextTitle', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentTitleText.html',
        scope: {
            model: '=' 
        }
    };
});

eServe.directive('inlineTextarea', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentTextarea.html',
        scope: {
            model: '=' 
        }
    };
});

eServe.directive('inlineTextAddress', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentAddressLine1Text.html',
        scope: {
            model: '=' 
        }
    };
});
eServe.directive('inlineTextAddress2', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentAddressLine2Text.html',
        scope: {
            model: '=' 
        }
    };
});
eServe.directive('inlineTextAddress3', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentAddressLine3Text.html',
        scope: {
            model: '=' 
        }
    };
});
eServe.directive('inlineTextAddresspin', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentAddressPinText.html',
        scope: {
            model: '=' 
        }
    };
});
eServe.directive('inlineTextAddressstate', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentAddressStateText.html',
        scope: {
            model: '=' 
        }
    };
});

eServe.directive('inlineTextAddresscountry', function() {
    return {
        restrict: 'E',
        // can be in-lined or async loaded by xhr
        // or inlined as JS string (using template property)
        templateUrl: 'componentAddressCountryText.html',
        scope: {
            model: '=' 
        }
    };
});

eServe.directive('onKeyup', function() {
    return function(scope, elm, attrs) {
        elm.bind('keypress', function(evt) {
            //if no key restriction specified, always fire
            if (evt.which != 13 && evt.target.value.length == 3) {
            	scope.$apply(attrs.onKeyup);
            } else if(evt.which == 13) {
            	scope.subscriberIdGlobal = subscriberId;
            	$(".chat-log").animate({ scrollTop: $(".chat-log").get(0).scrollHeight}, "slow");
            	evt.preventDefault();
            }
        });
    };
});
eServe.directive('onBlur', function() {
    return function(scope, elm, attrs) {
        elm.bind('blur', function(evt) {
            //if no key restriction specified, always fire
            
            	scope.$apply(attrs.onBlur);
            
        });
    };
});
eServe.directive('onFoucs', function() {
    return function(scope, elm, attrs) {
        elm.bind('focus', function(evt) {
            //if no key restriction specified, always fire
            
        	if(evt.target.value.length > 3) {
        	
            	scope.$apply(attrs.onFocus);
        	}
            
        });
    };
});

// Service for chat , to make communication between different controllers
	

eServe.factory('chatStatusData', function(){
	return {
		count : 0,
		show :false
		
	}
});

/*eServe.directive('xeditable', function($timeout) {
    return {
        restrict: 'A',
        require: "ngModel",
        link: function(scope, element, attrs, ngModel) {
            var loadXeditable = function() {
                angular.element(element).editable({
                    display: function(value, srcData) {
                        ngModel.$setViewValue(value);
                        scope.$apply();
                    }
                });
            };
            $timeout(function() {
                loadXeditable();
            }, 10);
        }
    };
});*/