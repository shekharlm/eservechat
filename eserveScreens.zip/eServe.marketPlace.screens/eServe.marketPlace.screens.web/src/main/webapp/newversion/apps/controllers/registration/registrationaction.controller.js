	
(function( ng, app ){
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        this.localStorageService = localStorageService;
        this.scope.userEmailId = JSON.parse(localStorageService.get('signupData')).emailId;
        //../../accountmanagement-r-web/eServe/registrationread/populatebasicinfo
        this.ajax({url: "../../accountmanagement-r-web/eServe/registrationread/populatebasicinfo", method: "GET", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  } }).success(function (resp, $scope) {
        	$rootScope.basicInfo = resp;
        	$rootScope.basicInfo.userContacts = [
                 {
                     "id": "",
                     "contactNumber": "",
                     "contactNumberCode": "",
                     "contactType": "Phone",
                     "userCompaniesId": 0,
                     "user": null
                 }
             ];
        	//$rootScope.basicInfo.userContacts[0].contactNumberCode = "";
        	//$rootScope.basicInfo.userContacts[0].countryName = JSON.parse(localStorageService.get('signupData')).country.countryName;
        }).error(function (resp) {
    		alert(resp);
        });
        
        this.ajax({url: "../../accountmanagement-r-web/eServe/profiles/getindustrytypes", method: "GET", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  } }).success(function (resp, $scope) {
        	$rootScope.industryType = resp;
        }).error(function (resp) {
        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
        });
        
       this.scope.regData = {
    		   "profileTypeId": "1"
       };
        $scope.$watch('regData.profileTypeId', function(value) {
        	if( value == 1 )
        	{
        		$http({url: "data/provRegData.json", method: "GET"}).success(function (resp, $scope) {
        			$rootScope.providerInfo = resp;
                });
        	} else if( value == 2 ) {
        		$http({url: "data/providerbusinessprofile.json", method: "GET"}).success(function (resp, $scope) {
        			$rootScope.providerBusinessInfo = resp;
                });
        	}
        });
        
             
        
    	$scope.getAccountSelectionId = function() {
    		 return $scope.regData.profileTypeId;   
    	};
    	
        this.ajax({url: "data/CountryCodes.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.countryList = resp;
        });
        //this.scope.regData.firstName = JSON.parse(localStorageService.get('signupData')).displayName.split(' ')[0];
        //this.scope.regData.lastName = JSON.parse(localStorageService.get('signupData')).displayName.split(' ')[1];
       
        
        
		this.scope.succesPPBRegCntrl = ng.bind( this, this.succesPPBRegCntrl );
		this.scope.succesPPBRegSaveCntrl = ng.bind( this, this.succesPPBRegSaveCntrl );
				
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	succesPPBRegCntrl: function() {
        		//this.scope.regData.skills.skills = $('#listOfSkills').tokenInput("get");
        		this.scope.basicInfo.userContacts[0].contactNumber = this.scope.basicInfo.userContacts[0].contactNumberCode + this.scope.basicInfo.userContacts[0].contactNumber;
        		delete this.scope.basicInfo.userContacts[0].contactNumberCode;
        		delete this.scope.basicInfo.userContacts[0].countryName;
        		if( this.scope.regData.profileTypeId == "1" ) {
        			//../../accountmanagement-w-web/eServe/RegistrationWrite/updateuser
        			this.ajax({url: "../../accountmanagement-w-web/eServe/RegistrationWrite/updateuser", method: "POST", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(this.scope.basicInfo) }).success(function (resp) {
        				alert('Basic Info Saved Successfully');
        				//../../accountmanagement-w-web/eServe/profiles/createproviderprofile
        				
    		        }).error(function (resp) {
    		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
    		        });	
        			this.ajax({url: "../../accountmanagement-w-web/eServe/profiles/createproviderprofile", method: "PUT", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(this.scope.providerInfo) }).success(function (resp) {
        				
        				alert('Provider Profile Info Saved Successfully');
        			
    		        }).error(function (resp) {
    		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
    		        });
        			
        			var userHasSkills = [];
          			 for( var sk = 0; sk < $("#listOfSkills").tokenInput('get').length; sk++ )
          			{
          				 userHasSkills.push({
          				        "id": "",
          				        "additionalComments": null,
          				        "relevantExp": 0,
          				        "skillId": $("#listOfSkills").tokenInput('get')[sk].id,
          				        "userId": "",
          				        "skill": null,
          				        "user": null,
          				        "userSkillRatings": []
          				    });
          			}
          			this.ajax({url: "../../accountmanagement-w-web/eServe/skills/saveuserskills", method: "PUT", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(userHasSkills) }).success(function (resp) {
          				
          					alert('Skills Info Saved Successfully');
          					alert('Thanks for Registration...!!! Welcome to eServe');
          					$("#regPPBCntrl").trigger('click');
      		        	}).error(function (resp) {
      			        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
      			        });	
        				
        			
        		}else if( this.scope.regData.profileTypeId == "2" ) {
        		
        			this.ajax({url: "../../accountmanagement-w-web/eServe/RegistrationWrite/updateuser", method: "POST", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(this.scope.basicInfo) }).success(function (resp) {
    					alert('Basic Info Saved Successfully');
    					//../../accountmanagement-w-web/eServe/profiles/createproviderbusinessprofile
    					
    		        }).error(function (resp) {
    		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
    		        });
    				
    				this.ajax({url: "../../accountmanagement-w-web/eServe/profiles/createproviderbusinessprofile", method: "PUT", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(this.scope.providerBusinessInfo) }).success(function (resp) {
    					
    					alert('Provider Business Profile Info Saved Successfully');
    					alert('Thanks for Registration...!!! Welcome to eServe');
    					$("#regPPBCntrl").trigger('click');
    		        }).error(function (resp) {
    		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
    		        });	
        			
        			
        		}
        	}
        	
        };
 
		// Define the Controller as the constructor function.
    app.controller( "registration.controller", Controller );
})( angular, eServe );