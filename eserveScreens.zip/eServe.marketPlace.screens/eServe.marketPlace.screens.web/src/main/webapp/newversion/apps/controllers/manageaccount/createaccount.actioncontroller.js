
(function( ng, app ){
	
	"use strict";
	
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
		this.scope = $scope;
		this.ajax = $http;
		this.scope.invitationsentto = true;
		this.ajax({url: "testData/createEmployee.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.createAccountInfo = resp;
        });
		
		this.scope.getInvitationSentTo = function() {
			return $scope.invitationsentto;
		};
		
		$scope.$watch('invitationsentto', function(value) {
			$scope.invitationsentto = value;
		});
		
		this.scope.createAccountUserCntrl = ng.bind( this, this.createAccountUserCntrl );
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
        		createAccountUserCntrl: function() {
        			this.ajax({url: "../../accountmanagement-w-web/eServe/profiles/createemployeeprofile", method: "PUT", data: JSON.stringify(this.scope.createAccountInfo), headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId, 'companyId' : this.scope.companyId  } }).success(function (resp) {
        				$('#createAccountNavCntrl').trigger('click');
        			}).error(function (resp) {
    		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
    		        });
        		}
        // I handle the submit event on the form.
        };
 
		// Define the Controller as the constructor function.
    app.controller( "createaccount.adminController", Controller );
})( angular, eServe );