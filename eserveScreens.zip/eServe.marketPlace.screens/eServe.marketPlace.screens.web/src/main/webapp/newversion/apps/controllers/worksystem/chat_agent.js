function acceptClient(response) {
	openChat(response);
/*	broadcastData.subscriberId = response.message.chatId;
	broadcastData.messageType = "agent:accept"; 
	postMsg.author.firstName = localStorage["ls.loggedUserName"];
	postMsg.chatId = response.message.chatId;
	postMsg.messageTxt= " is accepted";
	broadcastData.message = postMsg;
	 var uuid =atmosphereUtils.requests.get("/agents/"+subscriberId).getUUID();
	$.get("http://"+hostAddress+":8080/eserve.worksystem.service.chat-web/chatservice/subscribe/session/addresource/"+uuid+"/"+response.message.chatId,
			function(msg){
		post(broadcastData);
	});
	atmosphereUtils.initRequest(response.message.chatId);
	post(broadcastData);*/
}