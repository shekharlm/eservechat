	
(function( ng, app ){
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        this.localStorageService = localStorageService;
        var actToken = window.location.href.split('/').pop();
        this.ajax({url: "data/consultantRegData.json", method: "GET", headers: {'Content-type': 'application/json', 'activationToken':actToken } }).success(function (resp, $scope) {
         	$rootScope.constBasicInfo = resp;
         	$rootScope.constBasicInfo.user.userContacts = [
   	                                                    {
 	                                                       "id": "",
 	                                                       "contactNumber": "",
 	                                                       "contactNumberCode": "",
 	                                                       "contactType": "Phone",
 	                                                       "userCompaniesId": 0,
 	                                                       "user": null
 	                                                   }
 	                                               ];
         }).error(function (resp) {
	        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
	        });
        
    	$scope.getAccountSelectionId = function() {
    		 return $scope.constregData.accountType;   
    	};
    	
        this.ajax({url: "data/CountryCodes.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.countryList = resp;
        });
        this.ajax({url: "data/consultantSendJson.json", method: "GET"}).success(function (resp, $scope) {
        	$scope.consultantSendJson = resp;
        });
        
		this.scope.succesConstRegCntrl = ng.bind( this, this.succesConstRegCntrl );
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	succesConstRegCntrl: function() {
        		this.scope.constBasicInfo.user.userContacts[0].contactNumber = this.scope.constBasicInfo.user.userContacts[0].contactNumberCode + this.scope.constBasicInfo.user.userContacts[0].contactNumber;
        		delete this.scope.constBasicInfo.user.userContacts[0].contactNumberCode;
        		this.scope.consultantSendJson.company = this.scope.constBasicInfo.company;
        		this.scope.consultantSendJson.user = this.scope.constBasicInfo.user;
        		this.ajax({url: "data/success.json", method: "POST", headers: {'Content-type': 'application/json'}, data: JSON.stringify(this.scope.consultantSendJson) }).success(function (resp) {
    				alert('Basic Info Saved Successfully');
    				alert('Thanks for Registration...!!! Welcome to eServe');
    				$('#contRegCntrl').trigger('click');
		        }).error(function (resp) {
		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
		        });	
    			
        	}
        };
 
		// Define the Controller as the constructor function.
    app.controller( "constregistration.controller", Controller );
})( angular, eServe );