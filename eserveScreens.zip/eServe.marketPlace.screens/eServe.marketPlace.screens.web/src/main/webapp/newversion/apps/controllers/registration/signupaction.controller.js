	
(function( ng, app ){
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        this.localStorageService = localStorageService;
		this.scope.signupData = {
				"displayName" : "",
				"emailId" : "",
				"password" : "",
				"country" : {"id" : "198" , "countryName": "United States"},
				"profileTypeId" :"1"
			};

		this.scope.succesSignupCntrl = ng.bind( this, this.succesSignupCntrl );
		this.ajax({url: "data/CountryList.json", method: "GET"}).success(function (resp, $scope) {
			$rootScope.countriesList = resp;
        });
		
		$scope.$watch('signupData.country.id', function(name) {
			$scope.signupData.country.countryName = $("#countrySelection option:selected").text();
		});
		
		
		
		if( this.localStorageService.get('empInvitationData') != undefined && this.localStorageService.get('empInvitationData') != null ) {
			this.scope.empSignup = JSON.parse(localStorageService.get('empInvitationData')).status;
			this.scope.signupData.emailId = JSON.parse(localStorageService.get('empInvitationData')).emailId;
			this.scope.signupData.virtualAccountId = JSON.parse(localStorageService.get('empInvitationData')).virtualAccountId;
			this.scope.signupData.profileTypeId = "4";
			this.scope.signupData.basicProfileType = "4";
			$('.accountSelection').hide();
		}
			
		
		
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	succesSignupCntrl: function() {
        		this.localStorageService.add('signupData',JSON.stringify(this.scope.signupData));
        		if(this.scope.signupData.profileTypeId == "4" ) {
        			this.localStorageService.add('userEmailId',this.scope.signupData.emailId);
        			this.ajax({url: "../../accountmanagement-w-web/eServe/profiles/profilesignup", method: "PUT", data: JSON.stringify(this.scope.signupData) }).success(function (resp) {
        				
        				
        				$("#signupCntrl").trigger('click');
        				
        				//localStorageService.set('signupData',this.scope.signupData);
        				/*if( resp.status.toLowerCase() == SUCCESS )
    					{
        					localStorageService.set('signupData',this.scope.signupData);
    						alert(JSON.stringify(this.scope.signData));
    			        
    					}else if( resp.status.toLowerCase() == FAILED )
    					{
    						alert("You can't able to signup to eserve. Please try later.");
    					}*/
    		        }).error(function (resp) {
    		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
    		        });
        		}else
        		{
        			//console.log(JSON.parse(this.scope.signupData));
            		//../../accountmanagement-w-web/eServe/RegistrationWrite/newuserregistration
        			this.localStorageService.add('userEmailId',this.scope.signupData.emailId);
        			this.ajax({url: "../../accountmanagement-w-web/eServe/RegistrationWrite/newuserregistration", method: "PUT", data: JSON.stringify(this.scope.signupData) }).success(function (resp) {
        				
        				
        				$("#signupCntrl").trigger('click');
        				
        				//localStorageService.set('signupData',this.scope.signupData);
        				/*if( resp.status.toLowerCase() == SUCCESS )
    					{
        					localStorageService.set('signupData',this.scope.signupData);
    						alert(JSON.stringify(this.scope.signData));
    			        
    					}else if( resp.status.toLowerCase() == FAILED )
    					{
    						alert("You can't able to signup to eserve. Please try later.");
    					}*/
    		        }).error(function (resp) {
    		        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
    		        });
        		}
        		
        	}
        };
 
		// Define the Controller as the constructor function.
    app.controller( "signup.Controller", Controller );
})( angular, eServe );