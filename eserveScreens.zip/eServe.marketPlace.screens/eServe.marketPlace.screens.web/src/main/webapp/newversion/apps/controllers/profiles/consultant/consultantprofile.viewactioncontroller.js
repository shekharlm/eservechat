
(function( ng, app ){
	
	"use strict";
	
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        $scope.panes = [
	         { title:"Job History", content:"Jobs Done...!!" },
	         { title:"Portfolio", content:"About my Work" }
	       ];
        
        this.ajax({url: "data/consultantprofile.json", method: "GET"}).success(function (resp, $scope) {
        	if( $rootScope.consultantData == undefined ) {
        		$rootScope.consultantData = resp;
        	}        	
        	localStorageService.add('profileInfo', resp);
        });
        
    	$scope.getAccountSelectionId = function() {
    		 return $scope.consultantData.accountType;   
    	};
    	
        this.ajax({url: "data/CountryCodes.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.countryList = resp;
        });
        this.ajax({url: "data/CountryCodes.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.stateList = resp;
        });
               
		this.scope.succesconsultantDataCntrl = ng.bind( this, this.succesconsultantDataCntrl );
		
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	succesconsultantDataCntrl: function() {
        		
    			this.ajax({url: "", method: "POST", data: JSON.stringify(this.scope.consultantData) }).success(function (resp) {
    				if( resp.status.toLowerCase() == SUCCESS )
					{
						alert(JSON.stringify(this.scope.signData));
			        
					}else if( resp.status.toLowerCase() == FAILED )
					{
						alert("You can't able to signup to eserve. Please try later.");
					}
		        });	
        	}
        };
 
		// Define the Controller as the constructor function.
    app.controller( "consultantprofile.viewController", Controller );
})( angular, eServe );

