/*Opening a chat window based on the id*/
function openChat(response){	
	var agentSubscriberId=response.message.chatId;
	var url="http://localhost:8080/eServe.marketPlace.screens.web/ChatWindowLayout/chat_agent_NEW.html?subscriberId="+agentSubscriberId;
	 $("#iframe").html('<iframe name="ChatFrame" width="350px" scrolling="no" height="400px" frameborder="0" scrolling="no" draggable="true" style="float:right;bottom: 10;position: absolute;right: 0;display:true" src='+url+'></iframe>');
}

/* Add message to chat window  */

function addMessage(response) {
	 var scope = angular.element(".chat-window-overlay").scope();	
	 scope.$apply(function() {
		  
		   scope.messages.push(response.message);	
		   scope.messageStatus ={};
	    });
	 $(".chat-log").animate({ scrollTop: $(".chat-log").get(0).scrollHeight}, "slow");
}


function chatStatusMessage(response) {
	var scope = angular.element(".chat-window-overlay").scope();
	scope.$apply(function(){
		scope.messageStatus = response.message;
	});
}

function removeStatusMessage(response) {
	var scope = angular.element(".chat-window-overlay").scope();
	response.message.author.firstName = "";
	scope.$apply(function(){
		scope.messageStatus = response.message;
	});
}
