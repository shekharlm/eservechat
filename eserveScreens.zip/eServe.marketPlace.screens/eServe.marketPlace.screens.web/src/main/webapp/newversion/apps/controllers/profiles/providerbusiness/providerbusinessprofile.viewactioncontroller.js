
(function( ng, app ){
	
	"use strict";
	
	function Controller( $scope, $http, $rootScope, localStorageService ) {
		// Store the scope so we can reference it in our
        // class methods
        this.scope = $scope;
        this.ajax = $http;
        this.localStorageService = localStorageService;
        if ( JSON.parse(localStorageService.get('signupData')) != null ) {
        	if( JSON.parse(localStorageService.get('signupData')).emailId != undefined && JSON.parse(localStorageService.get('signupData')).emailId != null ) {
        		this.scope.userEmailId = JSON.parse(localStorageService.get('signupData')).emailId;
        	}
        }else {
        	this.scope.userEmailId = localStorageService.get('userEmailId');
        }
        $scope.panes = [
	         { title:"Job History", content:"Jobs Done...!!" },
	         { title:"Portfolio", content:"About my Work" }
	       ];
        
        //testData/providerBusinessProfile.json
        //../../accountmanagement-r-web/eServe/profiles/getproviderbusinessprofile
        this.ajax({url: "../../accountmanagement-r-web/eServe/profiles/getproviderbusinessprofile", method: "GET", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }}).success(function (resp, $scope) {
        	if( $rootScope.providerBusinessData == undefined ) {
        		$rootScope.providerBusinessData = resp;
        	}        	
        }).error(function (resp) {
        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
        });
        
    	    	
        this.ajax({url: "data/CountryCodes.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.countryList = resp;
        });
        this.ajax({url: "data/CountryCodes.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.stateList = resp;
        });
        this.ajax({url: "testData/providerJobList.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.providerJobList = resp;
        });
        this.ajax({url: "testData/providerPortfolio.json", method: "GET"}).success(function (resp, $scope) {
        	$rootScope.portfolioData = resp;
        });
        
        this.scope.editProfile = function() {
        	for( var ed = 0; ed < $('inline-textarea span').length; ed++ ) {
        		$('inline-textarea span').trigger('click');
        		$('.navbar-fixed-bottom').css('display','block');
        	}
        	
        };
        
        this.scope.cancelProfileSave = function() {
        	$('.navbar-fixed-bottom').css('display','none');
        };
        this.scope.addressEdit = function() {
        	$('.addressEdit').css('display','none');
        	if( $scope.providerBusinessData.company.companyHasAddresses == null || $scope.providerBusinessData.company.companyHasAddresses.length == 0) {
        		$scope.providerBusinessData.company.companyHasAddresses = [
        		                 	                                      {
        		                 	                                          "id": "",
        		                 	                                          "address": {
        		                 	                                              "id": "",
        		                 	                                              "addressLine1": "",
        		                 	                                              "addressLine2": "",
        		                 	                                              "addressLine3": "",
        		                 	                                              "isActive": 0,
        		                 	                                              "pin": "",
        		                 	                                              "country": {
        		                 	                                                  "id": "84",
        		                 	                                                  "companyName": ""
        		                 	                                              },
        		                 	                                              "state": {
        		                 	                                                  "id": "12",
        		                 	                                                  "stateName": ""
        		                 	                                              }
        		                 	                                          },
        		                 	                                          "addressType": {
        		                 	                                              "id": "",
        		                 	                                              "addressType": ""
        		                 	                                          },
        		                 	                                          "company": {
        		                 	                                              "id": ""
        		                 	                                          }
        		                 	                                      }
        		                 	                                  ];
        	}
        	
        	$('.addressEditable').css('display','block');
        	
        	setTimeout(function () {
	        	$('inline-text-address2 span').trigger('click');
	        	$('inline-text-address3 span').trigger('click');
	        	$('inline-text-addresspin span').trigger('click');
	        	$('inline-text-addressstate span').trigger('click');
	        	$('inline-text-addresscountry span').trigger('click');
	        	$('inline-text-address span').trigger('click');
        	}, 800);
        	$('.navbar-fixed-bottom').css('display','block');
        };
               
        this.scope.successSavePBCntrl = ng.bind( this, this.successSavePBCntrl );
		
		
		// Return this object reference.
		return( this );
	}
	
	// Define the class methods on the controller.
        Controller.prototype = {
 
        // I handle the submit event on the form.
        	successSavePBCntrl: function() {
        		var inputValidation = true;
        		var textareaValidation = true;
        		
        		inputValidation = $('input:visible').each(function(i, obj) {
        			var currentObj = $(obj)[0];
        			if( currentObj.style.border == "1px solid red") {

        				return false; //this is equivalent of 'continue' for jQuery loop
        			}
        		});
        		textareaValidation = $('textarea:visible').each(function(i, obj) {
        			var currentObj = $(obj)[0];
        			if( currentObj.style.border == "1px solid red") {

        				return false; //this is equivalent of 'continue' for jQuery loop
        			}
        		});
        		
        		if( inputValidation.length == 0 && textareaValidation.length == 0 ) {
	        		this.ajax({url: "../../accountmanagement-w-web/eServe/profiles/updateproviderbusinessprofile", method: "POST", headers: {'Content-type': 'application/json', 'emailId': this.scope.userEmailId  }, data: JSON.stringify(this.scope.providerBusinessData) }).success(function (resp) {
	    				
	    				alert('Provider Business Profile Info Saved Successfully');
	    			
			        }).error(function (resp) {
			        	$.each( JSON.parse(localStorage["ls.errorCodeList"]), function(k,v) {  $.each( v, function(k1,v1) { if( v1 == resp ) { alert(v.value);   }  });         });
			        });
        		}else {
        			alert('Please fill the required fields');
        		}
        	}
        };
 
		// Define the Controller as the constructor function.
    app.controller( "providerbusinessprofile.viewController", Controller );
})( angular, eServe );

