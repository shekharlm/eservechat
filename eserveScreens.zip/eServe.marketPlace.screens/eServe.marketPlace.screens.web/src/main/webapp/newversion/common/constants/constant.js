
/**** Error Code ****/

var ES_AM_W_001 = "User is unique";
var ES_AM_PR_R_006 = "No Result Found Exception.";
var ES_AM_PR_R_005 = "User not found.";
var ES_AM_PR_R_004 = "Persistence error.";
var ES_AM_PR_R_002 = "Invitation has expired.";
var ES_AM_PR_R_001 = "User has not invited with this activation token";
var ES_AM_PR_R_003 = "User invitation has already accepted.";
var ES_AM_R_001 = "Not Found";
var ES_AM_PR_W_001 = "User account has not activated.";
var ES_AM_PR_R_007 = "Updation failed.";
var ES_AM_PR_W_002 = "Profile creation failed.";
var ES_AM_PR_W_003 = "User should not have more than one basic profile.";
var ES_AM_PR_R_008 = "User has already registered with this email.";
var ES_AM_PR_R_010 = "User account has already activated successfully.";
var ES_AM_PR_R_009 = "User invitation has expired.";
var ES_AM_PR_R_011 = "User has no skills.";
var ES_AM_PR_R_012 = "Authentication failed.";
var ES_AM_PR_R_013 = "User account closed by admin.";
var ES_AM_PR_R_014 = "User account locked by admin.";
var ES_AM_PR_R_016 = "You have not registered to eserve, please register to eserve and click on the link sent to your mail to create profile.";
var ES_AM_PR_R_017 = "Dozer mapping exception.";


/**** Constant Variables ****/

var PROFILETYPE1 = "provider";
var PROFILETYPE2 = "providerbusiness";
var PROFILETYPE3 = "clientbusiness";
var PROFILETYPE4 = "employee";
var PROFILETYPE5 = "consultant";
