angular.module('ErrorCodes', []).
  factory('errorcodes', function($scope, $http, $rootScope, $window) {
	  $http({url: "common/constants/errorcode.json", method: "GET", headers: {'Content-type': 'application/json' }  }).success(function (resp) {
			console('Error Code List');
      });
});