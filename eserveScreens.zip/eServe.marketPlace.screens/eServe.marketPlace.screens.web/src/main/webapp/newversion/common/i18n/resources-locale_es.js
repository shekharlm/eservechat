[
    {
        "key": "_WelcomeHeader_",
        "value": "Welcome to eServe..",
        "description": "Login to eServe system by different Channels"
    },
    {
        "key": "_CompleteRegistrationHeader_",
        "value": "Complete Your Registration",
        "description": "To Complete the registration title"
    },
    {
        "key": "_BasicInfoHeader_",
        "value": "Basic Info",
        "description": "Getting Basic Information of User"
    },
    {
        "key": "_FirstName_",
        "value": "First Name",
        "description": "First Name of the User"
    },
    {
        "key": "_LastName_",
        "value": "Last Name",
        "description": "Last Name of the user"
    },
    {
        "key": "_Gender_",
        "value": "Gender",
        "description": "Gender of User"
    },
    {
        "key": "_GenderMale_",
        "value": "Male",
        "description": "Male gender"
    },
    {
        "key": "_GenderFemale_",
        "value": "Female",
        "description": "Female gender"
    },
    {
        "key": "_ChooseAnyOneError_",
        "value": "Please choose one.",
        "description": "Choose any of the checkbox/radio button"
    },
    {
        "key": "_PhoneNumber_",
        "value": "Phone Number",
        "description": "Users Phone Number title/Label"
    },
    {
        "key": "_CompanyInfoHeader_",
        "value": "Company Info",
        "description": "Company Info Header"
    },
    {
        "key": "_ProfileInfo_",
        "value": "Profile Info",
        "description": "Profile Info Header"
    },
    {
        "key": "_Title_",
        "value": "Title",
        "description": "Title Label"
    },
    {
        "key": "_Overview_",
        "value": "Overview",
        "description": "Overview Label"
    },
    {
        "key": "_CompanyName_",
        "value": "Company Name",
        "description": "Company Name label"
    },
    {
        "key": "_TagName_",
        "value": "Tag Name",
        "description": "Tag Name Label"
    },
    {
        "key": "_IndustryType_",
        "value": "Industry Type",
        "description": "Industry Type Label"
    },
    {
        "key": "_CompanyOverview_",
        "value": "Company Overview",
        "description": "Company Overview Label"
    },
    {
        "key": "_ServiceDescription_",
        "value": "Service Description",
        "description": "Service Description Label"
    },
    {
        "key": "_MinimumHourlyRate_",
        "value": "Minimum Hourly Rate",
        "description": "Minimum Hourly Rate Label"
    },
    {
        "key": "_PaymentTerms_",
        "value": "Payment Terms",
        "description": "Payment Terms Label"
    },
    {
        "key": "_CompanyeMailId_",
        "value": "Company eMail Id",
        "description": "Company eMail Id Label"
    },
    {
        "key": "_Keywords_",
        "value": "Keywords",
        "description": "Keywords Label"
    },
    {
        "key": "_YourSkills_",
        "value": "Your skills",
        "description": "Your skills Label"
    },
    {
        "key": "_CompanyPhoneNumber_",
        "value": "Company Phone Number",
        "description": "Company Phone Number Label"
    },
    {
        "key": "_RegistrationDoneButton_",
        "value": "Registration Done",
        "description": "Registration Done Label"
    },
    {
        "key": "_SaveChangesButton_",
        "value": "Save Changes",
        "description": "Save Changes Button"
    },
    {
        "key": "_ExistingUsersTitle_",
        "value": "Existing users",
        "description": "Existing users title"
    },
    {
        "key": "_LoginHeader_",
        "value": "Login >>",
        "description": "Login Header Label"
    },
    {
        "key": "_SocialNetworkLoginTitle_",
        "value": "Register or Login from your social network.",
        "description": "Login to eServe system by different Channels"
    },
    {
        "key": "_RegisterNewAccountHeader_",
        "value": "Register for a new account.",
        "description": "Register for a new account."
    },
    {
        "key": "_SignUpTitle_",
        "value": "Sign Up >>",
        "description": "Sign Up Label"
    },
    {
        "key": "_LatestUpdateHeader_",
        "value": "Latest Updates",
        "description": "Latest Update Header"
    },
    {
        "key": "_TrustedCertificationHeader_",
        "value": "Trusted by these & 100s of others",
        "description": "Trusted Certification by diff organization"
    },
    {
        "key": "_LoginTitle_",
        "value": "Log in",
        "description": "Login title label"
    },
    {
        "key": "_eMailId_",
        "value": "eMail Id",
        "description": "eMail Id Label"
    },
    {
        "key": "_Password_",
        "value": "Password",
        "description": "Password Label"
    },
    {
        "key": "_Country_",
        "value": "Country",
        "description": "Country Label"
    },
    {
        "key": "_AccountType_",
        "value": "Account type",
        "description": "Country Label"
    },
    {
        "key": "_ClientAccountType_",
        "value": "Client",
        "description": "Client Account type Label"
    },
    {
        "key": "_ProviderAccountType_",
        "value": "Provider",
        "description": "Provider Account type Label"
    },
    {
        "key": "_KeepMeLogged_",
        "value": "Keep me logged in.",
        "description": "Keep me logged in label"
    },
    {
        "key": "_ForgotPassword_",
        "value": "Forgot Password?",
        "description": "Forgot Password Label"
    },
    {
        "key": "_LoginButton_",
        "value": "Login",
        "description": "Login Button"
    },
    {
        "key": "_EditButton_",
        "value": "Edit",
        "description": "Edit Button"
    },
    {
        "key": "_NewUserSignUp_",
        "value": "New User Sign Up",
        "description": "New User Sign Up Label"
    },
    {
        "key": "_DisplayName_",
        "value": "Display Name",
        "description": "Display Name Label"
    },
    {
        "key": "_TermCondition_",
        "value": "I agree to the eServe Terms & Conditions and Privacy Policy",
        "description": "Agree the Term and condition of eServe while sign up"
    },
    {
        "key": "_SignupButton_",
        "value": "Signup",
        "description": "Sign up string"
    },
    {
        "key": "_IndividualAccountType_",
        "value": "Individual",
        "description": "Individual or Business Account type selection"
    },
    {
        "key": "_BusinessAccountType_",
        "value": "Business",
        "description": "Individual or Business Account type selection"
    },
    {
        "key": "_ProviderProfileAccountType_",
        "value": "Choose a your provider account type",
        "description": "Individual or Business Provider Account type selection"
    },
    {
    	"key": "_AddressHeader_",
        "value": "Contact Address Details",
        "description": "User address details"
    },
    {
    	"key": "_ProfileOverviewTabTile_",
        "value": "Overview",
        "description": "Profile overview tab title"
    },
    {
    	"key": "_ProfileJobHistoryTabTile_",
        "value": "Job History",
        "description": "Profile Job History tab title"
    },
    {
    	"key": "_ProfilePortfolioTabTile_",
        "value": "Portfolio",
        "description": "Profile Portfolio tab title"
    },
    {
    	"key": "_AddressLine1_",
        "value": "Address Line1",
        "description": "Profile Address Line1 label"
    },
    {
    	"key": "_AddressLine2_",
        "value": "Address Line2",
        "description": "Profile Address Line1 label"
    },
    {
    	"key": "_AddressLine3_",
        "value": "Address Line3",
        "description": "Profile Address Line3 label"
    },
    {
    	"key": "_State_",
        "value": "State",
        "description": "State Label"
    },
    {
    	"key": "_PinNumber_",
        "value": "Zip / Postal Code",
        "description": "Zip / Postal Code label"
    },
    {
    	"key": "_InvitationAccept_",
        "value": "Thanks for accepting the eServe invitation",
        "description": "Invitation acceptance"
    },
    {
    	"key": "_Yes_",
        "value": "Yes",
        "description": "Yes selection check box"
    },
    {
    	"key": "_No_",
        "value": "No",
        "description": "No selection check box"
    },
    {
        "key":"_Greeting_",
        "value":" Jagan Site localization example using the resource localization service",
        "description":"Home page greeting text"
    },
    {
        "key":"__CaseTitle__",
        "value":"Resource Localization Service",
        "description":"Home page title text"
    },
    {
        "key":"_HomeControllerTitle_",
        "value":"List Example",
        "description":"Home Pane Title"
    },
    {
        "key":"_HomeControllerBlob_",
        "value":"Now is the time for all good men to come to the aide of their country.",
        "description":"text example"
    },
    {
        "key":"_FormControllerTitle_",
        "value":"Form example",
        "description":"Add/Edit Person Form Title"
    },
    {
        "key":"_FirstNameLabel_",
        "value":"First Name",
        "description":"Label for first name field"
    },
    {
        "key":"_LastNameLabel_",
        "value":"Last Name",
        "description":"Label for last name field"
    },
    {
        "key":"_EMailLabel_",
        "value":"Email",
        "description":"Label for email field"
    },
    {
        "key":"_BioLabel_",
        "value":"Bio (tell us something about you) ",
        "description":"Label for biography field"
    },
    {
        "key":"_SaveButtonLabel_",
        "value":"Save",
        "description":"Label for Save button"
    },
    {
        "key":"_CancelButtonLabel_",
        "value":"Cancel",
        "description":"Label for Cancel button"
    },
    {
        "key":"_NameHeader_",
        "value":"Name",
        "description":"Person List Name Header"
    },
    {
        "key":"_EmailHeader_",
        "value":"Email",
        "description":"Person List Name Header"
    },
    {
        "key":"_BioHeader_",
        "value":"Biography",
        "description":"Person List Bio Header"
    },
    {
        "key":"__CaseTitleValue__",
        "value":"Need help with R2D2 configuration",
        "description":"Value for case title"
    }
    
]