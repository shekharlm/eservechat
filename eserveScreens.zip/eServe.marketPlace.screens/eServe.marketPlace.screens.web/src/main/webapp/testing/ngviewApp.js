var myApp = angular.module('myApp',[],function($routeProvider) {        
    
    $routeProvider
    //.when('/home',{templateUrl:'home.html'})
    .when('/appOne',{templateUrl:'../pages/profilepages/viewbasicinfo.jsp',controller:'oneCtrl'})
    .when('/appTwo',{templateUrl:'../pages/profilepages/viewprofileinfo.jsp'})
    //.otherwise({redirectTo:'/home'});
    
});
    
function oneCtrl($scope) {
    $scope.name = 'World';
}

