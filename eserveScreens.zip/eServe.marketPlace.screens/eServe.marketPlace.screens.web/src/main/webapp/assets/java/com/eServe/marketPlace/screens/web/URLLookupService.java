package com.eServe.marketPlace.screens.web;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;


@Path("/screen")
public class URLLookupService {

	private static Properties properties=new Properties();
	private static boolean logCreated;
	private static Logger log=Logger.getLogger(URLLookupService.class.getName());
	static{		
		try {
			properties.load(URLLookupService.class.getClassLoader().getResourceAsStream("UrlList.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.log(Level.SEVERE,"****************************************************");
			log.log(Level.SEVERE, "Properties Not Loaded");
			log.log(Level.SEVERE,"****************************************************");
			e.printStackTrace();
			logCreated=false;
		}
	}
	
	@GET
	@Path("/lookup/{key}")
	public String lookup(@PathParam(value="key") String key){
		if(!logCreated){
			return (String)properties.getProperty(key);
		}else{
			return "";			
		}
	}
}
