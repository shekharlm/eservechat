[
    {
        "key":"__CaseTitle__",
        "value":"Case Title",
        "description":"title of the case will come here"
    },
    {
        "key":"__CaseStatus__",
        "value":"Status",
        "description":"status of case"
    },
    {
        "key":"__CasePriority__",
        "value":"Priority",
        "description":"Home Pane Title"
    },
    {
        "key":"__CaseGroup__",
        "value":"Group",
        "description":"text example"
    },
    {
        "key":"__CaseAssigneeAgent__",
        "value":"Assignee Agent",
        "description":"Add/Edit Person Form Title"
    },
    {
        "key":"__CaseDescription__",
        "value":"Description",
        "description":"Label for first name field"
    },
    {
        "key":"__CaseLanguage__",
        "value":"Language",
        "description":"Label for last name field"
    },
    {
        "key":"__DirectCaseLink__",
        "value":"Direct Case Link(Copy)",
        "description":"Label for email field"
    },
    {
        "key":"__CaseDueDate__",
        "value":"Due Date",
        "description":"Label for biography field"
    },
    {
        "key":"__CaseLabels__",
        "value":"Labels",
        "description":"Label for Save button"
    },
    {
        "key":"__CaseTitleValue__",
        "value":"Need help with R2D2 configuration",
        "description":"Value for case title"
    }
    
]
