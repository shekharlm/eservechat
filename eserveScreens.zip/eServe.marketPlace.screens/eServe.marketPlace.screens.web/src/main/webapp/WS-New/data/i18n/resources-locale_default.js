[
    {
        "key":"_Greeting_",
        "value":" Jagan Site localization example using the resource localization service",
        "description":"Home page greeting text"
    },
    {
        "key":"__CaseTitle__",
        "value":"Resource Localization Service",
        "description":"Home page title text"
    },
    {
        "key":"_HomeControllerTitle_",
        "value":"List Example",
        "description":"Home Pane Title"
    },
    {
        "key":"_HomeControllerBlob_",
        "value":"Now is the time for all good men to come to the aide of their country.",
        "description":"text example"
    },
    {
        "key":"_FormControllerTitle_",
        "value":"Form example",
        "description":"Add/Edit Person Form Title"
    },
    {
        "key":"_FirstNameLabel_",
        "value":"First Name",
        "description":"Label for first name field"
    },
    {
        "key":"_LastNameLabel_",
        "value":"Last Name",
        "description":"Label for last name field"
    },
    {
        "key":"_EMailLabel_",
        "value":"Email",
        "description":"Label for email field"
    },
    {
        "key":"_BioLabel_",
        "value":"Bio (tell us something about you) ",
        "description":"Label for biography field"
    },
    {
        "key":"_SaveButtonLabel_",
        "value":"Save",
        "description":"Label for Save button"
    },
    {
        "key":"_CancelButtonLabel_",
        "value":"Cancel",
        "description":"Label for Cancel button"
    },
    {
        "key":"_NameHeader_",
        "value":"Name",
        "description":"Person List Name Header"
    },
    {
        "key":"_EmailHeader_",
        "value":"Email",
        "description":"Person List Name Header"
    },
    {
        "key":"_BioHeader_",
        "value":"Biography",
        "description":"Person List Bio Header"
    },
    {
        "key":"__CaseTitleValue__",
        "value":"Need help with R2D2 configuration",
        "description":"Value for case title"
    }
]
