	

    var requestMaps = null;
    var postMsg = {
            chatId : null,
            messageTxt : null,
            author : {
                    firstName:null,
                    lastName:null,
                    photoUrl:null
            },
            timeStamp : null
    };
    var broadcastData = {
            version : null,
            subscriberId : null,
            groupId : null,
            messageType : null,
            message : null
    };
    var atmosphereUtils;
    $(document).ready(function(){
              atmosphereUtils = new AtmosphereUtils();
    });
     
    var authors = new Array();
    var subscriberId = null;
    var action = null;
     
    function multiChat(response){
        var id = response.subscriberId;
        chatboxManager.addBox(id,
        {dest:null, // not used in demo
        title:response.message.author.firstName,
        first_name:response.message.author.firstName == null ?"":response.message.author.firstName,
        last_name:response.message.author.lastName == null ? "" : response.message.author.lastName
        //you can add your own options too
        });
    }
    Array.prototype.remove = function(el) {
            return this.splice(this.indexOf(el), 1);
    };
    function subscribeChat(subscriberId2) {
            subscriberId = subscriberId2;
            atmosphereUtils.initRequest(subscriberId,this.callback);
    }
     
    function agentRequest(subId) {
            subscriberId= subId;
            postMsg.messageTxt = " is requesting an agent.";
            broadcastData.messageType = "agent:request";
            broadcastData.subscriberId = subId;
            broadcastData.message = postMsg;
            atmosphereUtils.initRequest(subscriberId,this.callback);
            post(broadcastData);
    }
    function subscribeAgent() {
            temp = Math.floor(Math.random()*100001) + jQuery.now();
            subscriberId ="/agents/"+ temp;
            broadcastData.messageType = "agent:subscribe";
            broadcastData.subscriberId = temp;
            broadcastData.message = postMsg;
            atmosphereUtils.initRequest(subscriberId,this.callback);
            subscriberId = temp;
    }
     
    // jquery.atmosphere.response
    function callback(response) {
            // Websocket events.
            $.atmosphere.log('info', [ "response.state: " + response.state ]);
            $.atmosphere.log('info', [ "response.transport: " + response.transport ]);
            $.atmosphere.log('info', [ "response.status: " + response.status ]);
            if (response.transport != 'polling' && response.state == 'messageReceived') {
                    $.atmosphere.log('info', [ "response.responseBody: "
                                    + response.responseBody ]);
                    if (response.status == 200) {
                            displayChat(response.responseBody);
                    }
            }
    }
     
    function showItem(id) {
            $(id).show();
    }
    function hideItem(id) {
            $(id).hide();
    }
    function displayChat(data) {
            response = JSON.parse(data);
            color = "gray";
            datetime = new Date(response.message.time);
            name = response.message.author.firstName;
            msg = response.message.messageTxt;
     
            if (response.messageType.match("chat:status") != null
                            && (response.message.author.firstName != postMsg.author.firstName)) {
                    var temp = document.getElementById("chat-box-typing-"+response.subscriberId);
                    if (temp == null){
                            var e = document.createElement('div');
                    var p = document.createElement("p");
                    $(e).append(p);
                    if (response.message.author.firstName) {
                        var peerName = document.createElement("i");
                        $(peerName).text(response.message.author.firstName + " " + response.message.messageTxt);
                        p.appendChild(peerName);
                    }
                    $(e).addClass("ui-chatbox-typing");
                    $(e).attr("id","chat-box-typing-"+response.subscriberId);
                            $('#'+response.subscriberId).after(e);
                    }
                    else{
                            $("#chat-box-typing-"+response.subscriberId).show();
                    }
     
            } else if (response.messageType.match("chat:remove") != null
                            && (response.message.author.firstName != postMsg.author.firstName)) {
                    var temp = document.getElementById("chat-box-typing-"+response.subscriberId);
                    if(temp != null){
                            $("#chat-box-typing-"+response.subscriberId).hide();
                    }
            } else if (response.messageType.match("chat:post") != null) {
                    var temp = document.getElementById("chat-box-typing-"+response.subscriberId);
                    if(temp != null){
                            $("#chat-box-typing-"+response.subscriberId).hide();
                    }
                    $("#"+response.subscriberId).chatbox("option", "boxManager").addMsg(response.message.author.firstName, response.message.messageTxt);
            } else if (response.messageType.match("agent:request") != null) {
                    if (confirm(response.message.author.firstName + " " + response.message.messageTxt)) {
    //                      openChatWindow(response);
                            /** removing the chat display name form popup*/
                            multiChat(response);
                            broadcastData.subscriberId = subscriberId;
                            broadcastData.messageType = "agent:accept";
                            postMsg.chatId = response.subscriberId;
                            broadcastData.message = postMsg;
                            post(broadcastData);
                            //subscribeChat(response.subscriberId);
                    }
            } else if (response.messageType.match("agent:accept") != null) {
                    $(".ui-widget").remove();
                    multiChat(response);
            }
            displayTypingMessage();
    }
    function post(object) {
            var request = $.ajax({
                    url : 'http://localhost:8080/eserve.worksystem.service.chat-web/rest/subscribe/chat',
                    type : 'POST',
                    data : JSON.stringify(object),
                    contentType : "application/json; charset=utf-8",
            });
            request.fail(function(jqXHR, textStatus) {
                    alert("Request failed: " + textStatus);
            });
    }
    function setName(event) {
            if (event.keyCode == $.ui.keyCode.ENTER) {
                    temp = $.trim($(event.target).val());
                    if (temp.length > 0) {
                            postMsg.author.firstName = temp;
                            $('#authorName').text() + ' - ' + temp;
                            hideItem(event.target.id);
                            $('#authorName').text($('#authorName').text() + ' - ' + temp);
                            if($('#authorName').text().match("Client -") != null)
                            {
                                    broadcastData.groupId = "agents";
                                    agentRequest(atmosphereUtils.getSessionId());
                            }
                    }
            }
    }
    function setNameText(varName){
            if (varName.length > 0) {
                    postMsg.author.firstName = varName;
                    broadcastData.groupId = "agents";
                    agentRequest(Math.floor(Math.random()*1001)+jQuery.now());
                    return true;
            }
            else{
                    alert("Please enter display name ...");
                    return false;
            }
    }
    //This method will be called when enter is pressed in chat text box
    function chat(textItem,subId) {
     
            /*
             * if(event.keyCode != $.ui.keyCode.ENTER &&
             * (($(currentObject).val().length%4)==0) &&
             * ($(currentObject).val().length>4)){ sendProgress(); }
             */
            msg = $.trim($(textItem).val());
            if (msg.length > 0) {
                    postMsg.messageTxt = $(textItem).val();
                    postMsg.chatId = subId;
                    broadcastData.messageType = "chat:post";
                    broadcastData.message = postMsg;
                    broadcastData.subscriberId = subscriberId;
                    post(broadcastData);
                    $("#"+subId).chatbox("option", "boxManager").addMsg(postMsg.author.firstName, postMsg.messageTxt);
            }
    }
    function sendProgress(textItem,subId) {
            if (postMsg.author.firstName != "") {
                    broadcastData.messageType = "chat:status";
                    postMsg.messageTxt = "is typing ...";// $("#input").val();
                    postMsg.chatId = subId;
                    broadcastData.message = postMsg;
                    broadcastData.subscriberId = subscriberId;
                    post(broadcastData);
            }
    }
    function removeProgress(textItem,subId) {
            if (postMsg.author != "") {
                    broadcastData.messageType = "chat:remove";// $("#input").val();
                    postMsg.messageTxt = "";
                    postMsg.chatId = subId;
                    broadcastData.message = postMsg;
                    broadcastData.subscriberId = subscriberId;
                    post(broadcastData);
            }
    }
    function closeChat(subId){
            var req =requestMaps.get(subId);
            if (req != null){
                    req.close();
            }
    }
    function getTimeInHtml(datetime) {
                    var time = null;
                    var p = document.createElement("p");
                    var span = document.createElement("span");
                   
    /*      var time = "'<p><span style="'color:graytext'
                            + '">'
                            + author
                            + '</span> @ '
                            + +(datetime.getHours() < 10 ? '0' + datetime.getHours() : datetime
                                            .getHours())
                            + ':'
                            + (datetime.getMinutes() < 10 ? '0' + datetime.getMinutes()
                                            : datetime.getMinutes())
                            + ':'
                            + (datetime.getSeconds() < 10 ? '0' + datetime.getSeconds()
                                            : datetime.getSeconds()) + ':   ' + message + '</p>'"";*/
    }
    function displayTypingMessage() {
            var temp = "are";
            if (authors.length > 0) {
                    if (authors.length == 1) {
                            temp = "is";
                    }
                    $("#statusDiv").text(authors.join() + " " + temp + " typing");
            } else if (authors.length == 0) {
                    $("#statusDiv").text("");
            }
    }

