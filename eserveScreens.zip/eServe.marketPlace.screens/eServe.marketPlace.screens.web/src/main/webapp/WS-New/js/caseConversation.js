
/* author : Jagan 
   Date   : 10 May 2013
   Title  : Case Conversation Details

 */



var wsApp = angular.module('workSystem', ['localization','ui.keypress']);

wsApp.directive('whenScrolled', function() {
    return function(scope, elm, attr) {
        var raw = elm[0];
        
        elm.bind('scroll', function() {
            if (raw.scrollTop + raw.offsetHeight >= raw.scrollHeight) {
                scope.$apply(attr.whenScrolled);
            }
        });
    };
});

wsApp.directive('toggle', function() {
    return function(scope, elm, attr) {
        var raw = elm[0];
        
        elm.bind('scroll', function() {
            if (raw.scrollTop + raw.offsetHeight >= raw.scrollHeight) {
                scope.$apply(attr.whenScrolled);
            }
        });
    };
});

wsApp.factory('caseData', function(){
	return {
		
		caseId:1
		
	}
});


function caseTabCtrl($scope, $rootScope, $http,caseData) {
	
	 $scope.getCaseConversation = function()  {
		 
		 $http({url: "data/case_conversation_"+$rootScope.caseIdGlobal +".json", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'} }).

	    success(function (resp) {
	          
	           //alert("Got response");
	           //splayConversation(resp);

	    		$rootScope.conversations = resp.conversations;
	        }).
	        error(function(resp) {


	        	alert("Didnt get any response");
	        }); 
		 
    };
    
    $scope.getCaseDetails = function() {



        $http({url: "data/case_details_"+ $rootScope.caseIdGlobal+".json", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'} }).

         	    success(function (resp) {
  	          
  	           //alert("Got response");
  	           //splayConversation(resp);

  	        
             // Getting the basic case details
              $rootScope.title = resp.details.title;
              $rootScope.status = resp.details.status;
              $rootScope.priority = resp.details.priority;
              $rootScope.language = resp.details.language;
              $rootScope.description = resp.details.description;
              $rootScope.assignee = resp.details.assignee;
              $rootScope.directLink = resp.details.direct_link;
              $rootScope.dueDate = resp.details.due_date;
              $rootScope.groups = resp.details.groups; 
              
             // Getting the basic customer infomation
              $rootScope.caseID = resp.id;
              $rootScope.customer = resp.customerInfo.name;
              $rootScope.company = resp.customerInfo.company.name;
              
              // Getting the basic agent infomation
              
              $rootScope.agentInfo = resp.agentInfo;
              
              // Getting channel info , ie where channel is posted.
              
              $rootScope.channelInfo = resp.details.channelInfo;
              
              
  	        }).
  	        error(function(resp) {


  	        	alert("Didnt get any response");
  	        });

   };
    
   
    $scope.getCaseInfo = function(id){
    	
    $rootScope.caseIdGlobal = id;	
   	 
   	 $scope.getCaseConversation(); // To get conversation details
     $scope.getCaseDetails(); // TO get case details
   	 
    };
    
    $scope.getCaseInfo(1);
    
}



function caseConversationCtrl($scope, $http, $rootScope,caseData) {
       
       //$scope.conversations = [];

      $scope.getConversation = function(id) {
       
        $http({url: "data/case_conversation_"+ $rootScope.caseIdGlobal+".json", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'} }).

       	    success(function (resp) {
	          
	           //alert("Got response");
	           //splayConversation(resp);

	            $scope.conversations = resp.conversations;
	        }).
	        error(function(resp) {


	        	alert("Didnt get any response");
	        })
	        
      }
      
             //$scope.getConversation(1) ; 

          
	         $scope.postConversation = function(type) {

				var newConv = [{

					"id":"1",
		  			"name":"Mark R Hamillton",
				  	"type":"agent",
				  	"photo":"img/agent1.png",
				  	"date":"Mar 27, 2013 at 03:15 am ",
				  	"channel":type,
				  	"content":$scope.txtConversation,
				  	"attachments":{}
				} ];
				$scope.txtConversation = '';

                    
				/* Display new conversation */

                 var oldConvs =   $rootScope.conversations ;

                 

                 $rootScope.conversations = [] ;

                 //$scope.conversations = $scope.conversations.push($scope.newConv);

                 
           		 angular.forEach(oldConvs, function(conversation) {

            
               		newConv.push(conversation);

                 });


                 $rootScope.conversations =  newConv;
                
			};	



                
			    $scope.loadMore = function() {
			        /*for (var i = 0; i < 5; i++) {
			            $scope.items.push({id: counter});
			            counter += 10;
			        }*/

                   //alert("loading more");

                   $http({url: "data/case_conversation_"+ $rootScope.caseIdGlobal+".json", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'} }).

		       	    success(function (resp) {
			          
			           //alert("Got response");
			           //splayConversation(resp);

			            //$scope.conversations = resp;


			            angular.forEach(resp.conversations, function(conversation) {

            
		               		 $rootScope.conversations.push(conversation);

		                 });

			        }).
			        error(function(resp) {


			        	alert("Didnt get any response when loading");
			        });

			    };
			    
			    //$scope.loadMore()		   

}






/* --------------- Case Details ----------------------------------  */



function caseSidebarCtrl($scope ,$http, $rootScope,caseData) {

 
 $scope.getCaseDetails = function() {



      $http({url: "data/case_details_"+ $rootScope.caseIdGlobal+".json", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'} }).

       	    success(function (resp) {
	          
	           //alert("Got response");
	           //splayConversation(resp);

	        

            $rootScope.title = resp.details.title;
            $rootScope.status = resp.details.status;
            $rootScope.priority = resp.details.priority;
            $rootScope.language = resp.details.language;
            $rootScope.description = resp.details.description;
            $rootScope.assignee = resp.details.assignee;
            $rootScope.directLink = resp.details.direct_link;
            $rootScope.dueDate = resp.details.due_date;
            $rootScope.groups = resp.details.groups;
            
	        }).
	        error(function(resp) {


	        	alert("Didnt get any response");
	        })

 };


 //$scope.getCaseDetails();
 
 
}


function saveCaseCtrl($scope, $rootScope) {
	
	

	  $scope.sendCaseDetails = function () {
		  
	     //alert($rootScope.title);
				var sendCaseDetailsJson = {   
						
									"id":$scope.id,
								    "details": {
								        "title": $rootScope.title,
								        "priority": $rootScope.priority,
								        "groups": [
								            {
								                "id": "1",
								                "name": "Support"
								            }
								        ],
								        "description": $rootScope.description,
								        "assignee": $rootScope.assignee,
								        "language": $rootScope.language,
								        "labels": [
								            "Frank OZ",
								            "Carrie fisher"
								        ],
								        "direct_link": $rootScope.directLink,
								        "due_date": $rootScope.dueDate,
								        "status":$scope.status
								        
								    }
								};
				alert(JSON.stringify(sendCaseDetailsJson));
	  };
	
	
	 // $scope.sendCaseDetails();
	
	
}





function caseTitleBarCtrl($scope,$rootScope, $http) {
	
	
		
	
	
}












































/*var app = angular.module('worksystem',[]).config(['$routeProvider', function($routeProvider){
    $routeProvider.
        when('/index', {templateUrl: 'index.html', controller: appNameCtrl}).
        when('/:catId/', { templateUrl: 'index.html', controller: categoryCtrl }).
        otherwise({redirectTo: '/index'});
} ]);

//Add this to have access to a global variable
app.run(function ($rootScope) {
$rootScope.globalVariable = 'Amadou'; //global variable
});

*/

/* Jquery Useages in case details */


/*$(function(){
	
	//$.fn.editable.defaults.mode = 'inline';
	$('#case-title').editable();
	$('#case-description').editable();
	$('#case-assignee').editable();
	$('#case-link').editable();
	$('#case-duedate').editable();
	$('#case-duedate').editable();
	$('#case-duedate').editable();
	$('#case-bug-id').editable();
	$('#case-cdet-id').editable();
	

	
	 $('#case-status').editable({
		 value: 2,
		 source: [
		 {value: 1, text: 'Open'},
		 {value: 2, text: 'Pending'},
		 {value: 3, text: 'Resolved'}
		 ]
	});
	 $('#case-priority').editable({
		 value: 2,
		 source: [
		 {value: 1, text: 'Minor'},
		 {value: 2, text: 'High'},
		 {value: 3, text: 'Very high'}
		 ]
	});
	 $('#case-groups').editable({
		 value: 1,
		 source: [
		 {value: 1, text: 'Support'},
		 {value: 2, text: 'Tech Support'}
		 ]
	});
	 $('#case-language').editable({
		 value: 1,
		 source: [
		 {value: 1, text: 'English'},
		 {value: 2, text: 'French'},
		 {value: 3, text: 'Latin'}
		 ]
	});
	
});*/

function toggle() {
	
	$('.submit-case').toggle();
	
}



























/* Adding Everything into a controller 


function caseInfoCtrl($scope,$rootScope,$http) {
	

    
    $scope.conversations = [];

   $scope.getCaseConversation = function(id) {
    
     $http({url: "data/case_conversation.json", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'} }).

    	    success(function (resp) {
	          
	           //alert("Got response");
	           //splayConversation(resp);

	            $scope.conversations = resp.conversations;
	        }).
	        error(function(resp) {


	        	alert("Didnt get any response");
	        });
	        
   }
   
          //$scope.getConversation(1) ; 

       
	         $scope.postConversation = function(type) {

				var newConv = [{

					"id":"1",
		  			"name":"Mark R Hamillton",
				  	"type":"agent",
				  	"photo":"img/agent1.png",
				  	"date":"Mar 27, 2013 at 03:15 am ",
				  	"channel":type,
				  	"content":$scope.txtConversation,
				  	"attachments":{}
				} ];
				$scope.txtConversation = '';

                 
				 Display new conversation 

              var oldConvs =   $scope.conversations ;

              

              $scope.conversations = [] ;

              //$scope.conversations = $scope.conversations.push($scope.newConv);

              
        		 angular.forEach(oldConvs, function(conversation) {

         
            		newConv.push(conversation);

              });


              $scope.conversations =  newConv;
             
			};	



             
			    $scope.loadMore = function() {
			        for (var i = 0; i < 5; i++) {
			            $scope.items.push({id: counter});
			            counter += 10;
			        }

                //alert("loading more");

                $http({url: "data/case_conversation.json", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'} }).

		       	    success(function (resp) {
			          
			           //alert("Got response");
			           //splayConversation(resp);

			            //$scope.conversations = resp;


			            angular.forEach(resp.conversations, function(conversation) {

         
		               		 $scope.conversations.push(conversation);

		                 });

			        }).
			        error(function(resp) {


			        	alert("Didnt get any response when loading");
			        });

			    };
			    
			    //$scope.loadMore();



        Case Details 
			    
			      
			    
			    $scope.getCaseDetails = function(id) {



			        $http({url: "data/case_details.json", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'} }).

			         	    success(function (resp) {
			  	          
			  	           //alert("Got response");
			  	           //splayConversation(resp);

			  	        
                          $rootScope.caseID = resp.id;
			              $rootScope.title = resp.details.title;
			              $rootScope.status = resp.details.status;
			              $rootScope.priority = resp.details.priority;
			              $rootScope.language = resp.details.language;
			              $rootScope.description = resp.details.description;
			              $rootScope.assignee = resp.details.assignee;
			              $rootScope.directLink = resp.details.direct_link;
			              $rootScope.dueDate = resp.details.due_date;
			              $rootScope.groups = resp.details.groups;
			              $rootScope.customer = resp.customerInfo.name;
			              $rootScope.company = resp.customerInfo.company.name;
			              
			              
			              
			  	        }).
			  	        error(function(resp) {


			  	        	alert("Didnt get any response");
			  	        })

			   };


			   //$scope.getCaseDetails();
			   
			   
	  Save Case Details 
			   
			   
			   $scope.sendCaseDetails = function () {
					  
				     //alert($rootScope.title);
							var sendCaseDetailsJson = {   
												"id":$scope.id,
											    "details": {
											        "title": $rootScope.title,
											        "priority": $rootScope.priority,
											        "groups": [
											            {
											                "id": "1",
											                "name": "Support"
											            }
											        ],
											        "description": $rootScope.description,
											        "assignee": $rootScope.assignee,
											        "language": $rootScope.language,
											        "labels": [
											            "Frank OZ",
											            "Carrie fisher"
											        ],
											        "direct_link": $rootScope.directLink,
											        "due_date": $rootScope.dueDate,
											        "status":$scope.status
											        
											    }
											};
							alert(JSON.stringify(sendCaseDetailsJson));
				  };
				
				
				  $scope.getCaseInfo = function(caseID,index) {
					  
					  $scope.getCaseConversation(caseID);
					  $scope.getCaseDetails(caseID);
					  			  
				  } ;
				  
				  $scope.getCaseInfo('1',"");
	
}
*/






































