//var app=angular.module('workSystem',["ui.keypress"]);

wsApp.directive('onKeyup', function() {
    return function(scope, elm, attrs) {
        elm.bind('keypress', function(evt) {
            //if no key restriction specified, always fire
            if (evt.which != 13 && evt.target.value.length == 3) {
            	scope.$apply(attrs.onKeyup);
            } else if(evt.which == 13) {
            	
            	$(".chat-log").animate({ scrollTop: $(".chat-log").get(0).scrollHeight}, "slow");
            	evt.preventDefault();
            }
        });
    };
});
wsApp.directive('onBlur', function() {
    return function(scope, elm, attrs) {
        elm.bind('blur', function(evt) {
            //if no key restriction specified, always fire
            
            	scope.$apply(attrs.onBlur);
            
        });
    };
});
wsApp.directive('onFoucs', function() {
    return function(scope, elm, attrs) {
        elm.bind('focus', function(evt) {
            //if no key restriction specified, always fire
            
        	if(evt.target.value.length > 3) {
        	
            	scope.$apply(attrs.onFocus);
        	}
            
        });
    };
});

// Service for chat , to make communication between different controllers
	

wsApp.factory('chatStatusData', function(){
	return {
		count : 0,
		show :false
		
	}
});

 
function chatStatusCtrl($scope,$http,$rootScope,chatStatusData) {
	
	$scope.activeChats= {};
	$rootScope.activeChats = 0;
	$rootScope.waitingReply = 0;
	$scope.activeChat = 0;
	$scope.activeChats = chatStatusData;
	$scope.chatWindow = {};
	$scope.chatWindow = chatStatusData
	
};


function chatCtrl($scope,$http,$rootScope,chatStatusData) {
	
	$scope.chatWindow = {};
	$scope.chatWindow = chatStatusData;
	
	$scope.activeChats = {};
	
    $scope.messages = [];
    $scope.authorInfo= "";
    $scope.subscriberIdGlobal = "";
    $scope.postMsg = {};
    $scope.broadcastData = {
            version : null,
            subscriberId : null,
            groupId : null,
            messageType : null,
            message : null
    };
    
    $scope.activeChats =chatStatusData; 
   
    
    
    
    
    
    //Assigning values for posting message,
    
     
     
    
    
    
    $scope.sendMessage = function() {
      
    	$scope.post();
    	//alert($scope.messageText);
        $scope.messageText = "";
    };
    
    //Request to send message 
    
       $scope.postMessage = function() {
    	     
    	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
    	 $scope.postMsg.messageTxt = $scope.messageText;
    	 $scope.postMsg.author = {} ; 
    	 $scope.postMsg.author.firstName = "Jagan";   
    	 $scope.postMsg.author.lastName = "";   
    	 $scope.postMsg.author.photoUrl = "";   
    	 $scope.postMsg.timeStamp = ""; 
    	 
    	 
    	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
    	 $scope.broadcastData.messageType = "chat:post";
    	 $scope.broadcastData.message = $scope.postMsg; 
    	 
    	 $scope.post();
    	 $scope.addMessage();
   };
   
   $scope.addMessage = function() {
	   
	   $scope.postMsg.timeStamp = Date.now();
	   $scope.messages.push($scope.postMsg);
	   $scope.messageText = "";
	   $scope.postMsg ={};
   };
   
   
   $scope.addStatus = function() {
      
	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
  	 $scope.postMsg.messageTxt = "is typing ...";
  	 $scope.postMsg.author = {} ; 
  	 $scope.postMsg.author.firstName = "Jagan";   
  	 $scope.postMsg.author.lastName = "";   
  	 $scope.postMsg.author.photoUrl = "";   
  	 $scope.postMsg.timeStamp = ""; 
  	 
  	 
  	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
  	 $scope.broadcastData.messageType = "chat:status";
  	 $scope.broadcastData.message = $scope.postMsg;
	   
  	 $scope.post();
  	 
  	 
	   
     };
     $scope.removeStatus = function() {
         
    	 $scope.postMsg.chatId = $scope.chatInfo.subscriberId;
      	 $scope.postMsg.messageTxt = "";
      	 $scope.postMsg.author = {} ; 
      	 $scope.postMsg.author.firstName = "";   
      	 $scope.postMsg.author.lastName = "";   
      	 $scope.postMsg.author.photoUrl = "";   
      	 $scope.postMsg.timeStamp = ""; 
      	 
      	 
      	 $scope.broadcastData.subscriberId = $scope.subscriberIdGlobal;
      	 $scope.broadcastData.messageType = "chat:remove";
      	 $scope.broadcastData.message = $scope.postMsg;
      	 $scope.post();
         };
   
     
   $scope.post = function(){
	   $http({
   		url: "http://localhost:8080/eserve.worksystem.service.chat-web/chatservice/subscribe/chat", 
   		method: "POST",
   		dataType:"JSON", 
   		data:$scope.broadcastData,
   		headers: {'Content-type': 'application/json'} }).
   	    success(function (resp) {
   	    		//$scope.addMessage();
   	    		
	        }).
	        error(function(resp) {
	        	alert("Request  Failed : while sending message");
	        	return false;
	        });
   };
    	 
 }