function acceptClient(response) {
	openChat(response);
/*	broadcastData.subscriberId = response.message.chatId;
	broadcastData.messageType = "agent:accept"; 
	postMsg.author.firstName = "Jagan Default";
	postMsg.chatId = response.subscriberId;
	postMsg.messageTxt= " is accepted";
	broadcastData.message = postMsg;
	post(broadcastData);*/
}