angular.module('ui.utils',  [
  "ui.event",
  "ui.format",
  "ui.highlight",
  "ui.indeterminate",
  "ui.inflector",
  "ui.jq",
  "ui.keypress",
  "ui.mask",
  "ui.reset",
  "ui.route",
  "ui.scrollfix",
  "ui.showhide",
  "ui.unique",
  "ui.validate"
]);