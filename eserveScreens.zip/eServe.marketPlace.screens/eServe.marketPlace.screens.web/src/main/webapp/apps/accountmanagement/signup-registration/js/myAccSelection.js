var myAccSelection = angular.module('myAccSelApp',[])

myAccSelection.factory('accountSelection', ['$http', function($http){
	return{
		name: 'Account Selection',
		get: function(callback){
			$http.get('/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/providerInfo').success(function(data) {
			callback(data);
			});
		}
	}
}]);


function accSelectionCntrl($scope, $http, accountSelection )
{
	accountSelection.get(function(data){
		$scope.accSelection = data;
	});
	
	$scope.accTypeSelect = function(element) {
		var selectedAccount = element.target.getAttribute('profiletype');
		$scope.accSelection.userHasProfiles[0].profileType.profileType = selectedAccount;
		var useremail = window.location.search.split('=').pop();
		$http({ url:"/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/updateProviderProfile", method: "PUT",  data:JSON.stringify($scope.accSelection) }).success(function (resp) {
            alert('success');
            if( selectedAccount == "ProviderProfile" )
            {
            	window.location = "/eServe.marketPlace.screens.web/pages/registration/pregistration.jsp?emailId="+useremail+"?profileType="+selectedAccount;
            }
            else if( selectedAccount == "ProviderBusinessProfile" )
            {
            	window.location = "/eServe.marketPlace.screens.web/pages/registration/bregistration.jsp?emailId="+useremail+"?profileType="+selectedAccount;
            }
            else if( selectedAccount == "ClientBusinessProfile" )
            {
            	window.location = "/eServe.marketPlace.screens.web/pages/registration/bcregistration.jsp?emailId="+useremail+"?profileType="+selectedAccount;
            }
            
        });			
	}
}