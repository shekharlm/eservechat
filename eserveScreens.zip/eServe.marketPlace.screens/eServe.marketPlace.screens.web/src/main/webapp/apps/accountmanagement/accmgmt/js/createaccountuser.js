angular.module('createAccUser', ['ui.bootstrap.dropdownToggle', 'invite.friends']).controller('createUserCntrl', function($scope,$http, createAccUserData,companiesList){
	createAccUserData.get(function(data){
		$scope.accUserData = data;
	});
	companiesList.get(function(data){
		$scope.companiesList = data;
	});
	$scope.createUserSubmit = function() {
		//var buttonID = element.target.getAttribute(id);
		//alert(JSON.stringify($scope.accUserData));
		$http({ url:"/eServe.marketPlace.accountmanagement.profiles-web/profiles/createuser",method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'}, data:JSON.stringify($scope.accUserData) }).success(function (resp) {
        if(resp.message.toLowerCase()==SUCCESS){
        	alert("Invitation has been sent successfully");
        	 
        }else if(resp.message.toLowerCase()==FAILED) {
        	alert("Error in processing request");
        }
        else if(resp.message.toLowerCase()==ACCEPTED ) {
        	alert("User has already accepted the invitation.");
        }
        else if(resp.message.toLowerCase()==NOTEXPIRED) {
        	alert("User has already been invited and invitation has not expired yet.");
        }
        else if(resp.message.toLowerCase()== EXISTS ) {
        	alert("Invite email already exsits as a user");
        }
        else if(resp.message.toLowerCase()== INVALID ) {
        	alert("The invited user does not have a eserve account hence it cannot be added as an employee or a consultant.");
        }
        location.reload(); // Refreshing the page....Need To customize the page loading
		});	
	}
	$scope.createMultipleUserSubmit = function() {
		//var buttonID = element.target.getAttribute(id);
		//alert(JSON.stringify($scope.accUserData));
		$http({ url:"/eServe.marketPlace.accountmanagement.profiles-web/profiles/createuser",method: "POST",dataType:"JOSN", headers: {'Content-type': 'application/json'}, data:JSON.stringify($scope.accUserData) }).success(function (resp) {
			 if(resp.message.toLowerCase()==SUCCESS){
		        	alert("Invitation has been sent successfully");
		        }else if(resp.message.toLowerCase()==FAILED) {
		        	alert("Error in processing request");
		        }
		        else if(resp.message.toLowerCase()==ACCEPTED ) {
		        	alert("User has already accepted the invitation.");
		        }
		        else if(resp.message.toLowerCase()==NOTEXPIRED) {
		        	alert("User has already been invited and invitation has not expired yet.");
		        }
		        else if(resp.message.toLowerCase()== EXISTS ) {
		        	alert("Invite email already exsits as a user");
		        }
		        else if(resp.message.toLowerCase()== INVALID ) {
		        	alert("The invited user does not have a eserve account hence it cannot be added as an employee or a consultant.");
		        }
			 location.reload(); // Refreshing the page....Need To customize the page loading
        });	
	}

}).factory('createAccUserData', ['$http', function($http){
	return{
		name: 'Account User Data',
		get: function(callback){
			$http.get('/eServe.marketPlace.accountmanagement.profiles-web/profiles/blankJsonOfUserHasInvitation').success(function(data) {
				callback(data);
			});
		}
	}
}]).factory('companiesList', ['$http', function($http){
	return{
		name: 'Companies List',
		get: function(callback){
			$http({url:"/eServe.marketPlace.accountmanagement.profiles-web/profiles/companieslist",dataType:"JSON",method:"GET",headers: {'Content-type': 'application/json'}}).success(function(data) {
				// prepare data here
				callback(data);
			});
		}
	}
}]).directive('datepicker',function ($parse){ 
    var linker = function(scope, element, attrs) {
    	 var ngModel = $parse(attrs.ngModel);
        element.datepicker({
        	inline: true,
        	 showOn:"both",
             changeYear:true,
             changeMonth:true,
             minDate: new Date(),
            dateFormat: 'yy-mm-dd',
            onSelect:function (dateText, inst) {
                scope.$apply(function(scope){
                    // Change binded variable
                    ngModel.assign(scope, dateText);
                });
           }
        });
    }

    return {
        restrict: 'A',
        link: linker 
    }
});
var options = {
		
	    onFail: function() {
			for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
			{
				 $($myform.getInvalid()[errlen]).addClass('invalid')
				 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
			}
	    },
	    onSuccess: function() {
			$('#createUser').trigger('click');
	    },
	
	    inputs: {
	      'password': {
	        filters: 'required password',
	      },
	      'username': {
	        filters: 'required username',
	        data: {
	         
	        }
	      },
	      'file': {
	        filters: 'extension',
	        data: { extension: ['jpg'] }
	      },
	
	      'comments': {
	        filters: 'min max',
	        data: { min: 50, max: 200 }
	      },
	      'question': {
	        filters: 'exclude',
	        data: { exclude: ['default'] },
	        errors : {
	          exclude: 'Select a Question.'
	        }
	      },
	      'langs[]': {
	        filters: 'min max',
	        data: { min: 1, max: 1 },
	        errors: {
	          min: 'Please Accept the term and condition.',
	          max: 'Please Accept the term and condition.'
	        }
	      }
	    }
	  };
	
	  var $myform = $('#my-form').idealforms(options).data('idealforms');
