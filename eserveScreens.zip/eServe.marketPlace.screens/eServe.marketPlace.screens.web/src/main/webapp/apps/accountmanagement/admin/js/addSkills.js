$(document).ready(function(){
	$("#addSkillsBtn").click(function(){
		$('#addSkillsToggle').toggle();
	});
});