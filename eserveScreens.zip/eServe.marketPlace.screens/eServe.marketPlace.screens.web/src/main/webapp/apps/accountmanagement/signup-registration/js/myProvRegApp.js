angular.module('myRegApp', []).controller('myRegAppAuth', function($scope,$http,regData){
	
	regData.get(function(data){
		$scope.registrationData = data;
	});
	
		
	
	$scope.Done = function(event) { 
		$scope.registrationData.emailId = window.location.search.split('?')[1].split('=')[1];
		
		// Getting Skills
		
		for( var s = 0; s < $('.token-input-token p').length; s++ )
		{
			if( s >= 1 )
			{
				// Need to update dynamically based on json structure;
				
				$scope.registrationData.userHasSkills[s] = {
			            "id": 0,
			            "additionalComments": null,
			            "relevantExp": 0,
			            "skill": {
			                "id": 0,
			                "skill": "",
			                "jobHasSkills": null,
			                "skillType": null,
			                "userHasSkills": null,
			                "industryHasSkills": null
			            },
			            "user": null,
			            "userSkillRatings": null
			        };
			}
				
			$scope.registrationData.userHasSkills[s].skill.skill = $('.token-input-token p')[s].textContent;
			$scope.registrationData.userHasSkills[s].skill.id = $('.token-input-token p')[s].id;	
			
		}
		
		$http({url: "/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/updateProviderProfile", method: "PUT", headers: {'Content-type': 'application/json'}, data: JSON.stringify($scope.registrationData) }).success(function (resp) {
			 alert('Thanks for registration. Please login.');
			 window.location = "/eServe.marketPlace.screens.web/index.jsp"; 
		});
	}
}).factory('regData', ['$http', function($http){
	return{
		name: 'Registration Info',
		get: function(callback){
			$http({url: "/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/providerInfo",dataType:"JSON", method:"GET" }).success(function (data) {
				callback(data)
			});	
		}
	}
}]);

var options = {
		
	    onFail: function() {
			for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
			{
				 $($myform.getInvalid()[errlen]).addClass('invalid')
				 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
			}
	    },
	    onSuccess: function() {
			$('#provRegDone').trigger('click');
	    },
	
	    inputs: {
	      'password': {
	        filters: 'required password',
	      },
	      'username': {
	        filters: 'required username',
	        data: {
	         
	        }
	      },
	      'file': {
	        /* filters: 'extension',
	        data: { extension: [] } */
	      },
	      'number': {
	    	  filters: 'optional number',
	    	  data: { min: 10, max: 15 }
	      },
	      'profileOverview': {
	        filters: 'required min max',
	        data: { min: 50, max: 200 }
	      },
	      'jobHasSkills': {
		        filters: 'required min max',
		        data: { min: 1, max: 200 }
		      },
	      'country': {
	        filters: 'exclude',
	        data: { exclude: ['default'] },
	        errors : {
	          exclude: 'Select a Country.'
	        }
	      }
	    }
	  };
	
	  
	  var $myform = $('#my-form').idealforms(options).data('idealforms');

	  $(document).ready(function(){
		  
		  $('#addProfileAttachmentCollapse').click(function() {
			  $('#profileHasAttachmentField').toggle();
			  $('#addProfileAttachmentCollapse').hide();$('#addProfileAttachmentExp').show();
		  });
		  $('#addProfileAttachmentExp').click(function() {
			  $('#profileHasAttachmentField').toggle();
			  $('#addProfileAttachmentCollapse').show();$('#addProfileAttachmentExp').hide();
		  });
		  
		  $.ajax({
			 url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/skills/displayAllSkills",
			 method: "GET",
			 dataType: "JSON",
			 success: function(resp) {
				if( resp.status.toLowerCase() != FAIL )
				{
					 $("#userHasSkills").tokenInput(resp.skills, {
			                preventDuplicates: true
			            });
				}
				else
				{
					console.log('Populate skills Error');
				}
			 },
			 error: function(resp){
				 alert('Json Error');
			 }
		  });
	      
	  });