
// Forget password 
// Verifying the email id
// and if the email id is valid then redirecting to the security question page
// else appropriate error message display. 


var forgetpwdAuth = angular.module("forgetpasswordApp", []);
	
forgetpwdAuth.factory("forgetpwd", function() {
			

			var forgetpwd = {};
			forgetpwd = {
					"emailId" : ""
				}
			return forgetpwd;
	});
	
	function forgetPwdCntrl($scope, $http, forgetpwd)
	{
		$scope.forgetpassword = forgetpwd;
		$scope.submitforgetpwd = function() {
			alert(JSON.stringify(forgetpwd));
			
			$http({ url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/resetPassword", method: "POST",dataType:"json", headers: {'Content-type': 'application/json'}, data:forgetpwd.emailId
			}).success(function (resp) {
				if( resp.message.toLowerCase() == RESENT )
				{
					alert('Reset password link is sent to your mail.');
				}else if( resp.message.toLowerCase() == SECURITYQUESTION )
				{
					//alert('need to forward security page');
					window.location="/eServe.marketPlace.screens.web/pages/fp/securitypage.jsp?email="+forgetpwd.emailId;
					/*$scope.alert =  { type: 'alert-error', msg: 'Your email id does not exists. Please check your email id.', errorDisplay: "displayBlock" }
					forgetpasswordalertCtrl($scope);*/
				}
				else if( resp.message.toLowerCase() == FAIL ){
					alert('Please verify the email Id');
				}
				else if( resp.message.toLowerCase() == CLOSED ){
					alert('You Account is closed. Please contact admin to re-open the account');
				}
				else if( resp.message.toLowerCase() == INVALID ){
					alert('Invalid Email');
				}
	        }).
	        error(function(resp) {
	        	alert("Error forget Password");
	        });		
		}
	}
	function forgetpasswordalertCtrl($scope) {
	  $scope.closeAlert = function(index) {
	    $scope.alerts.splice(index, 1);
	  };

	}
	
	

	
	 var options = {
				
	    onFail: function() {
			for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
			{
				 $($myform.getInvalid()[errlen]).addClass('invalid')
				 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
			}
	    },
	    onSuccess: function() {
			$('#forgotEmailId').trigger('click');
	    },
	
	    inputs: {
	      'password': {
	        filters: 'required password',
	      },
	      'username': {
	        filters: 'required username',
	        data: {
	         
	        }
	      },
	      'file': {
	        filters: 'extension',
	        data: { extension: ['jpg'] }
	      },
	
	      'comments': {
	        filters: 'min max',
	        data: { min: 50, max: 200 }
	      },
	      'country': {
	        filters: 'exclude',
	        data: { exclude: ['default'] },
	        errors : {
	          exclude: 'Select a Country.'
	        }
	      },
	      'langs[]': {
	        filters: 'min max',
	        data: { min: 1, max: 1 },
	        errors: {
	          min: 'Please Accept the term and condition.',
	          max: 'Please Accept the term and condition.'
	        }
	      }
	    }
	  };
	
	  var $myform = $('#my-form').idealforms(options).data('idealforms');