var viewMyProfileApp = angular.module('viewProfile', ['ui.bootstrap.dropdownToggle','invite.friends','ui.bootstrap']);


viewMyProfileApp.factory('viewBasicInfo', ['$http', function($http){
	return{
		name: 'Basic Info',
		get: function(callback){
			//var mailAddress = window.location.search.split('=').pop();
			// Need to update late url after testing complete
			// /eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/basicinf
			///eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/user/basicinf
			$http.get('/eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/user/basicinf').success(function(data) {
			// prepare data here
			callback(data);
			});
		}
	}
}]);

viewMyProfileApp.factory('countriesList', ['$http', function($http){
	return{
		name: 'Country List',
		get: function(callback){
			
				$http.get('/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/Countries').success(function(data) {
					// prepare data here
					callback(data);
				});
			}
	}
}]);
viewMyProfileApp.directive('mouseover', ['$http', function($http){
	return function (scope, element, attrs){
		element.bind('mouseenter', function (element) {
			$('.changePhoto').css('display','block');
		});
		element.bind('mouseleave', function (element) {
			$('.changePhoto').css('display','none');
		});
	}	
}]);
viewMyProfileApp.directive('datepicker',function ($parse){ 
    var linker = function(scope, element, attrs) {
    	 var ngModel = $parse(attrs.ngModel);
        element.datepicker({
        	inline: true,
        	 showOn:"both",
             changeYear:true,
             changeMonth:true,
             yearRange : 'c-50:c+10',
            dateFormat: 'yy-mm-dd',
            onSelect:function (dateText, inst) {
                scope.$apply(function(scope){
                    // Change binded variable
                    ngModel.assign(scope, dateText);
                });
           }
        });
    }

    return {
        restrict: 'A',
        link: linker 
    }
});


function viewProfileAppCntrl($scope, $http, $filter, viewBasicInfo, countriesList )
{
	viewBasicInfo.get(function(data){
		if( data.status.toLowerCase() == INACTIVE )
		{
			alert('Your Account is inactive. Please check mail and Activate your account');
			$('input').attr('disabled','disabled');$('select').attr('disabled','disabled');
		}else if( data.status.toLowerCase() == BLOCKED )
		{
			alert('Your Account is Closed. Please contact admin to reopen');
			$('input').attr('disabled','disabled');$('select').attr('disabled','disabled');
		}else if( data.status.toLowerCase() == ACTIVE )
		{
			$scope.basicInfoData = data.userobj;
			$scope.basicInfoData.dateOfBirth = $filter('date')($scope.basicInfoData.dateOfBirth, 'yyyy-mm-dd');
		}
		
		if( $scope.basicInfoData != undefined )
		{
			if( $scope.basicInfoData.accountStatus.toLowerCase() == INACTIVE )
			{
				$('.errorBlock').css('display','block');
			}
		}
		if( $scope.basicInfoData != undefined )
		{
			if($scope.basicInfoData.userHasProfiles[0].profileType.profileType == "CLIENT_BUSINESS" )
			{
				$scope.companyName = $scope.basicInfoData.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
				$scope.CompanyNav = "viewCliCompany.jsp";
			}
			else if( $scope.basicInfoData.userHasProfiles[0].profileType.profileType == "PROVIDER_BUSINESS" )
			{
				$scope.companyName = $scope.basicInfoData.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
				$scope.CompanyNav = "viewProvCompany.jsp";
			}
			else if( $scope.basicInfoData.userHasProfiles[0].profileType.profileType == "PROVIDER" )
			{
				$('#account-link').css('display','none')
			}
		}
	});
	countriesList.get(function(data){
		$scope.countriesData = data;
	});
	
	
	$scope.$watch('basicInfoData.userHasAddresses[0].address.country.id', function(value) {
		if($scope.basicInfoData != undefined ) {
			
			$http.get('/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/States/'+parseInt(value)).success(function(data) {
				$scope.stateListCurrent = data;
			});
			
		}
	});
	$scope.$watch('basicInfoData.userHasAddresses[1].address.country.id', function(value) {
		if($scope.basicInfoData != undefined ) {
			
			$http.get('/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/States/'+parseInt(value)).success(function(data) {
				$scope.stateListPermanent = data;
			});
			
		}
	});
	$scope.copyAddress = function($event)
	{
		var checkbox = $event.target;
		if( checkbox.checked == true )
		{
			$scope.basicInfoData.userHasAddresses[1].address.addressLine1 = $scope.basicInfoData.userHasAddresses[0].address.addressLine1;
			$scope.basicInfoData.userHasAddresses[1].address.addressLine2 = $scope.basicInfoData.userHasAddresses[0].address.addressLine2;
			$scope.basicInfoData.userHasAddresses[1].address.addressLine3 = $scope.basicInfoData.userHasAddresses[0].address.addressLine3;
			$scope.basicInfoData.userHasAddresses[1].address.country.id = $scope.basicInfoData.userHasAddresses[0].address.country.id;
			$scope.basicInfoData.userHasAddresses[1].address.state.id = $scope.basicInfoData.userHasAddresses[0].address.state.id;
			$scope.basicInfoData.userHasAddresses[1].address.pin = $scope.basicInfoData.userHasAddresses[0].address.pin;
		}else
		{
			$scope.basicInfoData.userHasAddresses[1].address.addressLine1 = "";
			$scope.basicInfoData.userHasAddresses[1].address.addressLine2 = "";
			$scope.basicInfoData.userHasAddresses[1].address.addressLine3 = "";
			$scope.basicInfoData.userHasAddresses[1].address.country.id = "";
			$scope.basicInfoData.userHasAddresses[1].address.state.id = "";
			$scope.basicInfoData.userHasAddresses[1].address.pin = "";
		}
	}
	
	$scope.updateprofile = function(scope,element){
		$http({ url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/update/updateBasicInfo", method: "POST", headers: {'Content-type': 'application/json'}, data:JSON.stringify($scope.basicInfoData)
		}).success(function (resp) {
			if(resp.status.toLowerCase() == FAIL )
			{
				alert('Error in To update the profile. Please try some other time.')
			}
			else
			{
				alert('Your Profile information has been updated successfully.')
			}
        }).
        error(function(resp) {
        	alert(resp);
        });	
	}
}

function AlertCtrl($scope) {
  $scope.alerts = [
    { type: 'error', msg: 'Email Address not yet verified. Please verify it.' }
  ];

  $scope.addAlert = function() {
    $scope.alerts.push({msg: "Another alert!"});
  };

  $scope.closeAlert = function(index) {
    $scope.alerts.splice(index, 1);
  };
}


var options = {
			
   onFail: function() {
		for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
		{
			 $($myform.getInvalid()[errlen]).addClass('invalid')
			 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
		}
   },
   onSuccess: function() {
		$('#updateBasicInfo').trigger('click');
   },

   inputs: {
     'password': {
       filters: 'required password',
     },
     'username': {
       filters: 'required username',
       data: {
        
       }
     },
     'file': {
       filters: 'extension',
       data: { extension: ['jpg'] }
     },
     'number': {
   	  filters: 'optional number',
   	  data: { min: 10, max: 15 }
     },
     'comments': {
       filters: 'min max',
       data: { min: 50, max: 200 }
     },
     /*'Country': {
       filters: 'exclude',
       data: { exclude: ['default'] },
       errors : {
         exclude: 'Select a Country.'
       }
     },
     'State': {
         filters: 'exclude',
         data: { exclude: ['default'] },
         errors : {
           exclude: 'Select a State.'
         }
       },*/
     'langs[]': {
       filters: 'min max',
       data: { min: 1, max: 1 },
       errors: {
         min: 'Please Accept the term and condition.',
         max: 'Please Accept the term and condition.'
       }
     }
   }
 };

 var $myform = $('#my-form').idealforms(options).data('idealforms');