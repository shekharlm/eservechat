
// Display the security question
// Verifying the security answer.
// and if the security answer is valid then redirecting to the change password page
// else appropriate error message display. 


var fpsecurityApp = angular.module("fpsecurityApp", []);
	
	
	
	function securityQnsCntrl($scope, $http, securityQnsList)
	{
		
		securityQnsList.get(function(data){
			$scope.securityQnsList = data;
			$scope.securityID =$scope.securityQnsList[0].id;
		});
		/*$http({ url: "../profiles/securityQuestion", dataType: "JSON", method: "GET", headers: {'Content-type': 'application/json'}
		}).success(function (resp) {
			alert('seccess');
        }).
        error(function(resp) {
        	alert(resp.text);
        });	*/
		
		$scope.submitSecurityAns = function() {
			var userID = "";
			for( var uid = 0; uid < $scope.securityQnsList.length; uid++ )
			{
				if( $scope.securityID ==  $scope.securityQnsList[uid].id )
				{
					userID = $scope.securityQnsList[uid].id;
				}
			}
			var email = window.location.href.split('=').pop()
			var securityResp = { "userhasSecurityQuestionId": userID,"securityAnswer": $scope.securityAnswer,"email":email  }	
			$http({ url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/checksecurityquestion",dataType:"JSON", method: "POST", headers: {'Content-type': 'application/json'}, data:JSON.stringify(securityResp)
			}).success(function (resp) {
				if( resp.message.toLowerCase() == SUCCESS )
				{
					$scope.alert =  { type: 'alert-success', msg: 'Your security answer is verified successfully. Please wait a second to proceed next step.', errorDisplay: "displayBlock" }
					securityqnsalertCtrl($scope);
					window.location = "/eServe.marketPlace.screens.web/pages/fp/changepassword.jsp?emailId="+resp.email;
				}else if( resp.message.toLowerCase() == FAIL )
				{
					$scope.alert =  { type: 'alert-error', msg: 'Error occurs while processing the request', errorDisplay: "displayBlock" }
					securityqnsalertCtrl($scope);
				}else if( resp.message.toLowerCase() == INVALID )
				{
					$scope.alert =  { type: 'alert-error', msg: 'Your security question answer is wrong. Please try one more time', errorDisplay: "displayBlock" }
					securityqnsalertCtrl($scope);
				}
	            
	        }).
	        error(function(resp) {
	        	alert("Error forget Password");
	        });		
		}
	}
	fpsecurityApp.factory('securityQnsList', ['$http', function($http){
		return{
			name: 'Security Questions List',
			get: function(callback){
				var emailAddress = window.location.href.split('=').pop();
				$http({ url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/getsecurityquestions/", dataType: "JSON", method: "GET", headers: {'Content-type': 'application/json','email':emailAddress}
				}).success(function (data) {
					callback(data)
		        }).
		        error(function(resp) {
		        	alert(resp.text);
		        });
			}
		}
	}]);
	
	function securityqnsalertCtrl($scope) {
	  $scope.closeAlert = function(index) {
	    $scope.alerts.splice(index, 1);
	  };

	}

	
	 var options = {
				
	    onFail: function() {
			for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
			{
				 $($myform.getInvalid()[errlen]).addClass('invalid')
				 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
			}
	    },
	    onSuccess: function() {
			$('#securityId').trigger('click');
	    },
	
	    inputs: {
	      'password': {
	        filters: 'required password',
	      },
	      'username': {
	        filters: 'required username',
	        data: {
	         
	        }
	      },
	      'file': {
	        filters: 'extension',
	        data: { extension: ['jpg'] }
	      },
	
	      'comments': {
	        filters: 'min max',
	        data: { min: 50, max: 200 }
	      },
	      'question': {
	        filters: 'exclude',
	        data: { exclude: ['default'] },
	        errors : {
	          exclude: 'Select a Question.'
	        }
	      },
	      'langs[]': {
	        filters: 'min max',
	        data: { min: 1, max: 1 },
	        errors: {
	          min: 'Please Accept the term and condition.',
	          max: 'Please Accept the term and condition.'
	        }
	      }
	    }
	  };
	
	  var $myform = $('#my-form').idealforms(options).data('idealforms');