angular.module('companiesList', ['ui.bootstrap.dropdownToggle', 'invite.friends']).controller('companiesListCntrl', function($scope,$http, companiesList){

	companiesList.get(function(data){
		$scope.companiesList = data;
	});

}).factory('companiesList', ['$http', function($http){
	return{
		name: 'Companies List',
		get: function(callback){
			$http({url:"/eServe.marketPlace.accountmanagement.profiles-web/profiles/companieslist/",dataType:"JSON",method:"GET",headers: {'Content-type': 'application/json'},data:'3'}).success(function(data) {
				// prepare data here
				callback(data);
			});
		}
	}
}]);

