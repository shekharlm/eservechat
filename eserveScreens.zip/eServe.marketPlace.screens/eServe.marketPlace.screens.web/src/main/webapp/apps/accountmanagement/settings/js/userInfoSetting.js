angular.module('userInfoSettings', ['ui.bootstrap.dropdownToggle']).controller('userinfosetting', function($scope,$http, privacySettingList){

	privacySettingList.get(function(data){
	
		$scope.privacySettingList = data.statusMessage;
	});
	
	$scope.savePrivacySetting = function() {
		for( var sg = 0; sg < $scope.privacySettingList.settingGroups.length; sg++ )
		{
			delete $scope.privacySettingList.settingGroups[sg].$$hashKey;
			
			for( var ss = 0; ss < $scope.privacySettingList.settingGroups[sg].settings.length; ss++ )
			{
				delete $scope.privacySettingList.settingGroups[sg].settings[ss].$$hashKey;
				
				if( $scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices.length != 0 ) {
					for( var sc = 0; sc < $scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices.length; sc++) {
						
						delete $scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices[sc].$$hashKey;

					}
				}
			}
		}
		alert(JSON.stringify($scope.privacySettingList));
	}
	$scope.SettingHasChoice = function(event) {
		for( var sg = 0; sg < $scope.privacySettingList.settingGroups.length; sg++ )
		{
			delete $scope.privacySettingList.settingGroups[sg].$$hashKey;
			
			for( var ss = 0; ss < $scope.privacySettingList.settingGroups[sg].settings.length; ss++ )
			{
				delete $scope.privacySettingList.settingGroups[sg].settings[ss].$$hashKey;
				
				if( $scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices.length != 0 ) {
					for( var sc = 0; sc < $scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices.length; sc++) {
						
						delete $scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices[sc].$$hashKey;
						if( event.currentTarget.getAttribute('sgid') == $scope.privacySettingList.settingGroups[sg].id )
						{
							if( event.currentTarget.getAttribute('id') == $scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices[sc].id && event.currentTarget.getAttribute('settingid') == $scope.privacySettingList.settingGroups[sg].settings[ss].id )
							{
								$scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices[sc].status = 1;
								event.currentTarget.setAttribute('selected','selected');
							}else {
								$scope.privacySettingList.settingGroups[sg].settings[ss].settingHasChoices[sc].status = 0;
								event.currentTarget.removeAttribute('selected');
							}
						}
						
					}
				}
			}
		}
	}
	
	
	$scope.SettingCheckBox = function(event) {
		for( var sg = 0; sg < $scope.privacySettingList.settingGroups.length; sg++ )
		{
			delete $scope.privacySettingList.settingGroups[sg].$$hashKey;
			
			for( var ss = 0; ss < $scope.privacySettingList.settingGroups[sg].settings.length; ss++ )
			{
				if( event.currentTarget.checked == true )
				{
					if( event.currentTarget.getAttribute('sgid') == $scope.privacySettingList.settingGroups[sg].id && event.currentTarget.getAttribute('settingid') == $scope.privacySettingList.settingGroups[sg].settings[ss].id )
					{
						$scope.privacySettingList.settingGroups[sg].settings[ss].status = 1;
						event.currentTarget.setAttribute('checked','checked');
					}
				}else
				{
					if( event.currentTarget.getAttribute('sgid') == $scope.privacySettingList.settingGroups[sg].id && event.currentTarget.getAttribute('settingid') == $scope.privacySettingList.settingGroups[sg].settings[ss].id )
					{
						$scope.privacySettingList.settingGroups[sg].settings[ss].status = 0;
						event.currentTarget.removeAttribute('checked');
					}
				}
				
			}
		}
	}
	setTimeout('selectOption()',3000);
}).factory('privacySettingList', ['$http', function($http){
	return{
		name: 'Privacy Setting List',
		get: function(callback){
			
			$http({url:"/eServe.marketPlace.accountmanagement.accountsettings-web/settings/settingsdisplay/populateusersettings?category_id=4",dataType:"JSON",method:"POST",headers: {'Content-type': 'application/json'} }).success(function(data) {
				// prepare data here
				callback(data);
			});
		}
	}
}]);