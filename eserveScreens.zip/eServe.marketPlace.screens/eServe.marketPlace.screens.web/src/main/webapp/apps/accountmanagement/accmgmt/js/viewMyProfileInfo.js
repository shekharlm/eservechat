var viewProfileAppAuth = angular.module('viewMyProfile', ['ui.bootstrap.dropdownToggle', 'invite.friends','ui.bootstrap']);

function viewMyProfileAppCntrl($scope,$http,userProfileInfo)
{
	userProfileInfo.get(function(data){
		$scope.userProfileInfoUpdate = data.userobj;
		if( $scope.userProfileInfoUpdate != undefined )
		{
			if($scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "CLIENT_BUSINESS" )
			{
				$scope.companyName = $scope.userProfileInfoUpdate.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
				$scope.CompanyNav = "viewCliCompany.jsp";
			}
			else if( $scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "PROVIDER_BUSINESS" )
			{
				$scope.companyName = $scope.userProfileInfoUpdate.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
				$scope.CompanyNav = "viewProvCompany.jsp";
			}else if( $scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "PROVIDER" )
			{
				$('#account-link').css('display','none')
			}
		}
		
		if( $scope.userProfileInfoUpdate != undefined )
		{
			if( $scope.userProfileInfoUpdate.accountStatus.toLowerCase() == INACTIVE )
			{
				$('.errorBlock').css('display','block');
			}
		}
	});
	$scope.updateemploymentprofile = function(scope,element){
		var urlpath = "";
		if( $scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "PROVIDER" )
		{
			urlpath = "/eServe.marketPlace.accountmanagement.profiles-web/profiles/update/updateProviderProfileInfo";
		}else if( $scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "PROVIDER_BUSINESS" )
		{
			urlpath = "/eServe.marketPlace.accountmanagement.profiles-web/profiles/update/updateProviderBProfileInfo";
		}else if( $scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "CLIENT_BUSINESS" )
		{
			urlpath = "/eServe.marketPlace.accountmanagement.profiles-web/profiles/update/updateClientBProfileInfo";
		}
		$http({ url: urlpath, method: "POST", headers: {'Content-type': 'application/json'}, data:JSON.stringify($scope.userProfileInfoUpdate)
		}).success(function (resp) {
			if(resp.status.toLowerCase() == FAIL )
			{
				alert('Error occure while saving the modification');
			}else
			{
				alert('Your profile information has been updated successfully');
			}
			
        }).
        error(function(resp) {
        	alert(resp);
        });	
	}
}

viewProfileAppAuth.factory('userProfileInfo', ['$http', function($http){
	return{
		name: 'Basic Info',
		get: function(callback){
			//var mailAddress = window.location.search.split('=').pop();
			// After Testing Need to replace the URL
			// /eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/profileinf
			// data/profile.json
			$http.get('/eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/basicinf').success(function(data) {
			// prepare data here
			callback(data);
			});
		}
	}
}]);

function AlertCtrl($scope) {
  $scope.alerts = [
    { type: 'error', msg: 'Email Address not yet verified. Please verify it.' }
  ];

  $scope.addAlert = function() {
    $scope.alerts.push({msg: "Another alert!"});
  };

  $scope.closeAlert = function(index) {
    $scope.alerts.splice(index, 1);
  };
}


var options = {
			
   onFail: function() {
		for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
		{
			 $($myform.getInvalid()[errlen]).addClass('invalid')
			 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
		}
   },
   onSuccess: function() {
		$('#updateProfileInfo').trigger('click');
   },

   inputs: {
     'password': {
       filters: 'required password',
     },
     'username': {
       filters: 'required username',
       data: {
        
       }
     },
     'file': {
       filters: 'extension',
       data: { extension: ['jpg'] }
     },
     'number': {
   	  filters: 'required number',
   	  data: { min: 10, max: 15 }
     },
     'comments': {
       filters: 'min max',
       data: { min: 50, max: 200 }
     },
     /*'Country': {
       filters: 'exclude',
       data: { exclude: ['default'] },
       errors : {
         exclude: 'Select a Country.'
       }
     },
     'State': {
         filters: 'exclude',
         data: { exclude: ['default'] },
         errors : {
           exclude: 'Select a State.'
         }
       },*/
     'langs[]': {
       filters: 'min max',
       data: { min: 1, max: 1 },
       errors: {
         min: 'Please Accept the term and condition.',
         max: 'Please Accept the term and condition.'
       }
     }
   }
 };

 var $myform = $('#my-form').idealforms(options).data('idealforms');