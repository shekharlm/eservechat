var eserveSkillsAuth = angular.module('viewskills', ['ui.bootstrap.dropdownToggle', 'addskills']);

function displayUserSkillsCntrl($scope, $http, skillsList)
{
	skillsList.get(function(data){
		$scope.userSkills = data.skill;
	});
}

eserveSkillsAuth.factory('skillsList', ['$http', function($http){
	return{
		name: 'Skills List Info',
		get: function(callback){
			$http({ url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/skills/displaySkills", method: "GET", headers: {'Content-type': 'application/json'}
			}).success(function (resp) {
				if( resp.status.toLowerCase() != SUCCESS )
				{
					$('button[data-dismiss=modal]').trigger('click');
					$('#addskillspopup').trigger('click');
				}
				callback(resp);
	        }).
	        error(function(resp) {
	        	alert("Error in Display Skills List");
	        });	
		}
	}
}]);
