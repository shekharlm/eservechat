angular.module('invite.friends', []).controller('invitePopupCntrl', function($scope,$http,userInviteInfo){
	$scope.inviteEmailId="";
	userInviteInfo.get(function(data){
		$scope.userInviteInfo = data;
	})
	$scope.dismiss = function(){
		 $('button[data-dismiss=modal]').trigger('click');
		$scope.inviteEmailId="";
	}
	$scope.inviteusers = function(){
		$scope.userInviteInfo.emailSentTo = $scope.inviteEmailId;
		$http({ url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/sendinvitefriend", method: "POST", headers: {'Content-type': 'application/json'},dataType:"JSON",data:JSON.stringify($scope.userInviteInfo)
		}).success(function (resp) {
			if( resp.message.toLowerCase() == SUCCESS )
			{
				alert('Your invitation has been sent successfully');
				$('button[data-dismiss=modal]').trigger('click');
				$('#accinvitepopup').trigger('click');
				$scope.inviteEmailId="";
			}else if(resp.message.toLowerCase() == ACCEPTED ){
				alert("Email already Accepted");
			}else if(resp.message.toLowerCase() == FAILED){
				alert("Error in proccessing request");
			}else if(resp.message.toLowerCase() == NOTEXPIRED){
				alert("User already invited");
			}else if(resp.message.toLowerCase() == EXISTS){
				alert("User already have eServe Account");
			}else if(resp.message.toLowerCase() == INVALID){
				alert("Invalid user logged In");
			}
        }).
        error(function(resp) {
        	alert("Error Invite friend");
        });	
		
	}
}).factory('userInviteInfo', ['$http', function($http){
	return{
		name: 'Invite User Info',
		get: function(callback){
			/*"../../profiles/blankJsonOfUserHasInvitation"*/
			$http({ url:"/eServe.marketPlace.accountmanagement.profiles-web/profiles/blankJsonOfUserHasInvitation", method:"GET", dataType: "JSON", headers: {'Content-type': 'application/json'} }).success(function(data){
			
			callback(data);
			});
		}
	}
}]);

