
// Displaying the change password fields
// After UI validation the passed has been updated in DB.


var cpsecurityApp = angular.module("cpsecurityApp", []);
	
	function changepwdCntrl($scope, $http)
	{
		
		$scope.password ="";
		$scope.conformpassword = "";
		$scope.submitchangepwd = function() {
			if( $scope.password == $scope.conformpassword )	
			{
				var emailAddress = window.location.href.split('=').pop();
				var sendJson = { email:emailAddress, password:$scope.conformpassword }
				$http({ url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/createnewpassword", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'}, data:JSON.stringify(sendJson) 
				}).success(function (resp) {
					if( resp.message.toLowerCase() == SUCCESS )
					{
						$scope.alert =  { type: 'alert-success', msg: 'Your password changed successfully. Please click here to Login', errorDisplay: "displayBlock" }
						changepwdalertCtrl($scope);
						alert('Your password has been updated successfully. Please re-login again with new password')
						window.location = "/eServe.marketPlace.screens.web/index.jsp";
					}
					else if( resp.message.toLowerCase() == INVALID ) {
						$scope.alert =  { type: 'alert-error', msg: 'Invalid User', errorDisplay: "displayBlock" }
						changepwdalertCtrl($scope);
					}else
					{
						$scope.alert =  { type: 'alert-error', msg: 'Error While Processing the request', errorDisplay: "displayBlock" }
						changepwdalertCtrl($scope);
					}
		            
		        }).
		        error(function(resp) {
		        	alert(AJAXERROR);
		        });		
			}else
			{
				$scope.alert =  { type: 'alert-error', msg: 'Password mismatch. Please enter the valid password', errorDisplay: "displayBlock" }
				changepwdalertCtrl($scope);
				$scope.password ="";
				$scope.conformpassword = "";
			}
		}
		
		
		var activationToken = window.location.href.split('?').pop();
		if( activationToken != undefined && activationToken.split('=')[0] != 'emailId' )
		{
			$http({url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/verifypasswordlink/"+activationToken, method: "POST" }).success(function (resp) {
	          
	            if( resp.message.toLowerCase() == INVALID )
	            {
	            	alert('Reset password link is broken. Please click to proceed to resend the password link.');
	            	window.location="/eServe.marketPlace.screens.web/pages/fp/forgetpassword.jsp";
	            }
	            else  if( resp.message.toLowerCase() == SUCCESS )
	            {
	            	window.location = "/eServe.marketPlace.screens.web/pages/fp/changepassword.jsp?emailId="+resp.email;
	            }
	        });	
		}
		
	}
		
	function changepwdalertCtrl($scope) {
	  $scope.closeAlert = function(index) {
	    $scope.alerts.splice(index, 1);
	  };

	}

	 var options = {
				
	    onFail: function() {
			for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
			{
				 $($myform.getInvalid()[errlen]).addClass('invalid')
				 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
			}
	    },
	    onSuccess: function() {
			$('#changePasswordId').trigger('click');
	    },
	
	    inputs: {
	      'password': {
	        filters: 'required password',
	      },
	      'username': {
	        filters: 'required username',
	        data: {
	         
	        }
	      },
	      'file': {
	        filters: 'extension',
	        data: { extension: ['jpg'] }
	      },
	
	      'comments': {
	        filters: 'min max',
	        data: { min: 50, max: 200 }
	      },
	      'country': {
	        filters: 'exclude',
	        data: { exclude: ['default'] },
	        errors : {
	          exclude: 'Select a Country.'
	        }
	      },
	      'langs[]': {
	        filters: 'min max',
	        data: { min: 1, max: 1 },
	        errors: {
	          min: 'Please Accept the term and condition.',
	          max: 'Please Accept the term and condition.'
	        }
	      }
	    }
	  };
	
	  var $myform = $('#my-form').idealforms(options).data('idealforms');