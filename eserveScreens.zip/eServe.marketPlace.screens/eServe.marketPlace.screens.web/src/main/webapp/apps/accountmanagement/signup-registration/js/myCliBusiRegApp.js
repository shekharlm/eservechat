angular.module('myRegApp', []).controller('regCliBusinessApp', function($scope, $http, regData, industryType) {
	
	regData.get(function(data){
		$scope.registrationData = data;
	}); 
	
	
	industryType.get(function(data){
		$scope.industryTypes = data;
	});
	
	$scope.$watch('companycountryphone', function(text) {
		if($scope.registrationData != undefined ) {
			if( $scope.registrationData.clientBuisnessProfiles != null && $scope.registrationData.clientBuisnessProfiles != "" )
			{
				$scope.registrationData.providerBuisnessProfiles.contactPhoneNo = "";
				var phonecode = companycountryphone.options[companycountryphone.options.selectedIndex].text.split(' ').pop();
				$scope.registrationData.clientBuisnessProfiles.contactPhoneNo = phonecode + '-' + $scope.registrationData.clientBuisnessProfiles.contactPhoneNo;
			
			}else
			{
				$scope.registrationData.providerBuisnessProfiles.contactPhoneNo = "";
				var phonecode = companycountryphone.options[companycountryphone.options.selectedIndex].text.split(' ').pop();
				$scope.registrationData.providerBuisnessProfiles.contactPhoneNo = phonecode + '-' + $scope.registrationData.providerBuisnessProfiles.contactPhoneNo;
			
			}
		}
	});
	
		
	$scope.$watch('countryphone', function(text) {
		if($scope.registrationData != undefined ) {
			$scope.registrationData.phoneNumber = "";
			var phonecode = countryphone.options[countryphone.options.selectedIndex].text.split(' ').pop();
			$scope.registrationData.userContacts[0].contactNumber = phonecode + '-' + $scope.registrationData.userContacts[0].contactNumber;
		}
	});
	
	$scope.Done = function(event) { 
		$scope.registrationData.emailId = window.location.search.split('?')[1].split('=')[1];
		$http({url: "/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/updateClientBusinessProfile", method: "PUT", headers: {'Content-type': 'application/json'}, data: JSON.stringify($scope.registrationData) }).success(function (resp) {
			 alert('Thanks for registration. Please login.');
			 window.location = "/eServe.marketPlace.screens.web/index.jsp"; 
		});
				
	}
}).factory('regData', ['$http', function($http){
	return{
		name: 'Registration Info',
		get: function(callback){
			$http({url: "/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/providerInfo",dataType:"JSON", method:"GET" }).success(function (data) {
				callback(data)
			});	
		}
	}
}]).factory('industryType', ['$http', function($http){
	return{
		name: 'Industry List',
		get: function(callback){
			$http({url: "/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/industryType",dataType:"JSON", method:"GET" }).success(function (data) {
				callback(data)
			});	
		}
	}
}]);

var options = {
		
	    onFail: function() {
			for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
			{
				 $($myform.getInvalid()[errlen]).addClass('invalid')
				 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
			}
	    },
	    onSuccess: function() {
			$('#cliBussinessRegDone').trigger('click');
	    },
	
	    inputs: {
	      'password': {
	        filters: 'required password',
	      },
	      'username': {
	        filters: 'required username',
	        data: {
	         
	        }
	      },
	      'tagName': {
		        filters: 'required username',
		        data: {
		         
		        }
		   },
	      'companyname': {
		        filters: 'required username',
		        data: {
		         
		     }
	      },
	      'companyOverview' : {
	        	filters: 'required username',
		        data: {
		         
		       }
	       },
	      'file': {
	        /* filters: 'extension',
	        data: { extension: [] } */
	      },
	      'number': {
	    	  filters: 'optional number',
	    	  data: { min: 10, max: 15 }
	      },
	      'industryType': {
	        filters: 'exclude',
	        data: { exclude: ['default'] },
	        errors : {
	          exclude: 'Select a Industry Type.'
	        }
	      }
	    }
	  };
	
	  
	var $myform = $('#my-form').idealforms(options).data('idealforms');
