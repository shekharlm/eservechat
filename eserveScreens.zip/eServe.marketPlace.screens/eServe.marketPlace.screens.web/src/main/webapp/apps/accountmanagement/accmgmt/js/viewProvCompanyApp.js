var viewMyProfileApp = angular.module('viewProvCompanyApp', ['ui.bootstrap.dropdownToggle', 'invite.friends']);
viewMyProfileApp.factory('userInfo', ['$http', function($http){
return{
	name: 'Basic User Info',
	get: function(callback){
		///eServe.marketPlace.accountmanagement.profiles-web/profiles/profiles/displayprofile
		$http({url:'/eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/basicinf', method:"GET", dataType: "JSON", headers: {'Content-type': 'application/json'}}).success(function(data) {
			callback(data);
		});
	}
	}
}]);
function viewProvCompanyCntrl($scope,$http, userInfo)
{
	userInfo.get(function(data) {
		$scope.ProvCompanyInfo = data.userobj;
		
		if( $scope.ProvCompanyInfo != undefined )
		{
			if($scope.ProvCompanyInfo.userHasProfiles[0].profileType.profileType == "CLIENT_BUSINESS" )
			{
				$scope.companyName = $scope.ProvCompanyInfo.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
			}
			else if( $scope.ProvCompanyInfo.userHasProfiles[0].profileType.profileType == "PROVIDER_BUSINESS" )
			{
				$scope.companyName = $scope.ProvCompanyInfo.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
			}
			else if( $scope.ProvCompanyInfo.userHasProfiles[0].profileType.profileType == "PROVIDER" )
			{
				$('#account-link').css('display','none')
			}
		}
	});
	$scope.updatecompanyinfo = function(){
		var urlpath = "";
		if( $scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "PROVIDER" )
		{
			urlpath = "/eServe.marketPlace.accountmanagement.profiles-web/profiles/update/updateProviderProfileInfo";
		}else if( $scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "PROVIDER_BUSINESS" )
		{
			urlpath = "/eServe.marketPlace.accountmanagement.profiles-web/profiles/update/updateProviderBProfileInfo";
		}else if( $scope.userProfileInfoUpdate.userHasProfiles[0].profileType.profileType == "CLIENT_BUSINESS" )
		{
			urlpath = "/eServe.marketPlace.accountmanagement.profiles-web/profiles/update/updateClientBProfileInfo";
		}
		$http({url:urlpath, method:"GET", dataType: "JSON", headers: {'Content-type': 'application/json'}}).success(function(data) {
			callback(data);
		});
	}
}

function AlertCtrl($scope) {
	  $scope.alerts = [
	    { type: 'error', msg: 'Email Address not yet verified. Please verify it.' }
	  ];

	  $scope.addAlert = function() {
	    $scope.alerts.push({msg: "Another alert!"});
	  };

	  $scope.closeAlert = function(index) {
	    $scope.alerts.splice(index, 1);
	  };

	}



var options = {
		
	    onFail: function() {
			for( var errlen = 0; errlen < $myform.getInvalid().length; errlen++ )
			{
				 $($myform.getInvalid()[errlen]).addClass('invalid')
				 $($myform.getInvalid()[errlen].nextSibling).css('display','block');
			}
	    },
	    onSuccess: function() {
			$('#provBussinessUpdateDone').trigger('click');
	    },
	
	    inputs: {
	      'password': {
	        filters: 'required password',
	      },
	      'username': {
	        filters: 'required username',
	        data: {
	         
	        }
	      },
	      'tagName': {
		        filters: 'required username',
		        data: {
		         
		        }
		   },
	      'companyname': {
		        filters: 'required username',
		        data: {
		         
		     }
	      },
	      'companyOverview' : {
	        	filters: 'required username',
		        data: {
		         
		       }
	       },
	      'file': {
	        /* filters: 'extension',
	        data: { extension: [] } */
	      },
	      'number': {
	    	  filters: 'optional number',
	    	  data: { min: 10, max: 15 }
	      },
	      'Industry Type': {
	        filters: 'exclude',
	        data: { exclude: ['default'] },
	        errors : {
	          exclude: 'Select a Industry Type.'
	        }
	      }
	    }
	  };
	
	  
	var $myform = $('#my-form').idealforms(options).data('idealforms');