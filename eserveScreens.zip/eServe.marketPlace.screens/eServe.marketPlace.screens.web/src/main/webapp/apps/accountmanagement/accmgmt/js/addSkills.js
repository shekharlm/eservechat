angular.module('addskills', []).controller('addSkillsPopupCntrl', function($scope,$http,ListOfSkillsType){
	$scope.inviteEmailId="";
	$scope.dismiss = function(){
		 $('button[data-dismiss=modal]').trigger('click');
	}
	ListOfSkillsType.get(function(data){
		$scope.listOfSkillType =  data.skilltype;
		setTimeout('skillTypeOption()',3000);
	});
	
	$scope.$watch('listOfSkillType.id', function(value) {
		if($scope.listOfSkillType != undefined ) {
			// Test URL data/listOfSkills.json
			$http.get('/eServe.marketPlace.accountmanagement.profiles-web/profiles/skills/skillsbytype/'+value).success(function(data) {
				$scope.listOfSkills = data.statusMessage;
				setTimeout('skillsOption()',3000);
			});
		}
	});
	$scope.addSkills = function(){
		$http({ url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/skills/addskilltouser/"+$scope.skillName.id, method: "POST", headers: {'Content-type': 'application/json'}
		}).success(function (resp) {
			if( resp.status.toLowerCase() == SUCCESS )
			{
				alert(resp.statusMessage);
				//$('button[data-dismiss=modal]').trigger('click');
				//$('#addskillspopup').trigger('click');
				location.reload(); // Not correct way need to find solution like refresh skills div only.
			}
			else if( resp.status.toLowerCase() == FAILED )
			{
				alert(resp.statusMessage);
				//$('button[data-dismiss=modal]').trigger('click');
				//$('#addskillspopup').trigger('click');
			}
        }).
        error(function(resp) {
        	alert("Add Skills Error");
        });	
		
	}
}).factory('ListOfSkillsType', ['$http', function($http){
	return{
		name: 'Skills Type Info',
		get: function(callback){
			// Test URL  data/skillTypeList.json
			$http({url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/skills/displaySkillType",dataType:"JSON", headers: {'Content-type': 'application/json'},method:"GET" }).success(function (data) {
				callback(data);
			});	
		}
	}
}]);


function skillTypeOption()
{
	$('#skillsType option')[1].selected = true;
}

function skillsOption()
{
	$('#skills option')[1].selected = true;
}