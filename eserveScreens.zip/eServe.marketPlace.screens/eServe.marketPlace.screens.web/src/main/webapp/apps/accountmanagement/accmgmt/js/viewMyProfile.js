var viewMyProfileApp = angular.module('viewMyProfileApp', ['ui.bootstrap.dropdownToggle', 'invite.friends']);
viewMyProfileApp.factory('userInfo', ['$http', function($http){
return{
	name: 'Basic User Info',
	get: function(callback){
		// /eServe.marketPlace.accountmanagement.profiles-web/profiles/profiles/displayprofile
		$http({url:'data/profile.json', method:"GET", dataType: "JSON", headers: {'Content-type': 'application/json'}}).success(function(data) {
			callback(data);
		});
	}
	}
}]);
function basicInfoCntrl($scope,$http, userInfo)
{
	userInfo.get(function(data) {
		$scope.userInfo = data
	});
	if(userInfo.userHasProfiles[0].profileType.profileType == "ClientBusiness" )
	{
		$scope.companyName = $scope.userInfo.clientBuisnessProfiles[0].company.companyName;
	}
	else if( userInfo.userHasProfiles[0].profileType.profileType == "ProviderBusiness" )
	{
		$scope.companyName = $scope.userInfo.clientBuisnessProfiles[0].company.companyName;
	}
}

