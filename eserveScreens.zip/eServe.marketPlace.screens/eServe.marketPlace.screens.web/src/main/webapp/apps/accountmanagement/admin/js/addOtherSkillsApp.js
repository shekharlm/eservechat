angular.module('addSkillsAdminAppAuth', ['ui.bootstrap.dropdownToggle']).controller('addSkillsAdminCntrl', function($scope,$http,otherSkillsList){
	
	otherSkillsList.get(function(data){
		$scope.otherSkillsData =  data.statusMessage;
		$("#addSkillsBtn").hide();
		
	});
	$scope.cancel = function(){
		
	};
	$scope.updateSkillsStatus = function(element){
		var clickedmailid = element.target.getAttribute('emailId');
		for( var ulen = 0; ulen < $scope.otherSkillsData.otherSkills.length; ulen++ )
		{
			if(  $scope.otherSkillsData.otherSkills[ulen].id == clickedmailid && element.target.checked == true )
			{
				$scope.otherSkillsData.otherSkills[ulen].status = "1";
				$("#addSkillsBtn").show();
				$("#addSkillsToggle").show();
			}
			else if( $scope.otherSkillsData.otherSkills[ulen].id == clickedmailid && element.target.checked == false )
			{
				$scope.otherSkillsData.otherSkills[ulen].status = "0";
				$("#addSkillsBtn").hide();
				$("#addSkillsToggle").hide();
			}
		}
	};
	$scope.saveSkills = function(){
		for( var roskill = 0; roskill < $scope.otherSkillsData.skillTypes.length; roskill++ )
		{
			delete $scope.otherSkillsData.skillTypes[roskill].$$hashKey;
		}
		for( var roskill = 0; roskill < $scope.otherSkillsData.otherSkills.length; roskill++ )
		{
			delete $scope.otherSkillsData.otherSkills[roskill].$$hashKey;
		}
		$scope.otherSkillsData.adminEmailId = "vikash.pandey@ariveguru.com";
		alert(JSON.stringify($scope.otherSkillsData));
		
		$http({ url:" /eServe.marketPlace.accountmanagement.eServerAdmin-web/rest/admin/addskill", method: "POST",dataType:"JSON", headers: {'Content-type': 'application/json'},  data: $scope.otherSkillsData }).success(function (resp) {
            alert('New skill created successfully.');
            window.href="/eServe.marketPlace.screens.web/pages/ad/addOtherSkills.jsp";
        });	
	};
}).factory('otherSkillsList', ['$http', function($http){
	return{
		name: 'Others Skills List',
		get: function(callback){
			$http.get(' /eServe.marketPlace.accountmanagement.eServerAdmin-web/rest/admin/populateotherskills').success(function(data) {
				// prepare data here
				callback(data);
			});
		}
	}
}]);
