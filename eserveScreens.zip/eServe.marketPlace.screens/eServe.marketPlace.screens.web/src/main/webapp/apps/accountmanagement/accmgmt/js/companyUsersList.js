angular.module('companyUsersList', ['ui.bootstrap.dropdownToggle', 'invite.friends']).controller('companyUsersListCntrl', function($scope,$http, companyUsersList){

	companyUsersList.get(function(data){
		$scope.companyUsersList = data;
	});
	$scope.deleteAccount = function(element){
		var empId = element.target.getAttribute('uid');
		var profileType = element.target.getAttribute('profileType');
		var sendJson = {emporconsId:empId, type: profileType}
		var conform = confirm("Are you sure want to delete account");
		if( conform == true )
		{
			$http({url:"/eServe.marketPlace.accountmanagement.profiles-web/profiles/deleteEmployeeOrConsultant",dataType:"JSON",method:"POST",headers: {'Content-type': 'application/json'},data:JSON.stringify(sendJson)}).success(function(data) {
				if(data.message.toLowerCase() == SUCCESS ){
					alert("deleted successfully");
				}else{
					alert("Error in delete contact web master admin");
				}
			});
		}
	}

}).factory('companyUsersList', ['$http', function($http){
	return{
		name: 'Companies List',
		get: function(callback){
			var selectedCompanyId = window.location.href.split('?').pop();
			$http({url:"/eServe.marketPlace.accountmanagement.profiles-web/profiles/getEmployeeOrConsultantProfilesByCompany",dataType:"JSON",method:"POST",headers: {'Content-type': 'application/json'},data:selectedCompanyId}).success(function(data) {
				// prepare data here
				callback(data);
			});
			
		}
	}
}]);

