	var myAuth = angular.module('myAppAuth', ['ui.bootstrap', 'plunker']);
	
	var myApp = angular.module('myApp',[],function($routeProvider) {        
	    
	    $routeProvider
	    //.when('/home',{templateUrl:'home.html'})
	    .when('/appOne',{templateUrl:'appOne.html',controller:'oneCtrl'})
	    .when('/appTwo',{templateUrl:'appTwo.html'})
	    //.otherwise({redirectTo:'/home'});
	    
	});
	
	myAuth.factory("signupData", function() {
		var signupData = {};
		signupData = {
				"displayName" : "",
				"emailId" : "",
				"emailId" : "password"
			}
		return signupData;
	});
	
	myAuth.factory("loginData", function() {
	
		var loginData = {};
		loginData = {
				"email_Id" : "",
				"password" : "",
			}
		return loginData;
	});
	
	

	function loginCntrl($scope, $http, loginData)
	{
		$scope.loginData = loginData;
		$scope.loginsubmit = function($scope) {
			alert(JSON.stringify(loginData));
			$http({ method: "POST",  data: {"resp": "ok" } }).success(function (resp) {
	            alert('success');
	        });			
		}
	}
	
	function signupCntrl($scope, $http, signupData)
	{
		$scope.signupData = signupData;
		$scope.signupsubmit = function($scope) {
			/*url: 'eServe/eServe/addBasic'*/
			$http({ url: "", method: "POST", headers: {'Content-type': 'application/json'}, data:JSON.stringify(signupData)
			}).success(function (resp) {
				$('#triggerpopup').trigger('click');
	        }).
	        error(function(resp) {
	        	alert(resp);
	        });		
		}
	}
