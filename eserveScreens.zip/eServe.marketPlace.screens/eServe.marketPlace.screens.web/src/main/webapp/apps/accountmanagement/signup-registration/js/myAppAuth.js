	var myAuth = angular.module('myAppAuth', ['ui.bootstrap', 'plunker']);
	
	myAuth.factory("signupData", function() {
		var signupData = {};
		signupData = {
				"displayName" : "",
				"emailId" : "",
				"password" : "",
				"country" : {"id" : "84" , "countryName": ""},
				"accountType" :"1"
			}
		return signupData;
	});
	
	myAuth.factory("loginData", function() {
		var loginData = {};
		loginData = {
				"emailId" : "",
				"password" : "",
			}
		return loginData;
	});
	myAuth.factory('countryList', ['$http', function($http){
		return{
			name: 'Country List',
			get: function(callback){
				//$http.get('file:///home/palanivel/git/eserve-marketplace/eServe.marketPlace/eServe.marketPlace.accountmanagement.signup/eServe.marketPlace.accountmanagement.signup-web/src/main/webapp/apps/accountmanagement/signup-registration/data/country.json').success(function(data) {
				$http.get("/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/Countries").success(function(data){
				// prepare data here
				
				callback(data);
				});
			}
		}
	}]);
	
	

	function loginCntrl($scope, $http, loginData)
	{
		$scope.loginData = loginData;
		$scope.loginsubmit = function($scope) {
			if(loginData.emailId != "" && loginData.password != "" ){
				$http({url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/login/logincheck", method: "POST", data: JSON.stringify(loginData) }).success(function (resp) {
		            if( resp.status.toLowerCase() == FAILED )
		            {
		            	alert(resp.statusMessage);
		            }
		            else
		            {
		            	window.location = '/eServe.marketPlace.screens.web/'+'home.jsp'+'?emailId='+loginData.emailId
		            }
		        });	
			}
			else
			{
				alert('Please enter Email/Password....!');
			}
		}
		
		var activationToken = window.location.href.split('?').pop()
		if( activationToken != "index.jsp" )
		{
			$http({url: "/eServe.marketPlace.accountmanagement.profiles-web/profiles/emailVerification/"+activationToken, method: "GET" }).success(function (resp) {
	            if( resp.message.toLowerCase() == FAIL )
	            {
	            	alert('Invaid activation token');
	            }
	            else  if( resp.message.toLowerCase() == RESENT )
	            {
	            	alert('This Activation token as already expired and new activation token has been sent your email. Please click on the link to activate.');
	            }else  if( resp.message.toLowerCase() == ACTIVE )
	            {
	            	alert('Your account is already active. Please login.');
	            	window.location = '/eServe.marketPlace.screens.web/';
	            }
	            else  if( resp.message.toLowerCase() == LOCKED )
	            {
	            	alert('Since account has been blocked, this activation token is invalid. Please send a request to eserve admin to reopen.');
	            }
	            else  if( resp.message.toLowerCase() == SUCCESS )
	            {
	            	alert('Your account has been successfully verified. Please login.');
	            	window.location = '/eServe.marketPlace.screens.web/';
	            }
	        });	
		}
	}
	
	function signupCntrl($scope, $http, signupData, countryList)
	{
		countryList.get(function(data){
			$scope.countryList = data;
		}); 
		
		
		$scope.signupData = signupData;
		
		$scope.signupsubmit = function($scope) {
			/*url: 'eServe/eServe/addBasic'*/
			if( $('#country').val() != "? string: ?" && $('#country').val() != "" && $('#country').val() != "default" ) //Temp code for checking the country selection.
			{
				var accountTypeId = signupData.accountType;
				delete signupData.accountType;
				$http({ url: "/eServe.marketPlace.accountmanagement.signup-web/eServe/Registration/addBasic/"+accountTypeId, method: "POST", headers: {'Content-type': 'application/json'}, data:JSON.stringify(signupData)
				}).success(function (resp, $scope) {
					if( resp.status.toLowerCase() == SUCCESS )
					{
						$('#triggerpopup').trigger('click');
						var useremail = signupData.emailId;
						var selectedAccount = accountTypeId;
						if( selectedAccount.toLowerCase() == ACCOUNTTYPEPROVIDERID )
			            {
			            	window.location = "/eServe.marketPlace.screens.web/pages/registration/pregistration.jsp?emailId="+useremail+"?profileType="+selectedAccount;
			            }
			            else if( selectedAccount.toLowerCase() == ACCOUNTTYPEPROVIDERBUSINESSID )
			            {
			            	window.location = "/eServe.marketPlace.screens.web/pages/registration/bregistration.jsp?emailId="+useremail+"?profileType="+selectedAccount;
			            }
			            else if( selectedAccount.toLowerCase() == ACCOUNTTYPEPROVIDERBUSSINESSID )
			            {
			            	window.location = "/eServe.marketPlace.screens.web/pages/registration/bcregistration.jsp?emailId="+useremail+"?profileType="+selectedAccount;
			            }
			        
					}else if( resp.status.toLowerCase() == FAILED )
					{
						alert("You can't able to signup to eserve. Please try later.");
					}
					else if( resp.status.toLowerCase() == ACTIVE )
					{
						alert('You already signed in eserve system. Please login');
					}else if( resp.status.toLowerCase() == INACTIVE )
					{
						$('#triggerpopup').trigger('click');
						$('#heading').empty();
						$('#content p').empty();
						$('#heading').append('Account Inactive');
						$('#content p').append('You already signed in eserve system and your account is Inactive. Please check your mail and activate your account.');
					}else if( resp.status.toLowerCase() == BLOCKED )
					{
						alert('Due to some reason your eserve has been blocked.');
					}
					
		        }).
		        error(function(resp, $scope) {
		        	alert(AJAXERROR);
		        	alert($scope);
		        });	
			}else
			{
				$('#country').parent().next().html("choose a country");
				$('#country').parent().next().css('display','block');
			}
		}
			
	}
	