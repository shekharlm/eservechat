var viewProfileAppAuth = angular.module('viewProfile', ['ui.bootstrap.dropdownToggle', 'invite.friends','ui.bootstrap']);

function viewProfileAppCntrl($scope,$http,userBasicInfo)
{
	userBasicInfo.get(function(data){
		$scope.userBasicInfo = data.userobj;
		if( $scope.userBasicInfo != undefined )
		{
			if($scope.userBasicInfo.userHasProfiles[0].profileType.profileType == "CLIENT_BUSINESS" )
			{
				$scope.companyName = $scope.userBasicInfo.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
				$scope.CompanyNav = "viewCliCompany.jsp";
			}
			else if( $scope.userBasicInfo.userHasProfiles[0].profileType.profileType == "PROVIDER_BUSINESS" )
			{
				$scope.companyName = $scope.userBasicInfo.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
				$scope.CompanyNav = "viewProvCompany.jsp";
			}
			else if( $scope.userBasicInfo.userHasProfiles[0].profileType.profileType == "PROVIDER" )
			{
				$('#account-link').css('display','none')
			}
		}
		if( $scope.userBasicInfo != undefined )
		{
			if( $scope.userBasicInfo.accountStatus.toLowerCase() == INACTIVE )
			{
				$('.errorBlock').css('display','block');
			}
		}
	});
	
}

function AlertCtrl($scope) {
  $scope.alerts = [
    { type: 'error', msg: 'Email Address not yet verified. Please verify it.' }
  ];

  $scope.addAlert = function() {
    $scope.alerts.push({msg: "Another alert!"});
  };

  $scope.closeAlert = function(index) {
    $scope.alerts.splice(index, 1);
  };

}

viewProfileAppAuth.factory('userBasicInfo', ['$http', function($http){
	return{
		name: 'Basic Info',
		get: function(callback){
			// /eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/basicinf
			$http.get('/eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/basicinf').success(function(data) {
			// prepare data here
				callback(data);
			});
		}
	}
}]);