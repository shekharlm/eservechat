angular.module('add.photos.portfolio', []).controller('addPphotosPopupCntrl', function($scope,$http){
	$scope.inviteEmailId="";
	$scope.dismiss = function(){
		 $('button[data-dismiss=modal]').trigger('click');
	}
	$scope.addphotos = function(){
		$http({ url: "", method: "POST", headers: {'Content-type': 'application/json'}
		}).success(function (resp) {
			if( resp.status.toLowerCase() != SUCCESS )
			{
				$('button[data-dismiss=modal]').trigger('click');
				$('#accinvitepopup').trigger('click');
			}
        }).
        error(function(resp) {
        	alert("Error forget Password");
        });	
		
	}
});

