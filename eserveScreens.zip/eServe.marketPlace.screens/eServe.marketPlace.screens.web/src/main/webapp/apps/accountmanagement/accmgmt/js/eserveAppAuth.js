var eserveAppAuth = angular.module('eserveAppAuth', ['ui.bootstrap.dropdownToggle', 'invite.friends','ui.bootstrap']);

function homePageAppCntrl($scope,$http,userBasicActionInfo)
{
	userBasicActionInfo.get(function(data){
		$scope.userBasicActionData = data.userobj;
		if( $scope.userBasicActionData != undefined )
		{
			if( $scope.userBasicActionData.accountStatus.toLowerCase() == INACTIVE )
			{
				$('.errorBlock').css('display','block');
			}
		}
		
		
		if( $scope.userBasicActionData != undefined )
		{
			if($scope.userBasicActionData.userHasProfiles[0].profileType.profileType == "CLIENT_BUSINESS" )
			{
				$scope.companyName = $scope.userBasicActionData.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
			}
			else if( $scope.userBasicActionData.userHasProfiles[0].profileType.profileType == "PROVIDER_BUSINESS" )
			{
				$scope.companyName = $scope.userBasicActionData.clientBuisnessProfiles[0].company.companyName;
				$('.nav-left-item')[3].setAttribute('style','display:none');
				$('.nav-left-item')[4].setAttribute('style','display:none');
				$('.nav-left-item')[5].setAttribute('style','display:none');
			}
			else if( $scope.userBasicActionData.userHasProfiles[0].profileType.profileType == "PROVIDER" )
			{
				$('#account-link').css('display','none')
			}
		}
		
	});
	
}

function AlertCtrl($scope) {
  $scope.alerts = [
    { type: 'error', msg: 'Email Address not yet verified. Please verify it.' }
  ];

  $scope.addAlert = function() {
    $scope.alerts.push({msg: "Another alert!"});
  };

  $scope.closeAlert = function(index) {
    $scope.alerts.splice(index, 1);
  };
}

eserveAppAuth.factory('userBasicActionInfo', ['$http', function($http){
	return{
		name: 'Home Page Info',
		get: function(callback){
			 //var userMailID = window.location.search.split('?')[1].split('=')[1];
			// /eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/basicinf
			$http.get('/eServe.marketPlace.accountmanagement.profiles-web/profiles/displayprofile/userinf').success(function(data) {
			// prepare data here
			callback(data);
			});
		}
	}
}]);