var eserveSkillsAuth = angular.module('viewportfolio', ['ui.bootstrap.dropdownToggle', 'add.photos.portfolio', 'add.videos.portfolio']);

function userAppCntrl()
{
	
}