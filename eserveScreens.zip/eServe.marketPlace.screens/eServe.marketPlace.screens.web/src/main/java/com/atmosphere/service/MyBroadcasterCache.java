package com.atmosphere.service;

import java.util.List;

import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.BroadcasterCache;

public class MyBroadcasterCache implements BroadcasterCache{

	@Override
	public void start() {
		// TODO Auto-generated method stub

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addToCache(String id, AtmosphereResource r, Object e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Object> retrieveFromCache(String id, AtmosphereResource r) {
		// TODO Auto-generated method stub
		return null;
	}

}
