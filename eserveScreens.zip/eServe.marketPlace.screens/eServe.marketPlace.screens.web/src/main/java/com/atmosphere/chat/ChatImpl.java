package com.atmosphere.chat;

import java.io.IOException;
import java.util.Date;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.atmosphere.cpr.Broadcaster;
import org.atmosphere.cpr.BroadcasterFactory;
import org.atmosphere.cpr.MetaBroadcaster;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.atmosphere.utils.BroadcastContent;
import com.atmosphere.utils.JsonUtils;

/**
 * @author krish
 *
 */
@Path("/subscribe")
@Stateless
@LocalBean
public class ChatImpl implements IChat {

@Override
@POST
@Path("/chat")
public Response chat(BroadcastContent broadcastContent) throws JsonParseException, JsonMappingException, IOException {
Data data = null;
String subscriberId =  broadcastContent.getSubscriberId();
data = new ObjectMapper().convertValue(broadcastContent.getMessage(), Data.class);
data.setTimeStamp(new Date().getTime());
if (broadcastContent.getMessageType().equals("agent:request")){
subscriberId = "agents";
broadcastContent.setMessage(data);
notifySubscribersGroup(broadcastContent,subscriberId);
}
else{
subscriberId = data.getChatId();
if (broadcastContent.getGroupId()!= null){
subscriberId = "/"+broadcastContent.getGroupId()+"/"+subscriberId;
}
broadcastContent.setMessage(data);
notifySubscribers(broadcastContent,subscriberId);	
}
return Response.ok().build();
}
@Override
public void notifySubscribers(Object notificationData, String subscriberId) {
Broadcaster broadcaster = BroadcasterFactory.getDefault().lookup(subscriberId, false);
if (broadcaster != null)
broadcaster.broadcast(JsonUtils.toJson(notificationData));
}
@Override
public void notifySubscribersGroup(Object notificationData, String groupId) {
MetaBroadcaster.getDefault().broadcastTo("/"+groupId+"/*", JsonUtils.toJson(notificationData));
}
@Path("/data")
@GET
@Produces("application/json")
public Data getMessage() {
return new Data();
}

@Override
@POST
@Path("/toggle")
public Response toggle(String data) {
notifySubscribers(data, "subscribe");
return Response.ok().build();
}
@Path("/broadcastdata")
@GET
@Produces("application/json")
public BroadcastContent getBroadcastMessage() {
BroadcastContent broadcastContent = new BroadcastContent();
broadcastContent.setMessage(new Data());
return broadcastContent;
}
}