package com.atmosphere.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.atmosphere.cache.UUIDBroadcasterCache;
import org.atmosphere.config.service.AtmosphereHandlerService;
import org.atmosphere.cpr.ApplicationConfig;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.AtmosphereResourceEvent;
import org.atmosphere.cpr.AtmosphereResourceEventListener;
import org.atmosphere.cpr.Broadcaster;
import org.atmosphere.cpr.BroadcasterFactory;
import org.atmosphere.cpr.BroadcasterLifeCyclePolicyListener;
import org.atmosphere.cpr.BroadcasterListener;
import org.atmosphere.cpr.HeaderConfig;
import org.atmosphere.handler.AbstractReflectorAtmosphereHandler;
import org.atmosphere.interceptor.AtmosphereResourceLifecycleInterceptor;

//@AtmosphereHandlerService(path = "/chathandler/*", interceptors = { AtmosphereResourceLifecycleInterceptor.class })
public class EserveAtmosphereServlet extends
		AbstractReflectorAtmosphereHandler {

	@Override
	public void onRequest(AtmosphereResource atmosphereResource)
			throws IOException {

		HttpServletRequest req = atmosphereResource.getRequest();
		HttpServletResponse res = atmosphereResource.getResponse();
		String method = req.getMethod();
		String subscriberId = req.getParameter("subscriberId");

		// Suspend the response.
		if ("GET".equalsIgnoreCase(method)) {
		
			// Log all events on the console, including WebSocket events.
			atmosphereResource
					.addEventListener(new AtmosphereResourceEventListener() {

						@Override
						public void onThrowable(AtmosphereResourceEvent event) {
						}

						@Override
						public void onSuspend(AtmosphereResourceEvent event) {
						}

						@Override
						public void onResume(AtmosphereResourceEvent event) {
						}

						@Override
						public void onDisconnect(AtmosphereResourceEvent event) {
						}

						@Override
						public void onBroadcast(AtmosphereResourceEvent event) {
						}
					});
			res.setContentType("text/html;charset=ISO-8859-1");
			Broadcaster b = lookupBroadcaster(subscriberId);
			if (b != null) {
				b.addBroadcasterListener(new BroadcasterListener() {

					@Override
					public void onPreDestroy(Broadcaster b) {
					}

					@Override
					public void onPostCreate(Broadcaster b) {
					}

					@Override
					public void onComplete(Broadcaster b) {
						// b.destroy();
					}
				});
				b.addBroadcasterLifeCyclePolicyListener(new BroadcasterLifeCyclePolicyListener() {

					@Override
					public void onIdle() {
					}

					@Override
					public void onEmpty() {
					}

					@Override
					public void onDestroy() {
					}
				});
				// atmosphereResource.setBroadcaster(b);
				b.addAtmosphereResource(atmosphereResource);
			}
			String atmoTransport = req
					.getHeader(HeaderConfig.X_ATMOSPHERE_TRANSPORT);

			if (atmoTransport != null
					&& !atmoTransport.isEmpty()
					&& atmoTransport
							.equalsIgnoreCase(HeaderConfig.LONG_POLLING_TRANSPORT)) {
				req.setAttribute(ApplicationConfig.RESUME_ON_BROADCAST,
						Boolean.TRUE);
				atmosphereResource.resumeOnBroadcast(true);
				atmosphereResource.getBroadcaster().getBroadcasterConfig()
						.setBroadcasterCache(new UUIDBroadcasterCache());
				atmosphereResource.suspend(-1, false);
			} else {
				atmosphereResource.suspend(-1);
			}
		} else if ("POST".equalsIgnoreCase(method)) {
			Broadcaster b = lookupBroadcaster(subscriberId);
			String message = req.getReader().readLine();
			if (message != null && message.indexOf("message") != -1) {
				b.broadcast(message.substring("message=".length()));
			}
		}
	}

	@Override
	public void destroy() {
		// empty
	}

	@Override
	public void onStateChange(AtmosphereResourceEvent event) throws IOException {
		super.onStateChange(event);
		@SuppressWarnings("unchecked")
		List<Object> cachedMessages = (List<Object>) event.getMessage();
		// System.out.println("Broadcaster cache is "+cachedMessages +
		// " and size is "+ cachedMessages.size());
	}

	Broadcaster lookupBroadcaster(String subscriberId) {
		Broadcaster b = null;
		b = BroadcasterFactory.getDefault().lookup(subscriberId, true);
		return b;
	}
}
