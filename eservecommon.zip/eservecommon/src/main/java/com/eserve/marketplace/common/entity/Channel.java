package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the channel database table.
 * 
 */
@Entity
@Table(name="channel")
public class Channel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private byte id;

	@Column(name="channel_name")
	private String channelName;

	//bi-directional many-to-one association to ProjectHasChannel
	/*@OneToMany(mappedBy="channel")
	private List<ProjectHasChannel> projectHasChannels;*/

	public Channel() {
	}

	public byte getId() {
		return this.id;
	}

	public void setId(byte id) {
		this.id = id;
	}

	public String getChannelName() {
		return this.channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	/*public List<ProjectHasChannel> getProjectHasChannels() {
		return this.projectHasChannels;
	}

	public void setProjectHasChannels(List<ProjectHasChannel> projectHasChannels) {
		this.projectHasChannels = projectHasChannels;
	}

	public ProjectHasChannel addProjectHasChannel(ProjectHasChannel projectHasChannel) {
		getProjectHasChannels().add(projectHasChannel);
		projectHasChannel.setChannel(this);

		return projectHasChannel;
	}

	public ProjectHasChannel removeProjectHasChannel(ProjectHasChannel projectHasChannel) {
		getProjectHasChannels().remove(projectHasChannel);
		projectHasChannel.setChannel(null);

		return projectHasChannel;
	}*/

}