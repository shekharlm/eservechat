package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the events_has_attachments database table.
 * 
 */
@Entity
@Table(name="events_has_attachments")
public class EventsHasAttachment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="attachement_name")
	private String attachementName;

	@Column(name="attachment_path")
	private String attachmentPath;

	//bi-directional many-to-one association to Event
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="events_id")
	private Event event;

	public EventsHasAttachment() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAttachementName() {
		return this.attachementName;
	}

	public void setAttachementName(String attachementName) {
		this.attachementName = attachementName;
	}

	public String getAttachmentPath() {
		return this.attachmentPath;
	}

	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	public Event getEvent() {
		return this.event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}

}