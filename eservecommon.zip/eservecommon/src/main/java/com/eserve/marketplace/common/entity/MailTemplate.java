package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the mail_template database table.
 * 
 */
@Entity
@Table(name="mail_template")
public class MailTemplate implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String htmlContent;

	private String jsonData;

	@Column(name="mail_from")
	private String mailFrom;

	@Column(name="mail_to")
	private String mailTo;

	@Temporal(TemporalType.TIMESTAMP)
	private Date mailsent;

	private String placeHolders;

	private String status;

	private String subject;

	public MailTemplate() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHtmlcontent() {
		return this.htmlContent;
	}

	public void setHtmlcontent(String htmlcontent) {
		this.htmlContent = htmlcontent;
	}

	public String getJsonData() {
		return this.jsonData;
	}

	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}

	public String getMailFrom() {
		return this.mailFrom;
	}

	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	public String getMailTo() {
		return this.mailTo;
	}

	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}

	public Date getMailsent() {
		return this.mailsent;
	}

	public void setMailsent(Date mailsent) {
		this.mailsent = mailsent;
	}

	public String getPlaceholders() {
		return this.placeHolders;
	}

	public void setPlaceholders(String placeholders) {
		this.placeHolders = placeholders;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

}