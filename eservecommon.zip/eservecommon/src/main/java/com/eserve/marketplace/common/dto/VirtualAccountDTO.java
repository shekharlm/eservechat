package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the virtual_accounts database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class VirtualAccountDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private Date accountActiveSince;

	private byte accountStatus;

	private byte importStatus;

	//bi-directional many-to-one association to ConsultantProfile
	private List<ConsultantProfileDTO> consultantProfiles;

	//bi-directional many-to-one association to EmployeeProfile
	private List<EmployeeProfileDTO> employeeProfiles;

	//bi-directional many-to-one association to Company
	private CompanyDTO company;

	//bi-directional many-to-one association to User
	private UserDTO user;

	//bi-directional many-to-one association to VirtualAccountsHasInvitation
	private List<VirtualAccountsHasInvitationDTO> virtualAccountsHasInvitations;

	public VirtualAccountDTO() {
	}

	public VirtualAccountDTO(int id, Date accountActiveSince, byte accountStatus,
			byte importStatus, List<ConsultantProfileDTO> consultantProfiles,
			List<EmployeeProfileDTO> employeeProfiles, CompanyDTO company, UserDTO user,
			List<VirtualAccountsHasInvitationDTO> virtualAccountsHasInvitations) {
		super();
		this.id = id;
		this.accountActiveSince = accountActiveSince;
		this.accountStatus = accountStatus;
		this.importStatus = importStatus;
		this.consultantProfiles = consultantProfiles;
		this.employeeProfiles = employeeProfiles;
		this.company = company;
		this.user = user;
		this.virtualAccountsHasInvitations = virtualAccountsHasInvitations;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getAccountActiveSince() {
		return this.accountActiveSince;
	}

	public void setAccountActiveSince(Date accountActiveSince) {
		this.accountActiveSince = accountActiveSince;
	}

	public byte getAccountStatus() {
		return this.accountStatus;
	}

	public void setAccountStatus(byte accountStatus) {
		this.accountStatus = accountStatus;
	}

	public byte getImportStatus() {
		return this.importStatus;
	}

	public void setImportStatus(byte importStatus) {
		this.importStatus = importStatus;
	}

	public List<ConsultantProfileDTO> getConsultantProfiles() {
		return this.consultantProfiles;
	}

	public void setConsultantProfiles(List<ConsultantProfileDTO> consultantProfiles) {
		this.consultantProfiles = consultantProfiles;
	}

	public ConsultantProfileDTO addConsultantProfile(ConsultantProfileDTO consultantProfile) {
		getConsultantProfiles().add(consultantProfile);
		consultantProfile.setVirtualAccount(this);

		return consultantProfile;
	}

	public ConsultantProfileDTO removeConsultantProfile(ConsultantProfileDTO consultantProfile) {
		getConsultantProfiles().remove(consultantProfile);
		consultantProfile.setVirtualAccount(null);

		return consultantProfile;
	}

	public List<EmployeeProfileDTO> getEmployeeProfiles() {
		return this.employeeProfiles;
	}

	public void setEmployeeProfiles(List<EmployeeProfileDTO> employeeProfiles) {
		this.employeeProfiles = employeeProfiles;
	}

	public EmployeeProfileDTO addEmployeeProfile(EmployeeProfileDTO employeeProfile) {
		getEmployeeProfiles().add(employeeProfile);
		employeeProfile.setVirtualAccount(this);

		return employeeProfile;
	}

	public EmployeeProfileDTO removeEmployeeProfile(EmployeeProfileDTO employeeProfile) {
		getEmployeeProfiles().remove(employeeProfile);
		employeeProfile.setVirtualAccount(null);

		return employeeProfile;
	}

	public CompanyDTO getCompany() {
		return this.company;
	}

	public void setCompany(CompanyDTO company) {
		this.company = company;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public List<VirtualAccountsHasInvitationDTO> getVirtualAccountsHasInvitations() {
		return this.virtualAccountsHasInvitations;
	}

	public void setVirtualAccountsHasInvitations(List<VirtualAccountsHasInvitationDTO> virtualAccountsHasInvitations) {
		this.virtualAccountsHasInvitations = virtualAccountsHasInvitations;
	}

	public VirtualAccountsHasInvitationDTO addVirtualAccountsHasInvitation(VirtualAccountsHasInvitationDTO virtualAccountsHasInvitation) {
		getVirtualAccountsHasInvitations().add(virtualAccountsHasInvitation);
		virtualAccountsHasInvitation.setVirtualAccount(this);

		return virtualAccountsHasInvitation;
	}

	public VirtualAccountsHasInvitationDTO removeVirtualAccountsHasInvitation(VirtualAccountsHasInvitationDTO virtualAccountsHasInvitation) {
		getVirtualAccountsHasInvitations().remove(virtualAccountsHasInvitation);
		virtualAccountsHasInvitation.setVirtualAccount(null);

		return virtualAccountsHasInvitation;
	}

}