
package com.eserve.marketplace.common.exception;

/**
 * @author priyatham
 *
 */
@SuppressWarnings("serial")
public class UserNotFoundException extends Exception {

}
