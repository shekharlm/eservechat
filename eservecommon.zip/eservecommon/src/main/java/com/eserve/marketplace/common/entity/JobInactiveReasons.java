package com.eserve.marketplace.common.entity;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;
/**
 * @author ag
 */
@Entity
@Table(name = "job_inactive_reasons")
public class JobInactiveReasons implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    /*@OneToOne
    @JoinColumn(name="job_id",referencedColumnName="id")
    private Job job;*/
    @Column(name="inactive_decription")
    private String inactiveDecription;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "inactive_on")
    private Date inactiveOn;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
   /* public Job getJob() {
        return job;
    }
    public void setJob(Job job) {
        this.job = job;
    }*/
    public String getInactiveDecription() {
        return inactiveDecription;
    }
    public void setInactiveDecription(String inactiveDecription) {
        this.inactiveDecription = inactiveDecription;
    }
    public Date getInactiveOn() {
        return inactiveOn;
    }
    public void setInactiveOn(Date inactiveOn) {
        this.inactiveOn = inactiveOn;
    }
    @Override
    public String toString() {
        return "com.eServe.marketPlace.infrastructure.repository.entities.JobInactiveReasons[ id=" + id + " ]";
    }
}
