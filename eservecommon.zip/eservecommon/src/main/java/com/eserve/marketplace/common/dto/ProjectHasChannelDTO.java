package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the project_has_channel database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ProjectHasChannelDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Channel
	private ChannelDTO channel;

	//bi-directional many-to-one association to Project
	private ProjectDTO project;

	public ProjectHasChannelDTO() {
	}

	public ProjectHasChannelDTO(int id, ChannelDTO channel, ProjectDTO project) {
		super();
		this.id = id;
		this.channel = channel;
		this.project = project;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ChannelDTO getChannel() {
		return this.channel;
	}

	public void setChannel(ChannelDTO channel) {
		this.channel = channel;
	}

	public ProjectDTO getProject() {
		return this.project;
	}

	public void setProject(ProjectDTO project) {
		this.project = project;
	}

}