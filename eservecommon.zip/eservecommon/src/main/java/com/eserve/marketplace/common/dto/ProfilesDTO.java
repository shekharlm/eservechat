package com.eserve.marketplace.common.dto;

public interface ProfilesDTO {

}
