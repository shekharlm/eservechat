package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the case database table.
 * 
 */
@Entity
@Table(name="cases")
public class Case implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="module_has_tasks_id")
	private int moduleHasTasksId;

	private String subject;

	//bi-directional many-to-one association to CasePriority
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="case_priority_id", referencedColumnName = "id")
	private CasePriority casePriority;

	//bi-directional many-to-one association to CaseStatus
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="case_status_id", referencedColumnName = "id")
	private CaseStatus caseStatus;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="assingned_to", referencedColumnName = "id")
	private User user;

	//bi-directional many-to-one association to CaseAttachment
	/*@OneToMany(mappedBy="case1")
	private List<CaseAttachment> caseAttachments;*/

	public Case() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getModuleHasTasksId() {
		return this.moduleHasTasksId;
	}

	public void setModuleHasTasksId(int moduleHasTasksId) {
		this.moduleHasTasksId = moduleHasTasksId;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public CasePriority getCasePriority() {
		return this.casePriority;
	}

	public void setCasePriority(CasePriority casePriority) {
		this.casePriority = casePriority;
	}

	public CaseStatus getCaseStatus() {
		return this.caseStatus;
	}

	public void setCaseStatus(CaseStatus caseStatus) {
		this.caseStatus = caseStatus;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/*public List<CaseAttachment> getCaseAttachments() {
		return this.caseAttachments;
	}

	public void setCaseAttachments(List<CaseAttachment> caseAttachments) {
		this.caseAttachments = caseAttachments;
	}

	public CaseAttachment addCaseAttachment(CaseAttachment caseAttachment) {
		getCaseAttachments().add(caseAttachment);
		caseAttachment.setCase(this);

		return caseAttachment;
	}

	public CaseAttachment removeCaseAttachment(CaseAttachment caseAttachment) {
		getCaseAttachments().remove(caseAttachment);
		caseAttachment.setCase(null);

		return caseAttachment;
	}*/

}