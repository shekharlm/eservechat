package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the event_repeats_on database table.
 * 
 */
@Entity
@Table(name="event_repeats_on")
public class EventRepeatsOn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="repeat_on")
	private String repeatOn;

	//bi-directional many-to-one association to Event
	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="events_id", referencedColumnName = "id")
	private Event event;*/

	public EventRepeatsOn() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRepeatOn() {
		return this.repeatOn;
	}

	public void setRepeatOn(String repeatOn) {
		this.repeatOn = repeatOn;
	}

	/*public Event getEvent() {
		return this.event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}*/

}