package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the user_contacts database table.
 * 
 */
@Entity
@Table(name="user_contacts")
public class UserContact implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="contact_number")
	private String contactNumber;

	@Column(name="contact_type")
	private String contactType;

	@Column(name="user_companies_id")
	private int userCompaniesId;
	
	@Column(name = "status")
	private Boolean status;

	//bi-directional many-to-one association to User
	/*@ManyToOne(cascade = CascadeType.ALL)
	private User user;*/

	public UserContact() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContactNumber() {
		return this.contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getContactType() {
		return this.contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	public int getUserCompaniesId() {
		return this.userCompaniesId;
	}

	public void setUserCompaniesId(int userCompaniesId) {
		this.userCompaniesId = userCompaniesId;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	/*public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}*/

}