package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the skill_type database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class SkillTypeDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String skillType;

	//bi-directional many-to-one association to Skill
	private List<SkillDTO> skills;

	public SkillTypeDTO() {
	}

	public SkillTypeDTO(int id, String skillType, List<SkillDTO> skills) {
		super();
		this.id = id;
		this.skillType = skillType;
		this.skills = skills;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSkillType() {
		return this.skillType;
	}

	public void setSkillType(String skillType) {
		this.skillType = skillType;
	}

	public List<SkillDTO> getSkills() {
		return this.skills;
	}

	public void setSkills(List<SkillDTO> skills) {
		this.skills = skills;
	}

	public SkillDTO addSkill(SkillDTO skill) {
		getSkills().add(skill);
		skill.setSkillType(this);

		return skill;
	}

	public SkillDTO removeSkill(SkillDTO skill) {
		getSkills().remove(skill);
		skill.setSkillType(null);

		return skill;
	}

}