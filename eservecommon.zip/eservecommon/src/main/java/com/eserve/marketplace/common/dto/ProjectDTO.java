package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the project database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ProjectDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private Date endDate;

	private String projectName;

	private Date startDate;

	//bi-directional many-to-one association to Job
	private List<JobDTO> jobs;

	//bi-directional many-to-one association to Company
	private CompanyDTO company;

	//bi-directional many-to-one association to UserHasProfile
	private UserHasProfileDTO userHasProfile;

	//bi-directional many-to-one association to ProjectAuditLog
	private List<ProjectAuditLogDTO> projectAuditLogs;

	//bi-directional many-to-one association to ProjectHasCalendar
	private List<ProjectHasCalendarDTO> projectHasCalendars;

	//bi-directional many-to-one association to ProjectHasChannel
	private List<ProjectHasChannelDTO> projectHasChannels;

	//bi-directional many-to-one association to ProjectUserHasRole
	private List<ProjectUserHasRoleDTO> projectUserHasRoles;

	public ProjectDTO() {
	}

	public ProjectDTO(int id, Date endDate, String projectName, Date startDate,
			List<JobDTO> jobs, CompanyDTO company, UserHasProfileDTO userHasProfile,
			List<ProjectAuditLogDTO> projectAuditLogs,
			List<ProjectHasCalendarDTO> projectHasCalendars,
			List<ProjectHasChannelDTO> projectHasChannels,
			List<ProjectUserHasRoleDTO> projectUserHasRoles) {
		super();
		this.id = id;
		this.endDate = endDate;
		this.projectName = projectName;
		this.startDate = startDate;
		this.jobs = jobs;
		this.company = company;
		this.userHasProfile = userHasProfile;
		this.projectAuditLogs = projectAuditLogs;
		this.projectHasCalendars = projectHasCalendars;
		this.projectHasChannels = projectHasChannels;
		this.projectUserHasRoles = projectUserHasRoles;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public List<JobDTO> getJobs() {
		return this.jobs;
	}

	public void setJobs(List<JobDTO> jobs) {
		this.jobs = jobs;
	}

	public JobDTO addJob(JobDTO job) {
		getJobs().add(job);
		job.setProject(this);

		return job;
	}

	public JobDTO removeJob(JobDTO job) {
		getJobs().remove(job);
		job.setProject(null);

		return job;
	}

	public CompanyDTO getCompany() {
		return this.company;
	}

	public void setCompany(CompanyDTO company) {
		this.company = company;
	}

	public UserHasProfileDTO getUserHasProfile() {
		return this.userHasProfile;
	}

	public void setUserHasProfile(UserHasProfileDTO userHasProfile) {
		this.userHasProfile = userHasProfile;
	}

	public List<ProjectAuditLogDTO> getProjectAuditLogs() {
		return this.projectAuditLogs;
	}

	public void setProjectAuditLogs(List<ProjectAuditLogDTO> projectAuditLogs) {
		this.projectAuditLogs = projectAuditLogs;
	}

	public ProjectAuditLogDTO addProjectAuditLog(ProjectAuditLogDTO projectAuditLog) {
		getProjectAuditLogs().add(projectAuditLog);
		projectAuditLog.setProject(this);

		return projectAuditLog;
	}

	public ProjectAuditLogDTO removeProjectAuditLog(ProjectAuditLogDTO projectAuditLog) {
		getProjectAuditLogs().remove(projectAuditLog);
		projectAuditLog.setProject(null);

		return projectAuditLog;
	}

	public List<ProjectHasCalendarDTO> getProjectHasCalendars() {
		return this.projectHasCalendars;
	}

	public void setProjectHasCalendars(List<ProjectHasCalendarDTO> projectHasCalendars) {
		this.projectHasCalendars = projectHasCalendars;
	}

	public ProjectHasCalendarDTO addProjectHasCalendar(ProjectHasCalendarDTO projectHasCalendar) {
		getProjectHasCalendars().add(projectHasCalendar);
		projectHasCalendar.setProject(this);

		return projectHasCalendar;
	}

	public ProjectHasCalendarDTO removeProjectHasCalendar(ProjectHasCalendarDTO projectHasCalendar) {
		getProjectHasCalendars().remove(projectHasCalendar);
		projectHasCalendar.setProject(null);

		return projectHasCalendar;
	}

	public List<ProjectHasChannelDTO> getProjectHasChannels() {
		return this.projectHasChannels;
	}

	public void setProjectHasChannels(List<ProjectHasChannelDTO> projectHasChannels) {
		this.projectHasChannels = projectHasChannels;
	}

	public ProjectHasChannelDTO addProjectHasChannel(ProjectHasChannelDTO projectHasChannel) {
		getProjectHasChannels().add(projectHasChannel);
		projectHasChannel.setProject(this);

		return projectHasChannel;
	}

	public ProjectHasChannelDTO removeProjectHasChannel(ProjectHasChannelDTO projectHasChannel) {
		getProjectHasChannels().remove(projectHasChannel);
		projectHasChannel.setProject(null);

		return projectHasChannel;
	}

	public List<ProjectUserHasRoleDTO> getProjectUserHasRoles() {
		return this.projectUserHasRoles;
	}

	public void setProjectUserHasRoles(List<ProjectUserHasRoleDTO> projectUserHasRoles) {
		this.projectUserHasRoles = projectUserHasRoles;
	}

	public ProjectUserHasRoleDTO addProjectUserHasRole(ProjectUserHasRoleDTO projectUserHasRole) {
		getProjectUserHasRoles().add(projectUserHasRole);
		projectUserHasRole.setProject(this);

		return projectUserHasRole;
	}

	public ProjectUserHasRoleDTO removeProjectUserHasRole(ProjectUserHasRoleDTO projectUserHasRole) {
		getProjectUserHasRoles().remove(projectUserHasRole);
		projectUserHasRole.setProject(null);

		return projectUserHasRole;
	}

}