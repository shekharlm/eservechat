package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the calendar_has_properties database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CalendarHasPropertyDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Calendar
	private CalendarDTO calendar;

	//bi-directional many-to-one association to Property
	private PropertyDTO property;

	public CalendarHasPropertyDTO() {
	}

	public CalendarHasPropertyDTO(int id, CalendarDTO calendar, PropertyDTO property) {
		super();
		this.id = id;
		this.calendar = calendar;
		this.property = property;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public CalendarDTO getCalendar() {
		return this.calendar;
	}

	public void setCalendar(CalendarDTO calendar) {
		this.calendar = calendar;
	}

	public PropertyDTO getProperty() {
		return this.property;
	}

	public void setProperty(PropertyDTO property) {
		this.property = property;
	}

	@Override
	public String toString() {
		return "CalendarHasProperty [id=" + id + ", calendar=" + calendar
				+ ", property=" + property + "]";
	}

}