package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the timesheet database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class TimesheetDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private Date login;

	private Date logout;

	//bi-directional many-to-one association to User
	private UserDTO user;

	public TimesheetDTO() {
	}

	public TimesheetDTO(int id, Date login, Date logout, UserDTO user) {
		super();
		this.id = id;
		this.login = login;
		this.logout = logout;
		this.user = user;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getLogin() {
		return this.login;
	}

	public void setLogin(Date login) {
		this.login = login;
	}

	public Date getLogout() {
		return this.logout;
	}

	public void setLogout(Date logout) {
		this.logout = logout;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}