package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the user_skill_rating database table.
 * 
 */
@Entity
@Table(name="user_skill_rating")
public class UserSkillRating implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	//bi-directional many-to-one association to Rating
	@ManyToOne(cascade = CascadeType.ALL)
	private Rating rating;

	//bi-directional many-to-one association to UserHasSkill
	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="user_skills_id")
	private UserHasSkill userHasSkill;*/

	public UserSkillRating() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Rating getRating() {
		return this.rating;
	}

	public void setRating(Rating rating) {
		this.rating = rating;
	}

	/*public UserHasSkill getUserHasSkill() {
		return this.userHasSkill;
	}

	public void setUserHasSkill(UserHasSkill userHasSkill) {
		this.userHasSkill = userHasSkill;
	}*/

}