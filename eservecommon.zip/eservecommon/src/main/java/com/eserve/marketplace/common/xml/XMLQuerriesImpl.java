package com.eserve.marketplace.common.xml;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="queryBlock")
public class XMLQuerriesImpl {
	
	@XmlElementWrapper(name="querries")
	@XmlElement(name="query")
	private ArrayList<XMLQueryImpl> queryList;

	public ArrayList<XMLQueryImpl> getXmlQuerries() {
		return queryList;
	}
	
	public void setXmlQuerries(ArrayList<XMLQueryImpl> xmlQuerries) {
		this.queryList = xmlQuerries;
	}
		
}
