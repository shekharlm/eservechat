/**
 * 
 */
package com.eserve.marketplace.common.dto;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author priyatham
 *
 */
public class MailTemplateJson {

	private Map<String, String> directFields = new LinkedHashMap<String, String>();
	private List<Map<String,String>> tables = new ArrayList<Map<String,String>>();
	
	public Map<String, String> getDirectFields() {
		return directFields;
	}
	public void setDirectFields(Map<String, String> directFields) {
		this.directFields = directFields;
	}
	public List<Map<String, String>> getTables() {
		return tables;
	}
	public void setTables(List<Map<String, String>> tables) {
		this.tables = tables;
	}
}

