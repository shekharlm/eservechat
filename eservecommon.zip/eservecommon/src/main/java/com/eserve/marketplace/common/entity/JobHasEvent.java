package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the job_has_events database table.
 * 
 */
@Entity
@Table(name="job_has_events")
public class JobHasEvent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="no_of_positions")
	private byte noOfPositions;

	@Column(name="positions_filled")
	private byte positionsFilled;

	//bi-directional many-to-one association to Event
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="events_id", referencedColumnName = "id")
	private Event event;

	//bi-directional many-to-one association to Job
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "job_id", referencedColumnName = "id")
	private Job job;

	public JobHasEvent() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public byte getNoOfPositions() {
		return this.noOfPositions;
	}

	public void setNoOfPositions(byte noOfPositions) {
		this.noOfPositions = noOfPositions;
	}

	public byte getPositionsFilled() {
		return this.positionsFilled;
	}

	public void setPositionsFilled(byte positionsFilled) {
		this.positionsFilled = positionsFilled;
	}

	/*public Event getEvent() {
		return this.event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}*/

	public Job getJob() {
		return this.job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

}