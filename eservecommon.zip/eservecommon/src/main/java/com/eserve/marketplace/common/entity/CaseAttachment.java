package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the case_attachment database table.
 * 
 */
@Entity
@Table(name="case_attachment")
public class CaseAttachment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="attachemnt_name")
	private String attachemntName;

	@Column(name="attachment_path")
	private String attachmentPath;

/*	@Column(name="case_id",insertable=false,updatable=false)
	private int caseID;
*/	
	
	//bi-directional many-to-one association to Case
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="case_id", referencedColumnName = "id")
	private Case case1;

	public CaseAttachment() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAttachemntName() {
		return this.attachemntName;
	}

	public void setAttachemntName(String attachemntName) {
		this.attachemntName = attachemntName;
	}

	public String getAttachmentPath() {
		return this.attachmentPath;
	}

	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	public Case getCase() {
		return this.case1;
	}

	public void setCase(Case case1) {
		this.case1 = case1;
	}

}