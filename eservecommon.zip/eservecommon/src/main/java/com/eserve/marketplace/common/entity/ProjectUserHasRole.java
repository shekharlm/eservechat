package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the project_user_has_role database table.
 * 
 */
@Entity
@Table(name="project_user_has_role")
public class ProjectUserHasRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	//bi-directional many-to-one association to ProjectUserHasEvent
	/*@OneToMany(mappedBy="projectUserHasRole")
	private List<ProjectUserHasEvent> projectUserHasEvents;*/

	//bi-directional many-to-one association to Project
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "project_id", referencedColumnName = "id")
	private Project project;

	//bi-directional many-to-one association to ProjectRole
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="project_role_id", referencedColumnName = "id")
	private ProjectRole projectRole;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;

	//bi-directional many-to-one association to UserTimeinTimeoff
	/*@OneToMany(mappedBy="projectUserHasRole")
	private List<UserTimeinTimeoff> userTimeinTimeoffs;*/

	public ProjectUserHasRole() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/*public List<ProjectUserHasEvent> getProjectUserHasEvents() {
		return this.projectUserHasEvents;
	}

	public void setProjectUserHasEvents(List<ProjectUserHasEvent> projectUserHasEvents) {
		this.projectUserHasEvents = projectUserHasEvents;
	}

	public ProjectUserHasEvent addProjectUserHasEvent(ProjectUserHasEvent projectUserHasEvent) {
		getProjectUserHasEvents().add(projectUserHasEvent);
		projectUserHasEvent.setProjectUserHasRole(this);

		return projectUserHasEvent;
	}

	public ProjectUserHasEvent removeProjectUserHasEvent(ProjectUserHasEvent projectUserHasEvent) {
		getProjectUserHasEvents().remove(projectUserHasEvent);
		projectUserHasEvent.setProjectUserHasRole(null);

		return projectUserHasEvent;
	}*/

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public ProjectRole getProjectRole() {
		return this.projectRole;
	}

	public void setProjectRole(ProjectRole projectRole) {
		this.projectRole = projectRole;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/*public List<UserTimeinTimeoff> getUserTimeinTimeoffs() {
		return this.userTimeinTimeoffs;
	}

	public void setUserTimeinTimeoffs(List<UserTimeinTimeoff> userTimeinTimeoffs) {
		this.userTimeinTimeoffs = userTimeinTimeoffs;
	}

	public UserTimeinTimeoff addUserTimeinTimeoff(UserTimeinTimeoff userTimeinTimeoff) {
		getUserTimeinTimeoffs().add(userTimeinTimeoff);
		userTimeinTimeoff.setProjectUserHasRole(this);

		return userTimeinTimeoff;
	}

	public UserTimeinTimeoff removeUserTimeinTimeoff(UserTimeinTimeoff userTimeinTimeoff) {
		getUserTimeinTimeoffs().remove(userTimeinTimeoff);
		userTimeinTimeoff.setProjectUserHasRole(null);

		return userTimeinTimeoff;
	}*/

}