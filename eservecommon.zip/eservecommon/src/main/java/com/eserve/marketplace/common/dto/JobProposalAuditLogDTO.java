package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the job_proposal_audit_log database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class JobProposalAuditLogDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to AuditLog
	private AuditLogDTO auditLog;

	//bi-directional many-to-one association to Job
	private JobDTO job;

	//bi-directional many-to-one association to Proposal
	private ProposalDTO proposal;

	public JobProposalAuditLogDTO() {
	}

	public JobProposalAuditLogDTO(int id, AuditLogDTO auditLog, JobDTO job,
			ProposalDTO proposal) {
		super();
		this.id = id;
		this.auditLog = auditLog;
		this.job = job;
		this.proposal = proposal;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public AuditLogDTO getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(AuditLogDTO auditLog) {
		this.auditLog = auditLog;
	}

	public JobDTO getJob() {
		return this.job;
	}

	public void setJob(JobDTO job) {
		this.job = job;
	}

	public ProposalDTO getProposal() {
		return this.proposal;
	}

	public void setProposal(ProposalDTO proposal) {
		this.proposal = proposal;
	}

}