package com.eserve.marketplace.common.xml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="query")
public class XMLQueryImpl {
	private String query_name;
	private String query_string;

	@XmlElement
	public String getQuery_name() {
		return query_name;
	}
	
	public void setQuery_name(String query_name) {
		this.query_name = query_name;
	}
	
	@XmlElement
	public String getQuery_string() {
		return query_string;
	}
	

	public void setQuery_string(String query_string) {
		this.query_string = query_string;
	}
	
}
