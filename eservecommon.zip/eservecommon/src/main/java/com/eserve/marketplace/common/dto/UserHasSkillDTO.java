package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_has_skills database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserHasSkillDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String additionalComments;

	private int relevantExp;
	
	private int skillId;
	
	private int userId;

	//bi-directional many-to-one association to Skill
	private SkillDTO skill;

	//bi-directional many-to-one association to User
	private UserDTO user;

	//bi-directional many-to-one association to UserSkillRating
	private List<UserSkillRatingDTO> userSkillRatings;

	public UserHasSkillDTO() {
	}

	public UserHasSkillDTO(int id, String additionalComments, int relevantExp,
			SkillDTO skill, UserDTO user, List<UserSkillRatingDTO> userSkillRatings) {
		super();
		this.id = id;
		this.additionalComments = additionalComments;
		this.relevantExp = relevantExp;
		this.skill = skill;
		this.user = user;
		this.userSkillRatings = userSkillRatings;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdditionalComments() {
		return this.additionalComments;
	}

	public void setAdditionalComments(String additionalComments) {
		this.additionalComments = additionalComments;
	}

	public int getRelevantExp() {
		return this.relevantExp;
	}

	public void setRelevantExp(int relevantExp) {
		this.relevantExp = relevantExp;
	}

	public SkillDTO getSkill() {
		return this.skill;
	}

	public void setSkill(SkillDTO skill) {
		this.skill = skill;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public List<UserSkillRatingDTO> getUserSkillRatings() {
		return this.userSkillRatings;
	}

	public void setUserSkillRatings(List<UserSkillRatingDTO> userSkillRatings) {
		this.userSkillRatings = userSkillRatings;
	}

	public UserSkillRatingDTO addUserSkillRating(UserSkillRatingDTO userSkillRating) {
		getUserSkillRatings().add(userSkillRating);
		userSkillRating.setUserHasSkill(this);

		return userSkillRating;
	}

	public UserSkillRatingDTO removeUserSkillRating(UserSkillRatingDTO userSkillRating) {
		getUserSkillRatings().remove(userSkillRating);
		userSkillRating.setUserHasSkill(null);

		return userSkillRating;
	}

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}