package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_has_profiles database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserHasProfileDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Project
	private List<ProjectDTO> projects;

	//bi-directional many-to-one association to ProfileType
	private ProfileTypeDTO profileType;

	//bi-directional many-to-one association to User
	private UserDTO user;

	public UserHasProfileDTO() {
	}

	public UserHasProfileDTO(int id, List<ProjectDTO> projects,
			ProfileTypeDTO profileType, UserDTO user) {
		super();
		this.id = id;
		this.projects = projects;
		this.profileType = profileType;
		this.user = user;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<ProjectDTO> getProjects() {
		return this.projects;
	}

	public void setProjects(List<ProjectDTO> projects) {
		this.projects = projects;
	}

	public ProjectDTO addProject(ProjectDTO project) {
		getProjects().add(project);
		project.setUserHasProfile(this);

		return project;
	}

	public ProjectDTO removeProject(ProjectDTO project) {
		getProjects().remove(project);
		project.setUserHasProfile(null);

		return project;
	}

	public ProfileTypeDTO getProfileType() {
		return this.profileType;
	}

	public void setProfileType(ProfileTypeDTO profileType) {
		this.profileType = profileType;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}