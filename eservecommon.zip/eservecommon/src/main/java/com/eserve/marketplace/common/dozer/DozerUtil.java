package com.eserve.marketplace.common.dozer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;

import org.dozer.CustomConverter;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;

import com.eserve.marketplace.common.dozer.converter.CompanyConverter;
import com.eserve.marketplace.common.dozer.converter.UserConverter;
import com.eserve.marketplace.common.dozer.converter.VirtualAccountConverter;
import com.eserve.marketplace.common.exception.ApplicationException;
import com.eserve.marketplace.common.persistenceservice.IPersistenceService;
import com.eserve.marketplace.common.util.ApplicationConstants;


@SuppressWarnings("unused")
public class DozerUtil {
	
	private final DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();
	
	@Inject @DozerPersistence
	IPersistenceService<Serializable> persistenceService;
	
	@Produces @DozerMapper
	public VirtualAccountConverter getCustomConverterTest(){
		return new VirtualAccountConverter(persistenceService);
	}
	
	@Produces @DozerMapper
	public UserConverter getUserConverter(){
		return new UserConverter(persistenceService);
	}
	
	@Produces @DozerMapper
	public CompanyConverter getCompanyConverter(){
		return new CompanyConverter(persistenceService);
	}

	/*@Produces @DozerMapper
	public DisplayNameConverter getDisplayNameConverter(){
		return new DisplayNameConverter(persistenceService);
	}*/
	
	@Inject @DozerMapper VirtualAccountConverter virtualAccountConverter;
	@Inject @DozerMapper UserConverter userConverter;
	@Inject @DozerMapper CompanyConverter companyConverter;
//	@Inject @DozerMapper DisplayNameConverter displayNameConverter;
	
	@Produces @DozerMapper
	public Mapper getDozerBeanMapper(){
//		DozerBeanMapper dozerBeanMapper = (DozerBeanMapper) DozerBeanMapperSingletonWrapper.getInstance();
		List<String> mappingList = new ArrayList<String>();
		mappingList.add("dozerBeanMapping.xml");
		mappingList.add("userHasInvitation.xml");
		mappingList.add("company.xml");
		mappingList.add("providerBusiness.xml");
		mappingList.add("user.xml");
		mappingList.add("clientBusiness.xml");
		mappingList.add("provider.xml");
		mappingList.add("skill.xml");
		mappingList.add("userHasSkill.xml");
		mappingList.add("employeeProfile.xml");
		mappingList.add("virtualAccount.xml");
		mappingList.add("consultantProfile.xml");
		dozerBeanMapper.setMappingFiles(mappingList);
		
		Map<String, CustomConverter> customConverters = new HashMap<String, CustomConverter>();
		customConverters.put("virtualaccount", virtualAccountConverter);
		customConverters.put("userconv", userConverter);
		customConverters.put("companyconv", companyConverter);
//		customConverters.put("displayconv", displayNameConverter);
		
		dozerBeanMapper.setCustomConvertersWithId(customConverters);
		return dozerBeanMapper;
	}
	
	@Inject @DozerMapper
	Mapper mapper;
	
	public <T> T convert(Object srcObject, Class<T> destnationObj) throws ApplicationException{
		return  convert(srcObject, destnationObj,null);
	}
	
	public <T> T convert(Object srcObject, Class<T> destnationObj,String mapId) throws ApplicationException{
		try{
			return (T) mapper.map(srcObject, destnationObj, mapId);
		}catch(Exception exception){
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_017);
		}
	}
	
	
}
