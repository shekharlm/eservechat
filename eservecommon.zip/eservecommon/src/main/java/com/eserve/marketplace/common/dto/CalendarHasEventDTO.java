package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the calendar_has_events database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CalendarHasEventDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String statusType;

	//bi-directional many-to-one association to Calendar
	private CalendarDTO calendar;

	//bi-directional many-to-one association to Event
	private EventDTO event;

	public CalendarHasEventDTO(int id, String statusType, CalendarDTO calendar,
			EventDTO event) {
		super();
		this.id = id;
		this.statusType = statusType;
		this.calendar = calendar;
		this.event = event;
	}

	public CalendarHasEventDTO() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStatusType() {
		return this.statusType;
	}

	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}

	public CalendarDTO getCalendar() {
		return this.calendar;
	}

	public void setCalendar(CalendarDTO calendar) {
		this.calendar = calendar;
	}

	public EventDTO getEvent() {
		return this.event;
	}

	public void setEvent(EventDTO event) {
		this.event = event;
	}

	@Override
	public String toString() {
		return "CalendarHasEvent [id=" + id + ", statusType=" + statusType
				+ ", calendar=" + calendar + ", event=" + event + "]";
	}

}