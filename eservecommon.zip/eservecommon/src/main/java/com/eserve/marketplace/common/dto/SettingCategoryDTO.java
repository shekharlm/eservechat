package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the setting_category database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class SettingCategoryDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String categoryName;

	//bi-directional many-to-one association to SettingGroup
	private List<SettingGroupDTO> settingGroups;

	public SettingCategoryDTO() {
	}

	public SettingCategoryDTO(int id, String categoryName,
			List<SettingGroupDTO> settingGroups) {
		super();
		this.id = id;
		this.categoryName = categoryName;
		this.settingGroups = settingGroups;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategoryName() {
		return this.categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<SettingGroupDTO> getSettingGroups() {
		return this.settingGroups;
	}

	public void setSettingGroups(List<SettingGroupDTO> settingGroups) {
		this.settingGroups = settingGroups;
	}

}