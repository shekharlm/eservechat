package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the address database table.
 * 
 */
@Entity
@Table(name="address")
public class Address implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="address_line1")
	private String addressLine1;

	@Column(name="address_line2")
	private String addressLine2;

	@Column(name="address_line3")
	private String addressLine3;

	@Column(name="is_active")
	private byte isActive;

	private String pin;

	//bi-directional many-to-one association to Country
	@ManyToOne
	@JoinColumn(name = "country_id", referencedColumnName = "id")
	private Country country;

	//bi-directional many-to-one association to State
	@ManyToOne
	@JoinColumn(name = "state_id", referencedColumnName = "id")
	private State state;

	//bi-directional many-to-one association to CompanyHasAddress
	/*@OneToMany(mappedBy="address")
	private List<CompanyHasAddress> companyHasAddresses;*/

	//bi-directional many-to-one association to UserHasAddress
	/*@OneToMany(mappedBy="address")
	private List<UserHasAddress> userHasAddresses;*/

	public Address() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddressLine1() {
		return this.addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return this.addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return this.addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public byte getIsActive() {
		return this.isActive;
	}

	public void setIsActive(byte isActive) {
		this.isActive = isActive;
	}

	public String getPin() {
		return this.pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public Country getCountry() {
		return this.country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public State getState() {
		return this.state;
	}

	public void setState(State state) {
		this.state = state;
	}

	/*public List<CompanyHasAddress> getCompanyHasAddresses() {
		return this.companyHasAddresses;
	}

	public void setCompanyHasAddresses(List<CompanyHasAddress> companyHasAddresses) {
		this.companyHasAddresses = companyHasAddresses;
	}

	public CompanyHasAddress addCompanyHasAddress(CompanyHasAddress companyHasAddress) {
		getCompanyHasAddresses().add(companyHasAddress);
		companyHasAddress.setAddress(this);

		return companyHasAddress;
	}

	public CompanyHasAddress removeCompanyHasAddress(CompanyHasAddress companyHasAddress) {
		getCompanyHasAddresses().remove(companyHasAddress);
		companyHasAddress.setAddress(null);

		return companyHasAddress;
	}

	public List<UserHasAddress> getUserHasAddresses() {
		return this.userHasAddresses;
	}

	public void setUserHasAddresses(List<UserHasAddress> userHasAddresses) {
		this.userHasAddresses = userHasAddresses;
	}

	public UserHasAddress addUserHasAddress(UserHasAddress userHasAddress) {
		getUserHasAddresses().add(userHasAddress);
		userHasAddress.setAddress(this);

		return userHasAddress;
	}

	public UserHasAddress removeUserHasAddress(UserHasAddress userHasAddress) {
		getUserHasAddresses().remove(userHasAddress);
		userHasAddress.setAddress(null);

		return userHasAddress;
	}*/

}