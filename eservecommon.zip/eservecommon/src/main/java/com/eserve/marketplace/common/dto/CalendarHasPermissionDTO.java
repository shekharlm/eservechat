package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the calendar_has_permissions database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CalendarHasPermissionDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String permissions;

	//bi-directional many-to-one association to Calendar
	private CalendarDTO calendar;

	//bi-directional many-to-one association to Group
	private GroupDTO group;

	//bi-directional many-to-one association to User
	private UserDTO user;

	public CalendarHasPermissionDTO() {
	}

	public CalendarHasPermissionDTO(int id, String permissions, CalendarDTO calendar,
			GroupDTO group, UserDTO user) {
		super();
		this.id = id;
		this.permissions = permissions;
		this.calendar = calendar;
		this.group = group;
		this.user = user;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPermissions() {
		return this.permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public CalendarDTO getCalendar() {
		return this.calendar;
	}

	public void setCalendar(CalendarDTO calendar) {
		this.calendar = calendar;
	}

	public GroupDTO getGroup() {
		return this.group;
	}

	public void setGroup(GroupDTO group) {
		this.group = group;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "CalendarHasPermission [id=" + id + ", permissions="
				+ permissions + ", calendar=" + calendar + ", group=" + group
				+ ", user=" + user + "]";
	}

}