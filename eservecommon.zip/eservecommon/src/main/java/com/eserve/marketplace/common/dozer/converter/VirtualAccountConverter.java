package com.eserve.marketplace.common.dozer.converter;

import java.io.Serializable;

import org.dozer.CustomConverter;

import com.eserve.marketplace.common.entity.VirtualAccount;
import com.eserve.marketplace.common.exception.ApplicationException;
import com.eserve.marketplace.common.persistenceservice.IPersistenceService;

public class VirtualAccountConverter implements CustomConverter {
	
	
	private IPersistenceService<Serializable> persistenceServiceImpl;
	
	public VirtualAccountConverter() {
	}
	
	public VirtualAccountConverter(IPersistenceService<Serializable> persistenceService) {
		this.persistenceServiceImpl = persistenceService;
	}
	

	public Object convert(Object destFieldValue,	Object sourceFieldValue, Class<?> destinationClass,	Class<?> sourceClass) {
		
		if(sourceFieldValue == null){
			return null;
		}
		
		if(destFieldValue == null){
			try {
				destFieldValue = persistenceServiceImpl.findEntityById(VirtualAccount.class, Integer.parseInt(sourceFieldValue.toString()));
			} catch (NumberFormatException e) {
				return null;
			} catch (ApplicationException e) {
				return null;
			}
		}
		
		return destFieldValue;
	}
}
