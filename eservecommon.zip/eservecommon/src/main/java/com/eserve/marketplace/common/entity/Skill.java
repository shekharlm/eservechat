package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the skill database table.
 * 
 */
@Entity
@Table(name="skill")
public class Skill implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String skill;

	//bi-directional many-to-one association to JobHasSkill
	/*@OneToMany(mappedBy="skill")
	private List<JobHasSkill> jobHasSkills;*/

	//bi-directional many-to-one association to SkillType
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="skill_type_id", referencedColumnName = "id")
	private SkillType skillType;

	//bi-directional many-to-one association to UserHasSkill
	/*@OneToMany(mappedBy="skill")
	private List<UserHasSkill> userHasSkills;*/

	public Skill() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSkill() {
		return this.skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	/*public List<JobHasSkill> getJobHasSkills() {
		return this.jobHasSkills;
	}

	public void setJobHasSkills(List<JobHasSkill> jobHasSkills) {
		this.jobHasSkills = jobHasSkills;
	}

	public JobHasSkill addJobHasSkill(JobHasSkill jobHasSkill) {
		getJobHasSkills().add(jobHasSkill);
		jobHasSkill.setSkill(this);

		return jobHasSkill;
	}

	public JobHasSkill removeJobHasSkill(JobHasSkill jobHasSkill) {
		getJobHasSkills().remove(jobHasSkill);
		jobHasSkill.setSkill(null);

		return jobHasSkill;
	}*/

	public SkillType getSkillType() {
		return this.skillType;
	}

	public void setSkillType(SkillType skillType) {
		this.skillType = skillType;
	}

	/*public List<UserHasSkill> getUserHasSkills() {
		return this.userHasSkills;
	}

	public void setUserHasSkills(List<UserHasSkill> userHasSkills) {
		this.userHasSkills = userHasSkills;
	}

	public UserHasSkill addUserHasSkill(UserHasSkill userHasSkill) {
		getUserHasSkills().add(userHasSkill);
		userHasSkill.setSkill(this);

		return userHasSkill;
	}

	public UserHasSkill removeUserHasSkill(UserHasSkill userHasSkill) {
		getUserHasSkills().remove(userHasSkill);
		userHasSkill.setSkill(null);

		return userHasSkill;
	}*/
@Override
public boolean equals(Object obj) {
	// TODO Auto-generated method stub
	Skill incoming=(Skill)obj;
	return (this.id==incoming.getId());
}
}