package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the company_has_address database table.
 * 
 */
@Entity
@Table(name="company_has_address")
public class CompanyHasAddress implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	//bi-directional many-to-one association to Address
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id", referencedColumnName = "id")
	private Address address;

	//bi-directional many-to-one association to AddressType
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="address_type_id", referencedColumnName = "id")
	private AddressType addressType;

	//bi-directional many-to-one association to Company
	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "company_id", referencedColumnName = "id")
	private Company company;*/

	public CompanyHasAddress() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public AddressType getAddressType() {
		return this.addressType;
	}

	public void setAddressType(AddressType addressType) {
		this.addressType = addressType;
	}

	/*public Company getCompany() {
		return this.company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}*/

}