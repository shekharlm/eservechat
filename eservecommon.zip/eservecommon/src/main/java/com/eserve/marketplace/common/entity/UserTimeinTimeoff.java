package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the user_timein_timeoff database table.
 * 
 */
@Entity
@Table(name="user_timein_timeoff")
public class UserTimeinTimeoff implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String description;

	private String status;

	private String type;

	//bi-directional many-to-one association to Event
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="events_id", referencedColumnName = "id")
	private Event event;

	//bi-directional many-to-one association to ProjectUserHasRole
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="project_user_id", referencedColumnName = "id")
	private ProjectUserHasRole projectUserHasRole;

	public UserTimeinTimeoff() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Event getEvent() {
		return this.event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}

	public ProjectUserHasRole getProjectUserHasRole() {
		return this.projectUserHasRole;
	}

	public void setProjectUserHasRole(ProjectUserHasRole projectUserHasRole) {
		this.projectUserHasRole = projectUserHasRole;
	}

}