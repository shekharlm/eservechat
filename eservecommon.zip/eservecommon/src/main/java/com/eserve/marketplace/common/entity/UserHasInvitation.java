package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the user_has_invitation database table.
 * 
 */
@Entity
@Table(name="user_has_invitation")
public class UserHasInvitation implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public static String TYPE_FRIEND="FRIEND";
	public static String TYPE_CONSULTANT="CONSULTANT";
	public static String TYPE_EMPLOYEE="EMPLOYEE";
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="email_sent_to")
	private String emailSentTo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="invitation_expiry_date")
	private Date invitationExpiryDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="invitation_sent_date")
	private Date invitationSentDate;

	@Column(name="invitation_status")
	private byte invitationStatus;

	@Column(name="invitation_type")
	private String invitationType;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="invitation_sent_by", referencedColumnName = "id")
	private User user;

	//bi-directional many-to-one association to VirtualAccountsHasInvitation
	/*@OneToMany(mappedBy="userHasInvitation", fetch = FetchType.EAGER)
	private List<VirtualAccountsHasInvitation> virtualAccountsHasInvitations;*/
	
	@Column(name="verification_token")
	private String verificationToken;

	//bi-directional many-to-one association to Company
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "company_id", referencedColumnName = "id")
	private Company company;	
	
	public UserHasInvitation() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmailSentTo() {
		return this.emailSentTo;
	}

	public void setEmailSentTo(String emailSentTo) {
		this.emailSentTo = emailSentTo;
	}

	public Date getInvitationExpiryDate() {
		return this.invitationExpiryDate;
	}

	public void setInvitationExpiryDate(Date invitationExpiryDate) {
		this.invitationExpiryDate = invitationExpiryDate;
	}

	public Date getInvitationSentDate() {
		return this.invitationSentDate;
	}

	public void setInvitationSentDate(Date invitationSentDate) {
		this.invitationSentDate = invitationSentDate;
	}

	public byte getInvitationStatus() {
		return this.invitationStatus;
	}

	public void setInvitationStatus(byte invitationStatus) {
		this.invitationStatus = invitationStatus;
	}

	public String getInvitationType() {
		return this.invitationType;
	}

	public void setInvitationType(String invitationType) {
		this.invitationType = invitationType;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/*public List<VirtualAccountsHasInvitation> getVirtualAccountsHasInvitations() {
		return this.virtualAccountsHasInvitations;
	}

	public void setVirtualAccountsHasInvitations(List<VirtualAccountsHasInvitation> virtualAccountsHasInvitations) {
		this.virtualAccountsHasInvitations = virtualAccountsHasInvitations;
	}

	public VirtualAccountsHasInvitation addVirtualAccountsHasInvitation(VirtualAccountsHasInvitation virtualAccountsHasInvitation) {
		getVirtualAccountsHasInvitations().add(virtualAccountsHasInvitation);
		virtualAccountsHasInvitation.setUserHasInvitation(this);

		return virtualAccountsHasInvitation;
	}

	public VirtualAccountsHasInvitation removeVirtualAccountsHasInvitation(VirtualAccountsHasInvitation virtualAccountsHasInvitation) {
		getVirtualAccountsHasInvitations().remove(virtualAccountsHasInvitation);
		virtualAccountsHasInvitation.setUserHasInvitation(null);

		return virtualAccountsHasInvitation;
	}*/

	public String getVerificationToken() {
		return verificationToken;
	}

	public void setVerificationToken(String verificationToken) {
		this.verificationToken = verificationToken;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

}