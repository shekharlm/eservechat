package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the rating database table.
 * 
 */
@Entity
@Table(name="rating")
public class Rating implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String rating;

	//bi-directional many-to-one association to UserSkillRating
	/*@OneToMany(mappedBy="rating")
	private List<UserSkillRating> userSkillRatings;*/

	public Rating() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRating() {
		return this.rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	/*public List<UserSkillRating> getUserSkillRatings() {
		return this.userSkillRatings;
	}

	public void setUserSkillRatings(List<UserSkillRating> userSkillRatings) {
		this.userSkillRatings = userSkillRatings;
	}

	public UserSkillRating addUserSkillRating(UserSkillRating userSkillRating) {
		getUserSkillRatings().add(userSkillRating);
		userSkillRating.setRating(this);

		return userSkillRating;
	}

	public UserSkillRating removeUserSkillRating(UserSkillRating userSkillRating) {
		getUserSkillRatings().remove(userSkillRating);
		userSkillRating.setRating(null);

		return userSkillRating;
	}*/

}