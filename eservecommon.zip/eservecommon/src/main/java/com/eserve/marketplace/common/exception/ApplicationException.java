package com.eserve.marketplace.common.exception;
@SuppressWarnings("serial")
public class ApplicationException extends Exception {
	public ApplicationException(){}
	public ApplicationException(String message){
		super(message);
	}
}
