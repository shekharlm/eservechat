package com.eserve.marketplace.common.persistenceservice;

import java.io.Serializable;

import javax.enterprise.inject.Alternative;

import com.eserve.marketplace.common.dozer.DozerPersistence;

@DozerPersistence
public class PersistenceServiceImpl extends AbsPersistenceService<Serializable> implements IPersistenceService<Serializable> {

}
