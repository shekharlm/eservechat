package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the company_has_address database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CompanyHasAddressDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Address
	private AddressDTO address;

	//bi-directional many-to-one association to AddressType
	private AddressTypeDTO addressType;

	//bi-directional many-to-one association to Company
	private CompanyDTO company;

	public CompanyHasAddressDTO() {
	}

	public int getId() {
		return this.id;
	}

	public CompanyHasAddressDTO(int id, AddressDTO address, AddressTypeDTO addressType,
			CompanyDTO company) {
		super();
		this.id = id;
		this.address = address;
		this.addressType = addressType;
		this.company = company;
	}

	public void setId(int id) {
		this.id = id;
	}

	public AddressDTO getAddress() {
		return this.address;
	}

	public void setAddress(AddressDTO address) {
		this.address = address;
	}

	public AddressTypeDTO getAddressType() {
		return this.addressType;
	}

	public void setAddressType(AddressTypeDTO addressType) {
		this.addressType = addressType;
	}

	public CompanyDTO getCompany() {
		return this.company;
	}

	public void setCompany(CompanyDTO company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "CompanyHasAddress [id=" + id + ", address=" + address
				+ ", addressType=" + addressType + ", company=" + company + "]";
	}

}