package com.eserve.marketplace.common.interceptor;

import java.io.Serializable;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import org.jboss.resteasy.client.ClientResponse;
import org.jboss.resteasy.client.ProxyFactory;

import com.security.rest.IAuthentication;

@SuppressWarnings("serial")
@Interceptor
@AuthenticationIntr
public class AuthenticationInterceptorImpl implements Serializable{

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@AroundInvoke
	public Object checkAuthentication(InvocationContext ic) throws Exception {
		IAuthentication proxy = ProxyFactory.create(IAuthentication.class, "http://localhost:8080/securitymanagement-web/");
		ClientResponse response = (ClientResponse)proxy.checkAuthentication();
		Boolean flag = (Boolean) response.getEntity(Boolean.class);
		if(flag){
			return ic.proceed();
		}
		return null;
	}
}
