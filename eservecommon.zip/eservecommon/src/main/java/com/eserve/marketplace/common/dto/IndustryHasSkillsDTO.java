package com.eserve.marketplace.common.dto;

import java.io.Serializable;


/**
 * The persistent class for the industry_type database table.
 * 
 */
public class IndustryHasSkillsDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private IndustryTypeDTO industryType;
	
	private SkillDTO skill;

	public IndustryHasSkillsDTO() {
	}

	public IndustryHasSkillsDTO(int id, IndustryTypeDTO industryType, SkillDTO skill) {
		super();
		this.id = id;
		this.industryType = industryType;
		this.skill = skill;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public IndustryTypeDTO getIndustryType() {
		return industryType;
	}

	public void setIndustryType(IndustryTypeDTO industryType) {
		this.industryType = industryType;
	}

	public SkillDTO getSkill() {
		return skill;
	}

	public void setSkill(SkillDTO skill) {
		this.skill = skill;
	}

}