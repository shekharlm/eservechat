package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the component database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ComponentDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String componentName;

	//bi-directional many-to-one association to AuditLog
	private List<AuditLogDTO> auditLogs;

	public ComponentDTO() {
	}

	public ComponentDTO(int id, String componentName, List<AuditLogDTO> auditLogs) {
		super();
		this.id = id;
		this.componentName = componentName;
		this.auditLogs = auditLogs;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getComponentName() {
		return this.componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public List<AuditLogDTO> getAuditLogs() {
		return this.auditLogs;
	}

	public void setAuditLogs(List<AuditLogDTO> auditLogs) {
		this.auditLogs = auditLogs;
	}

	public AuditLogDTO addAuditLog(AuditLogDTO auditLog) {
		getAuditLogs().add(auditLog);
		auditLog.setComponent(this);

		return auditLog;
	}

	public AuditLogDTO removeAuditLog(AuditLogDTO auditLog) {
		getAuditLogs().remove(auditLog);
		auditLog.setComponent(null);

		return auditLog;
	}

	@Override
	public String toString() {
		return "Component [id=" + id + ", componentName=" + componentName
				+ ", auditLogs=" + auditLogs + "]";
	}

}