package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity
@Table(name="user")
@org.hibernate.annotations.Entity(dynamicUpdate = false)
public class User implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public static final String STATUS_LOCKED="LOCKED";
	public static final String STATUS_ACTIVE="ACTIVE";
	public static final String STATUS_INACTIVE="INACTIVE";
	public static final String STATUS_REOPEN="REOPEN";
	public static final String STATUS_CLOSED="CLOSED";	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="account_status")
	private String accountStatus;

	@Column(name="activation_token")
	private String activationToken;

	@Column(name="alternate_email_id")
	private String alternateEmailId;

	@Column(name="display_name")
	private String displayName;

	@Column(name="email_id")
	private String emailId;

	@Column(name="first_name")
	private String firstName;

	@Column(name="last_name")
	private String lastName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="member_since")
	private Date memberSince;

	private String password;

	@Column(name="password_reset")
	private byte passwordReset;

	private String gender;
	
	@Temporal(TemporalType.DATE)
	@Column(name="date_of_birth")
	private Date dateOfBirth;
	
	@Column(name="reference_through")
	private String referenceThrough;
	

	//bi-directional many-to-one association to AuditLog
	/*@OneToMany(mappedBy="user")
	private List<AuditLog> auditLogs;*/

	//bi-directional many-to-one association to CalendarHasPermission
	/*@OneToMany(mappedBy="user")
	private List<CalendarHasPermission> calendarHasPermissions;*/

	//bi-directional many-to-one association to Case
	/*@OneToMany(mappedBy="user")
	private List<Case> cases;*/

	//bi-directional many-to-one association to ClientBuisnessProfile
	/*@OneToMany(mappedBy="user")
	private List<ClientBuisnessProfile> clientBuisnessProfiles;*/

	//bi-directional many-to-one association to GroupHasUser
	/*@OneToMany(mappedBy="user")
	private List<GroupHasUser> groupHasUsers;*/

	//bi-directional many-to-one association to Job
	/*@OneToMany(mappedBy="user")
	private List<Job> jobs;*/

	//bi-directional many-to-one association to ProjectUserHasRole
	/*@OneToMany(mappedBy="user")
	private List<ProjectUserHasRole> projectUserHasRoles;*/

	//bi-directional many-to-one association to Proposal
	/*@OneToMany(mappedBy="user")
	private List<Proposal> proposals;*/

	//bi-directional many-to-one association to ProposalConversation
	/*@OneToMany(mappedBy="user1")
	private List<ProposalConversation> proposalConversations1;*/

	//bi-directional many-to-one association to ProposalConversation
	/*@OneToMany(mappedBy="user2")
	private List<ProposalConversation> proposalConversations2;*/

	//bi-directional many-to-one association to ProviderBuisnessProfile
	/*@OneToMany(mappedBy="user")
	private List<ProviderBuisnessProfile> providerBusinessProfiles;*/

	//bi-directional many-to-one association to ProviderProfile
	/*@OneToMany(mappedBy="user")
	private List<ProviderProfile> providerProfiles;*/

	//bi-directional many-to-one association to Timesheet
	/*@OneToMany(mappedBy="user")
	private List<Timesheet> timesheets;*/

	//bi-directional many-to-one association to Timezone
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "timezone_id", referencedColumnName = "id")
	private Timezone timezone;

	//bi-directional many-to-one association to UserContact
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private List<UserContact> userContacts;

	//bi-directional many-to-one association to UserHasAddress
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private List<UserHasAddress> userHasAddresses;

	//bi-directional many-to-one association to UserHasAttachment
	/*@OneToMany(mappedBy="user")
	private List<UserHasAttachment> userHasAttachments;*/

	//bi-directional many-to-one association to UserHasCalendar
	/*@OneToMany(mappedBy="user")
	private List<UserHasCalendar> userHasCalendars;*/

	//bi-directional many-to-one association to UserHasExperience
	/*@OneToMany(mappedBy="user")
	private List<UserHasExperience> userHasExperiences;*/

	//bi-directional many-to-one association to UserHasInvitation
	/*@OneToMany(mappedBy="user")
	private List<UserHasInvitation> userHasInvitations;*/


	//bi-directional many-to-one association to UserHasProfile
	/*@OneToMany(mappedBy="user")
	private List<UserHasProfile> userHasProfiles;*/

	//bi-directional many-to-one association to UserHasSecurityQuestion
	/*@OneToMany(mappedBy="user")
	private List<UserHasSecurityQuestion> userHasSecurityQuestions;*/

	//bi-directional many-to-one association to UserHasSetting
	/*@OneToMany(mappedBy="user")
	private List<UserHasSetting> userHasSettings;*/

	//bi-directional many-to-one association to UserHasSkill
	/*@OneToMany(mappedBy="user")
	private List<UserHasSkill> userHasSkills;*/

	//bi-directional many-to-one association to VirtualAccount
	/*@OneToMany(mappedBy="user")
	private List<VirtualAccount> virtualAccounts;*/
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="activation_token_expires_on")
	private Date activationTokenExpiresOn;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Country country;
	
	@Column(name = "facebook_link")
	private String facebookLink;
	
	@Column(name = "twitter_link")
	private String twitterLink;
	
	@Column(name = "linkedin_link")
	private String linkedinLink;
	
	public User() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountStatus() {
		return this.accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getActivationToken() {
		return this.activationToken;
	}

	public void setActivationToken(String activationToken) {
		this.activationToken = activationToken;
	}

	public String getAlternateEmailId() {
		return this.alternateEmailId;
	}

	public void setAlternateEmailId(String alternateEmailId) {
		this.alternateEmailId = alternateEmailId;
	}

	public String getDisplayName() {
		return this.displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getMemberSince() {
		return this.memberSince;
	}

	public void setMemberSince(Date memberSince) {
		this.memberSince = memberSince;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public byte getPasswordReset() {
		return this.passwordReset;
	}

	public void setPasswordReset(byte passwordReset) {
		this.passwordReset = passwordReset;
	}

	/*public List<AuditLog> getAuditLogs() {
		return this.auditLogs;
	}

	public void setAuditLogs(List<AuditLog> auditLogs) {
		this.auditLogs = auditLogs;
	}

	public AuditLog addAuditLog(AuditLog auditLog) {
		getAuditLogs().add(auditLog);
		auditLog.setUser(this);

		return auditLog;
	}

	public AuditLog removeAuditLog(AuditLog auditLog) {
		getAuditLogs().remove(auditLog);
		auditLog.setUser(null);

		return auditLog;
	}*/

	/*public List<CalendarHasPermission> getCalendarHasPermissions() {
		return this.calendarHasPermissions;
	}

	public void setCalendarHasPermissions(List<CalendarHasPermission> calendarHasPermissions) {
		this.calendarHasPermissions = calendarHasPermissions;
	}

	public CalendarHasPermission addCalendarHasPermission(CalendarHasPermission calendarHasPermission) {
		getCalendarHasPermissions().add(calendarHasPermission);
		calendarHasPermission.setUser(this);

		return calendarHasPermission;
	}

	public CalendarHasPermission removeCalendarHasPermission(CalendarHasPermission calendarHasPermission) {
		getCalendarHasPermissions().remove(calendarHasPermission);
		calendarHasPermission.setUser(null);

		return calendarHasPermission;
	}*/

	/*public List<Case> getCases() {
		return this.cases;
	}

	public void setCases(List<Case> cases) {
		this.cases = cases;
	}

	public Case addCas(Case cas) {
		getCases().add(cas);
		cas.setUser(this);

		return cas;
	}

	public Case removeCas(Case cas) {
		getCases().remove(cas);
		cas.setUser(null);

		return cas;
	}*/

	/*public List<ClientBuisnessProfile> getClientBuisnessProfiles() {
		return this.clientBuisnessProfiles;
	}

	public void setClientBuisnessProfiles(List<ClientBuisnessProfile> clientBuisnessProfiles) {
		this.clientBuisnessProfiles = clientBuisnessProfiles;
	}

	public ClientBuisnessProfile addClientBuisnessProfile(ClientBuisnessProfile clientBuisnessProfile) {
		getClientBuisnessProfiles().add(clientBuisnessProfile);
		clientBuisnessProfile.setUser(this);

		return clientBuisnessProfile;
	}

	public ClientBuisnessProfile removeClientBuisnessProfile(ClientBuisnessProfile clientBuisnessProfile) {
		getClientBuisnessProfiles().remove(clientBuisnessProfile);
		clientBuisnessProfile.setUser(null);

		return clientBuisnessProfile;
	}*/

	/*public List<GroupHasUser> getGroupHasUsers() {
		return this.groupHasUsers;
	}

	public void setGroupHasUsers(List<GroupHasUser> groupHasUsers) {
		this.groupHasUsers = groupHasUsers;
	}

	public GroupHasUser addGroupHasUser(GroupHasUser groupHasUser) {
		getGroupHasUsers().add(groupHasUser);
		groupHasUser.setUser(this);

		return groupHasUser;
	}

	public GroupHasUser removeGroupHasUser(GroupHasUser groupHasUser) {
		getGroupHasUsers().remove(groupHasUser);
		groupHasUser.setUser(null);

		return groupHasUser;
	}*/

	/*public List<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public Job addJob(Job job) {
		getJobs().add(job);
		job.setUser(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setUser(null);

		return job;
	}*/

	/*public List<ProjectUserHasRole> getProjectUserHasRoles() {
		return this.projectUserHasRoles;
	}

	public void setProjectUserHasRoles(List<ProjectUserHasRole> projectUserHasRoles) {
		this.projectUserHasRoles = projectUserHasRoles;
	}

	public ProjectUserHasRole addProjectUserHasRole(ProjectUserHasRole projectUserHasRole) {
		getProjectUserHasRoles().add(projectUserHasRole);
		projectUserHasRole.setUser(this);

		return projectUserHasRole;
	}

	public ProjectUserHasRole removeProjectUserHasRole(ProjectUserHasRole projectUserHasRole) {
		getProjectUserHasRoles().remove(projectUserHasRole);
		projectUserHasRole.setUser(null);

		return projectUserHasRole;
	}*/

	/*public List<Proposal> getProposals() {
		return this.proposals;
	}

	public void setProposals(List<Proposal> proposals) {
		this.proposals = proposals;
	}

	public Proposal addProposal(Proposal proposal) {
		getProposals().add(proposal);
		proposal.setUser(this);

		return proposal;
	}

	public Proposal removeProposal(Proposal proposal) {
		getProposals().remove(proposal);
		proposal.setUser(null);

		return proposal;
	}*/

	/*public List<ProposalConversation> getProposalConversations1() {
		return this.proposalConversations1;
	}

	public void setProposalConversations1(List<ProposalConversation> proposalConversations1) {
		this.proposalConversations1 = proposalConversations1;
	}

	public ProposalConversation addProposalConversations1(ProposalConversation proposalConversations1) {
		getProposalConversations1().add(proposalConversations1);
		proposalConversations1.setUser1(this);

		return proposalConversations1;
	}

	public ProposalConversation removeProposalConversations1(ProposalConversation proposalConversations1) {
		getProposalConversations1().remove(proposalConversations1);
		proposalConversations1.setUser1(null);

		return proposalConversations1;
	}

	public List<ProposalConversation> getProposalConversations2() {
		return this.proposalConversations2;
	}

	public void setProposalConversations2(List<ProposalConversation> proposalConversations2) {
		this.proposalConversations2 = proposalConversations2;
	}

	public ProposalConversation addProposalConversations2(ProposalConversation proposalConversations2) {
		getProposalConversations2().add(proposalConversations2);
		proposalConversations2.setUser2(this);

		return proposalConversations2;
	}

	public ProposalConversation removeProposalConversations2(ProposalConversation proposalConversations2) {
		getProposalConversations2().remove(proposalConversations2);
		proposalConversations2.setUser2(null);

		return proposalConversations2;
	}*/

	/*public List<ProviderBuisnessProfile> getProviderBusinessProfiles() {
		return this.providerBusinessProfiles;
	}

	public void setProviderBusinessProfiles(List<ProviderBuisnessProfile> providerBusinessProfiles) {
		this.providerBusinessProfiles = providerBusinessProfiles;
	}

	public ProviderBuisnessProfile addProviderBuisnessProfile(ProviderBuisnessProfile providerBuisnessProfile) {
		getProviderBusinessProfiles().add(providerBuisnessProfile);
		providerBuisnessProfile.setUser(this);

		return providerBuisnessProfile;
	}

	public ProviderBuisnessProfile removeProviderBuisnessProfile(ProviderBuisnessProfile providerBuisnessProfile) {
		getProviderBusinessProfiles().remove(providerBuisnessProfile);
		providerBuisnessProfile.setUser(null);

		return providerBuisnessProfile;
	}*/

	/*public List<ProviderProfile> getProviderProfiles() {
		return this.providerProfiles;
	}

	public void setProviderProfiles(List<ProviderProfile> providerProfiles) {
		this.providerProfiles = providerProfiles;
	}

	public ProviderProfile addProviderProfile(ProviderProfile providerProfile) {
		getProviderProfiles().add(providerProfile);
		providerProfile.setUser(this);

		return providerProfile;
	}

	public ProviderProfile removeProviderProfile(ProviderProfile providerProfile) {
		getProviderProfiles().remove(providerProfile);
		providerProfile.setUser(null);

		return providerProfile;
	}*/

	/*public List<Timesheet> getTimesheets() {
		return this.timesheets;
	}

	public void setTimesheets(List<Timesheet> timesheets) {
		this.timesheets = timesheets;
	}

	public Timesheet addTimesheet(Timesheet timesheet) {
		getTimesheets().add(timesheet);
		timesheet.setUser(this);

		return timesheet;
	}

	public Timesheet removeTimesheet(Timesheet timesheet) {
		getTimesheets().remove(timesheet);
		timesheet.setUser(null);

		return timesheet;
	}*/

	public Timezone getTimezone() {
		return this.timezone;
	}

	public void setTimezone(Timezone timezone) {
		this.timezone = timezone;
	}

	public List<UserContact> getUserContacts() {
		return this.userContacts;
	}

	public void setUserContacts(List<UserContact> userContacts) {
		this.userContacts = userContacts;
	}

	/*public UserContact addUserContact(UserContact userContact) {
		getUserContacts().add(userContact);
		userContact.setUser(this);

		return userContact;
	}

	public UserContact removeUserContact(UserContact userContact) {
		getUserContacts().remove(userContact);
		userContact.setUser(null);

		return userContact;
	}*/

	public List<UserHasAddress> getUserHasAddresses() {
		return this.userHasAddresses;
	}

	public void setUserHasAddresses(List<UserHasAddress> userHasAddresses) {
		this.userHasAddresses = userHasAddresses;
	}

	/*public UserHasAddress addUserHasAddress(UserHasAddress userHasAddress) {
		getUserHasAddresses().add(userHasAddress);
		userHasAddress.setUser(this);

		return userHasAddress;
	}

	public UserHasAddress removeUserHasAddress(UserHasAddress userHasAddress) {
		getUserHasAddresses().remove(userHasAddress);
		userHasAddress.setUser(null);

		return userHasAddress;
	}*/

	/*public List<UserHasAttachment> getUserHasAttachments() {
		return this.userHasAttachments;
	}

	public void setUserHasAttachments(List<UserHasAttachment> userHasAttachments) {
		this.userHasAttachments = userHasAttachments;
	}

	public UserHasAttachment addUserHasAttachment(UserHasAttachment userHasAttachment) {
		getUserHasAttachments().add(userHasAttachment);
		userHasAttachment.setUser(this);

		return userHasAttachment;
	}

	public UserHasAttachment removeUserHasAttachment(UserHasAttachment userHasAttachment) {
		getUserHasAttachments().remove(userHasAttachment);
		userHasAttachment.setUser(null);

		return userHasAttachment;
	}*/

	/*public List<UserHasCalendar> getUserHasCalendars() {
		return this.userHasCalendars;
	}

	public void setUserHasCalendars(List<UserHasCalendar> userHasCalendars) {
		this.userHasCalendars = userHasCalendars;
	}

	public UserHasCalendar addUserHasCalendar(UserHasCalendar userHasCalendar) {
		getUserHasCalendars().add(userHasCalendar);
		userHasCalendar.setUser(this);

		return userHasCalendar;
	}

	public UserHasCalendar removeUserHasCalendar(UserHasCalendar userHasCalendar) {
		getUserHasCalendars().remove(userHasCalendar);
		userHasCalendar.setUser(null);

		return userHasCalendar;
	}*/

	/*public List<UserHasExperience> getUserHasExperiences() {
		return this.userHasExperiences;
	}

	public void setUserHasExperiences(List<UserHasExperience> userHasExperiences) {
		this.userHasExperiences = userHasExperiences;
	}

	public UserHasExperience addUserHasExperience(UserHasExperience userHasExperience) {
		getUserHasExperiences().add(userHasExperience);
		userHasExperience.setUser(this);

		return userHasExperience;
	}

	public UserHasExperience removeUserHasExperience(UserHasExperience userHasExperience) {
		getUserHasExperiences().remove(userHasExperience);
		userHasExperience.setUser(null);

		return userHasExperience;
	}*/

	/*public List<UserHasInvitation> getUserHasInvitations() {
		return this.userHasInvitations;
	}

	public void setUserHasInvitations(List<UserHasInvitation> userHasInvitations) {
		this.userHasInvitations = userHasInvitations;
	}

	public UserHasInvitation addUserHasInvitation(UserHasInvitation userHasInvitation) {
		getUserHasInvitations().add(userHasInvitation);
		userHasInvitation.setUser(this);

		return userHasInvitation;
	}

	public UserHasInvitation removeUserHasInvitation(UserHasInvitation userHasInvitation) {
		getUserHasInvitations().remove(userHasInvitation);
		userHasInvitation.setUser(null);

		return userHasInvitation;
	}*/

	/*public List<UserHasProfile> getUserHasProfiles() {
		return this.userHasProfiles;
	}

	public void setUserHasProfiles(List<UserHasProfile> userHasProfiles) {
		this.userHasProfiles = userHasProfiles;
	}

	public UserHasProfile addUserHasProfile(UserHasProfile userHasProfile) {
		getUserHasProfiles().add(userHasProfile);
		userHasProfile.setUser(this);

		return userHasProfile;
	}

	public UserHasProfile removeUserHasProfile(UserHasProfile userHasProfile) {
		getUserHasProfiles().remove(userHasProfile);
		userHasProfile.setUser(null);

		return userHasProfile;
	}*/

	/*public List<UserHasSecurityQuestion> getUserHasSecurityQuestions() {
		return this.userHasSecurityQuestions;
	}

	public void setUserHasSecurityQuestions(List<UserHasSecurityQuestion> userHasSecurityQuestions) {
		this.userHasSecurityQuestions = userHasSecurityQuestions;
	}

	public UserHasSecurityQuestion addUserHasSecurityQuestion(UserHasSecurityQuestion userHasSecurityQuestion) {
		getUserHasSecurityQuestions().add(userHasSecurityQuestion);
		userHasSecurityQuestion.setUser(this);

		return userHasSecurityQuestion;
	}

	public UserHasSecurityQuestion removeUserHasSecurityQuestion(UserHasSecurityQuestion userHasSecurityQuestion) {
		getUserHasSecurityQuestions().remove(userHasSecurityQuestion);
		userHasSecurityQuestion.setUser(null);

		return userHasSecurityQuestion;
	}*/

	/*public List<UserHasSetting> getUserHasSettings() {
		return this.userHasSettings;
	}

	public void setUserHasSettings(List<UserHasSetting> userHasSettings) {
		this.userHasSettings = userHasSettings;
	}

	public UserHasSetting addUserHasSetting(UserHasSetting userHasSetting) {
		getUserHasSettings().add(userHasSetting);
		userHasSetting.setUser(this);

		return userHasSetting;
	}

	public UserHasSetting removeUserHasSetting(UserHasSetting userHasSetting) {
		getUserHasSettings().remove(userHasSetting);
		userHasSetting.setUser(null);

		return userHasSetting;
	}*/

	/*public List<UserHasSkill> getUserHasSkills() {
		return this.userHasSkills;
	}

	public void setUserHasSkills(List<UserHasSkill> userHasSkills) {
		this.userHasSkills = userHasSkills;
	}

	public UserHasSkill addUserHasSkill(UserHasSkill userHasSkill) {
		getUserHasSkills().add(userHasSkill);
		userHasSkill.setUser(this);

		return userHasSkill;
	}

	public UserHasSkill removeUserHasSkill(UserHasSkill userHasSkill) {
		getUserHasSkills().remove(userHasSkill);
		userHasSkill.setUser(null);

		return userHasSkill;
	}*/

	/*public List<VirtualAccount> getVirtualAccounts() {
		return this.virtualAccounts;
	}

	public void setVirtualAccounts(List<VirtualAccount> virtualAccounts) {
		this.virtualAccounts = virtualAccounts;
	}

	public VirtualAccount addVirtualAccount(VirtualAccount virtualAccount) {
		getVirtualAccounts().add(virtualAccount);
		virtualAccount.setUser(this);

		return virtualAccount;
	}

	public VirtualAccount removeVirtualAccount(VirtualAccount virtualAccount) {
		getVirtualAccounts().remove(virtualAccount);
		virtualAccount.setUser(null);

		return virtualAccount;
	}*/

	public Date getActivationTokenExpiresOn() {
		return activationTokenExpiresOn;
	}

	public void setActivationTokenExpiresOn(Date activationTokenExpiresOn) {
		this.activationTokenExpiresOn = activationTokenExpiresOn;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getReferenceThrough() {
		return referenceThrough;
	}

	public void setReferenceThrough(String referenceThrough) {
		this.referenceThrough = referenceThrough;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getFacebookLink() {
		return facebookLink;
	}

	public void setFacebookLink(String facebookLink) {
		this.facebookLink = facebookLink;
	}

	public String getTwitterLink() {
		return twitterLink;
	}

	public void setTwitterLink(String twitterLink) {
		this.twitterLink = twitterLink;
	}

	public String getLinkedinLink() {
		return linkedinLink;
	}

	public void setLinkedinLink(String linkedinLink) {
		this.linkedinLink = linkedinLink;
	}

}