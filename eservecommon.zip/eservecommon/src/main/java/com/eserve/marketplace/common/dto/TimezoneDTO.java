package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the timezone database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class TimezoneDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String timezoneAbbr;

	private String timezoneName;

	//bi-directional many-to-one association to User
	private List<UserDTO> users;

	public TimezoneDTO() {
	}

	public TimezoneDTO(int id, String timezoneAbbr, String timezoneName,
			List<UserDTO> users) {
		super();
		this.id = id;
		this.timezoneAbbr = timezoneAbbr;
		this.timezoneName = timezoneName;
		this.users = users;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTimezoneAbbr() {
		return this.timezoneAbbr;
	}

	public void setTimezoneAbbr(String timezoneAbbr) {
		this.timezoneAbbr = timezoneAbbr;
	}

	public String getTimezoneName() {
		return this.timezoneName;
	}

	public void setTimezoneName(String timezoneName) {
		this.timezoneName = timezoneName;
	}

	public List<UserDTO> getUsers() {
		return this.users;
	}

	public void setUsers(List<UserDTO> users) {
		this.users = users;
	}

	/*public UserDTO addUser(UserDTO user) {
		getUsers().add(user);
		user.setTimezone(this);

		return user;
	}

	public UserDTO removeUser(UserDTO user) {
		getUsers().remove(user);
		user.setTimezone(null);

		return user;
	}*/

}