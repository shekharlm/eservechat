package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the project database table.
 * 
 */
@Entity
@Table(name="project")
public class Project implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Temporal(TemporalType.DATE)
	@Column(name="end_date")
	private Date endDate;

	@Column(name="project_name")
	private String projectName;

	@Temporal(TemporalType.DATE)
	@Column(name="start_date")
	private Date startDate;

	//bi-directional many-to-one association to Job
	/*@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "project_id")
	private List<Job> jobs;*/

	//bi-directional many-to-one association to Company
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "company_id", referencedColumnName = "id")
	private Company company;

	//bi-directional many-to-one association to UserHasProfile
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="account_id", referencedColumnName = "id")
	private UserHasProfile userHasProfile;

	//bi-directional many-to-one association to ProjectAuditLog
	/*@OneToMany(mappedBy="project")
	private List<ProjectAuditLog> projectAuditLogs;*/

	//bi-directional many-to-one association to ProjectHasCalendar
	/*@OneToMany(mappedBy="project")
	private List<ProjectHasCalendar> projectHasCalendars;*/

	//bi-directional many-to-one association to ProjectHasChannel
	/*@OneToMany(mappedBy="project")
	private List<ProjectHasChannel> projectHasChannels;*/

	//bi-directional many-to-one association to ProjectUserHasRole
	/*@OneToMany(mappedBy="project")
	private List<ProjectUserHasRole> projectUserHasRoles;*/

	public Project() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/*public List<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}*/

	/*public Job addJob(Job job) {
		getJobs().add(job);
		job.setProject(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setProject(null);

		return job;
	}*/

	public Company getCompany() {
		return this.company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public UserHasProfile getUserHasProfile() {
		return this.userHasProfile;
	}

	public void setUserHasProfile(UserHasProfile userHasProfile) {
		this.userHasProfile = userHasProfile;
	}

	/*public List<ProjectAuditLog> getProjectAuditLogs() {
		return this.projectAuditLogs;
	}

	public void setProjectAuditLogs(List<ProjectAuditLog> projectAuditLogs) {
		this.projectAuditLogs = projectAuditLogs;
	}

	public ProjectAuditLog addProjectAuditLog(ProjectAuditLog projectAuditLog) {
		getProjectAuditLogs().add(projectAuditLog);
		projectAuditLog.setProject(this);

		return projectAuditLog;
	}

	public ProjectAuditLog removeProjectAuditLog(ProjectAuditLog projectAuditLog) {
		getProjectAuditLogs().remove(projectAuditLog);
		projectAuditLog.setProject(null);

		return projectAuditLog;
	}*/

	/*public List<ProjectHasCalendar> getProjectHasCalendars() {
		return this.projectHasCalendars;
	}

	public void setProjectHasCalendars(List<ProjectHasCalendar> projectHasCalendars) {
		this.projectHasCalendars = projectHasCalendars;
	}

	public ProjectHasCalendar addProjectHasCalendar(ProjectHasCalendar projectHasCalendar) {
		getProjectHasCalendars().add(projectHasCalendar);
		projectHasCalendar.setProject(this);

		return projectHasCalendar;
	}

	public ProjectHasCalendar removeProjectHasCalendar(ProjectHasCalendar projectHasCalendar) {
		getProjectHasCalendars().remove(projectHasCalendar);
		projectHasCalendar.setProject(null);

		return projectHasCalendar;
	}*/

	/*public List<ProjectHasChannel> getProjectHasChannels() {
		return this.projectHasChannels;
	}

	public void setProjectHasChannels(List<ProjectHasChannel> projectHasChannels) {
		this.projectHasChannels = projectHasChannels;
	}

	public ProjectHasChannel addProjectHasChannel(ProjectHasChannel projectHasChannel) {
		getProjectHasChannels().add(projectHasChannel);
		projectHasChannel.setProject(this);

		return projectHasChannel;
	}

	public ProjectHasChannel removeProjectHasChannel(ProjectHasChannel projectHasChannel) {
		getProjectHasChannels().remove(projectHasChannel);
		projectHasChannel.setProject(null);

		return projectHasChannel;
	}*/

	/*public List<ProjectUserHasRole> getProjectUserHasRoles() {
		return this.projectUserHasRoles;
	}

	public void setProjectUserHasRoles(List<ProjectUserHasRole> projectUserHasRoles) {
		this.projectUserHasRoles = projectUserHasRoles;
	}

	public ProjectUserHasRole addProjectUserHasRole(ProjectUserHasRole projectUserHasRole) {
		getProjectUserHasRoles().add(projectUserHasRole);
		projectUserHasRole.setProject(this);

		return projectUserHasRole;
	}

	public ProjectUserHasRole removeProjectUserHasRole(ProjectUserHasRole projectUserHasRole) {
		getProjectUserHasRoles().remove(projectUserHasRole);
		projectUserHasRole.setProject(null);

		return projectUserHasRole;
	}*/

}