package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the calendar database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CalendarDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String calendarName;

	//bi-directional many-to-one association to CalendarHasEvent
	private List<CalendarHasEventDTO> calendarHasEvents;

	//bi-directional many-to-one association to CalendarHasPermission
	private List<CalendarHasPermissionDTO> calendarHasPermissions;

	//bi-directional many-to-one association to CalendarHasProperty
	private List<CalendarHasPropertyDTO> calendarHasProperties;

	//bi-directional many-to-one association to JobHasCalendar
	private List<JobHasCalendarDTO> jobHasCalendars;

	//bi-directional many-to-one association to ProjectHasCalendar
	private List<ProjectHasCalendarDTO> projectHasCalendars;

	//bi-directional many-to-one association to UserHasCalendar
	private List<UserHasCalendarDTO> userHasCalendars;

	public CalendarDTO() {
	}

	public CalendarDTO(int id, String calendarName,
			List<CalendarHasEventDTO> calendarHasEvents,
			List<CalendarHasPermissionDTO> calendarHasPermissions,
			List<CalendarHasPropertyDTO> calendarHasProperties,
			List<JobHasCalendarDTO> jobHasCalendars,
			List<ProjectHasCalendarDTO> projectHasCalendars,
			List<UserHasCalendarDTO> userHasCalendars) {
		super();
		this.id = id;
		this.calendarName = calendarName;
		this.calendarHasEvents = calendarHasEvents;
		this.calendarHasPermissions = calendarHasPermissions;
		this.calendarHasProperties = calendarHasProperties;
		this.jobHasCalendars = jobHasCalendars;
		this.projectHasCalendars = projectHasCalendars;
		this.userHasCalendars = userHasCalendars;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCalendarName() {
		return this.calendarName;
	}

	public void setCalendarName(String calendarName) {
		this.calendarName = calendarName;
	}

	public List<CalendarHasEventDTO> getCalendarHasEvents() {
		return this.calendarHasEvents;
	}

	public void setCalendarHasEvents(List<CalendarHasEventDTO> calendarHasEvents) {
		this.calendarHasEvents = calendarHasEvents;
	}

	public CalendarHasEventDTO addCalendarHasEvent(CalendarHasEventDTO calendarHasEvent) {
		getCalendarHasEvents().add(calendarHasEvent);
		calendarHasEvent.setCalendar(this);

		return calendarHasEvent;
	}

	public CalendarHasEventDTO removeCalendarHasEvent(CalendarHasEventDTO calendarHasEvent) {
		getCalendarHasEvents().remove(calendarHasEvent);
		calendarHasEvent.setCalendar(null);

		return calendarHasEvent;
	}

	public List<CalendarHasPermissionDTO> getCalendarHasPermissions() {
		return this.calendarHasPermissions;
	}

	public void setCalendarHasPermissions(List<CalendarHasPermissionDTO> calendarHasPermissions) {
		this.calendarHasPermissions = calendarHasPermissions;
	}

	public CalendarHasPermissionDTO addCalendarHasPermission(CalendarHasPermissionDTO calendarHasPermission) {
		getCalendarHasPermissions().add(calendarHasPermission);
		calendarHasPermission.setCalendar(this);

		return calendarHasPermission;
	}

	public CalendarHasPermissionDTO removeCalendarHasPermission(CalendarHasPermissionDTO calendarHasPermission) {
		getCalendarHasPermissions().remove(calendarHasPermission);
		calendarHasPermission.setCalendar(null);

		return calendarHasPermission;
	}

	public List<CalendarHasPropertyDTO> getCalendarHasProperties() {
		return this.calendarHasProperties;
	}

	public void setCalendarHasProperties(List<CalendarHasPropertyDTO> calendarHasProperties) {
		this.calendarHasProperties = calendarHasProperties;
	}

	public CalendarHasPropertyDTO addCalendarHasProperty(CalendarHasPropertyDTO calendarHasProperty) {
		getCalendarHasProperties().add(calendarHasProperty);
		calendarHasProperty.setCalendar(this);

		return calendarHasProperty;
	}

	public CalendarHasPropertyDTO removeCalendarHasProperty(CalendarHasPropertyDTO calendarHasProperty) {
		getCalendarHasProperties().remove(calendarHasProperty);
		calendarHasProperty.setCalendar(null);

		return calendarHasProperty;
	}

	public List<JobHasCalendarDTO> getJobHasCalendars() {
		return this.jobHasCalendars;
	}

	public void setJobHasCalendars(List<JobHasCalendarDTO> jobHasCalendars) {
		this.jobHasCalendars = jobHasCalendars;
	}

	public JobHasCalendarDTO addJobHasCalendar(JobHasCalendarDTO jobHasCalendar) {
		getJobHasCalendars().add(jobHasCalendar);
		jobHasCalendar.setCalendar(this);

		return jobHasCalendar;
	}

	public JobHasCalendarDTO removeJobHasCalendar(JobHasCalendarDTO jobHasCalendar) {
		getJobHasCalendars().remove(jobHasCalendar);
		jobHasCalendar.setCalendar(null);

		return jobHasCalendar;
	}

	public List<ProjectHasCalendarDTO> getProjectHasCalendars() {
		return this.projectHasCalendars;
	}

	public void setProjectHasCalendars(List<ProjectHasCalendarDTO> projectHasCalendars) {
		this.projectHasCalendars = projectHasCalendars;
	}

	public ProjectHasCalendarDTO addProjectHasCalendar(ProjectHasCalendarDTO projectHasCalendar) {
		getProjectHasCalendars().add(projectHasCalendar);
		projectHasCalendar.setCalendar(this);

		return projectHasCalendar;
	}

	public ProjectHasCalendarDTO removeProjectHasCalendar(ProjectHasCalendarDTO projectHasCalendar) {
		getProjectHasCalendars().remove(projectHasCalendar);
		projectHasCalendar.setCalendar(null);

		return projectHasCalendar;
	}

	public List<UserHasCalendarDTO> getUserHasCalendars() {
		return this.userHasCalendars;
	}

	public void setUserHasCalendars(List<UserHasCalendarDTO> userHasCalendars) {
		this.userHasCalendars = userHasCalendars;
	}

	public UserHasCalendarDTO addUserHasCalendar(UserHasCalendarDTO userHasCalendar) {
		getUserHasCalendars().add(userHasCalendar);
		userHasCalendar.setCalendar(this);

		return userHasCalendar;
	}

	public UserHasCalendarDTO removeUserHasCalendar(UserHasCalendarDTO userHasCalendar) {
		getUserHasCalendars().remove(userHasCalendar);
		userHasCalendar.setCalendar(null);

		return userHasCalendar;
	}

	@Override
	public String toString() {
		return "Calendar [id=" + id + ", calendarName=" + calendarName
				+ ", calendarHasEvents=" + calendarHasEvents
				+ ", calendarHasPermissions=" + calendarHasPermissions
				+ ", calendarHasProperties=" + calendarHasProperties
				+ ", jobHasCalendars=" + jobHasCalendars
				+ ", projectHasCalendars=" + projectHasCalendars
				+ ", userHasCalendars=" + userHasCalendars + "]";
	}

}