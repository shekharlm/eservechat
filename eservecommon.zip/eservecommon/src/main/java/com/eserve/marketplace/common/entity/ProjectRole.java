package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the project_role database table.
 * 
 */
@Entity
@Table(name="project_role")
public class ProjectRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String role;

	//bi-directional many-to-one association to ProjectUserHasRole
	/*@OneToMany(mappedBy="projectRole")
	private List<ProjectUserHasRole> projectUserHasRoles;*/

	public ProjectRole() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	/*public List<ProjectUserHasRole> getProjectUserHasRoles() {
		return this.projectUserHasRoles;
	}

	public void setProjectUserHasRoles(List<ProjectUserHasRole> projectUserHasRoles) {
		this.projectUserHasRoles = projectUserHasRoles;
	}

	public ProjectUserHasRole addProjectUserHasRole(ProjectUserHasRole projectUserHasRole) {
		getProjectUserHasRoles().add(projectUserHasRole);
		projectUserHasRole.setProjectRole(this);

		return projectUserHasRole;
	}

	public ProjectUserHasRole removeProjectUserHasRole(ProjectUserHasRole projectUserHasRole) {
		getProjectUserHasRoles().remove(projectUserHasRole);
		projectUserHasRole.setProjectRole(null);

		return projectUserHasRole;
	}*/

}