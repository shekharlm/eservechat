package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the user_has_security_question database table.
 * 
 */
@Entity
@Table(name="user_has_security_question")
public class UserHasSecurityQuestion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="security_answer")
	private String securityAnswer;

	//bi-directional many-to-one association to SecurityQuestion
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="security_question_id", referencedColumnName = "id")
	private SecurityQuestion securityQuestion;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;

	public UserHasSecurityQuestion() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSecurityAnswer() {
		return this.securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

	public SecurityQuestion getSecurityQuestion() {
		return this.securityQuestion;
	}

	public void setSecurityQuestion(SecurityQuestion securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}