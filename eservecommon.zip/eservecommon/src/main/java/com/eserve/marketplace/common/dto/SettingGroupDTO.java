package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the setting_group database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class SettingGroupDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String groupName;

//	//bi-directional many-to-one association to SettingCategory
//	private SettingCategory settingCategory;

	//bi-directional many-to-one association to Setting
	private List<SettingDTO> settings;

	public SettingGroupDTO() {
	}

	public SettingGroupDTO(int id, String groupName,
			SettingCategoryDTO settingCategory, List<SettingDTO> settings) {
		super();
		this.id = id;
		this.groupName = groupName;
//		this.settingCategory = settingCategory;
		this.settings = settings;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

//	public SettingCategory getSettingCategory() {
//		return this.settingCategory;
//	}

//	public void setSettingCategory(SettingCategory settingCategory) {
//		this.settingCategory = settingCategory;
//	}

	public List<SettingDTO> getSettings() {
		return this.settings;
	}

	public void setSettings(List<SettingDTO> settings) {
		this.settings = settings;
	}
}