package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the events_has_attachments database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class EventsHasAttachmentDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String attachementName;

	private String attachmentPath;

	//bi-directional many-to-one association to Event
	private EventDTO event;

	public EventsHasAttachmentDTO() {
	}

	public EventsHasAttachmentDTO(int id, String attachementName,
			String attachmentPath, EventDTO event) {
		super();
		this.id = id;
		this.attachementName = attachementName;
		this.attachmentPath = attachmentPath;
		this.event = event;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAttachementName() {
		return this.attachementName;
	}

	public void setAttachementName(String attachementName) {
		this.attachementName = attachementName;
	}

	public String getAttachmentPath() {
		return this.attachmentPath;
	}

	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	public EventDTO getEvent() {
		return this.event;
	}

	public void setEvent(EventDTO event) {
		this.event = event;
	}

}