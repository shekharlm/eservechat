package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the event_repeats_on database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class EventRepeatsOnDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String repeatOn;

	//bi-directional many-to-one association to Event
	private EventDTO event;

	public EventRepeatsOnDTO() {
	}

	public EventRepeatsOnDTO(int id, String repeatOn, EventDTO event) {
		super();
		this.id = id;
		this.repeatOn = repeatOn;
		this.event = event;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRepeatOn() {
		return this.repeatOn;
	}

	public void setRepeatOn(String repeatOn) {
		this.repeatOn = repeatOn;
	}

	public EventDTO getEvent() {
		return this.event;
	}

	public void setEvent(EventDTO event) {
		this.event = event;
	}

}