package com.eserve.marketplace.common.xml;

import java.io.InputStream;
import java.util.*;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import org.apache.log4j.Logger;

import com.eserve.marketplace.common.util.ApplicationConstants;
@Singleton
public class XMLQueryReaderImpl{
	/**
	 * Map to hold the XMLQuery Objects
	 */
	private static Map<String, XMLQueryImpl> queryMap;
	private static Logger log;
	private static boolean readSuccess=true;
	/**
	 * The default Constructor
	 * Reads the READ_QUERY.XML file that is saved in the /<{JBOSS.HOME}/modules/com/eServe/infrastructure/repository/main>
	 * The dependency for the above path is included in the manifest.mf file of the EAR project.
	 */
	@Inject
	public XMLQueryReaderImpl() {
		queryMap=new HashMap<String,XMLQueryImpl>();

		try{
			
			log=Logger.getLogger(this.getClass());
//			log.info("INJECTING XML READER");
//			log.info("=======================");
			log.info("READING XML QUERY FILE");
			log.info("==========================");
			InputStream xmlQueryStream=this.getClass().getClassLoader().getResourceAsStream(ApplicationConstants.XML_QUERY_RESOURCE);	
			readXMLQuerries(xmlQueryStream);			
		}catch(Exception e){
			e.printStackTrace();
			log.error("ERROR WHILE TRYING TO READ XML QUERY FILE: "+e);
		}			
	}
	
	/**
	 * Reads the content of an XML file in a Map object of {@link XMLQueryImpl}
	 * The Map contains the QueryName and QueryString
	 * @param xmlQueryStream The InputStream containing the contents of the Query XML.
	 * @throws JAXBException
	 */
	private void readXMLQuerries(InputStream xmlQueryStream) throws JAXBException{
		if(!validateQueryFile(""))return;		
		//Creating the JAXBContext which will be used to Unmarshall
		JAXBContext context=JAXBContext.newInstance(XMLQuerriesImpl.class);
		Unmarshaller um=context.createUnmarshaller();
		//Unmarshalling the contents of the XML file.		
		XMLQuerriesImpl querries=(XMLQuerriesImpl) um.unmarshal(xmlQueryStream);
		ArrayList<XMLQueryImpl> queryList=querries.getXmlQuerries();
		for(XMLQueryImpl q:queryList){
			queryMap.put(q.getQuery_name(), q);
		}		
	}
	
	/**
	 * Validates the incoming XML file against a schema.
	 * @param xsdLocation The location of the XSD schema
	 * @return boolean Whether the XML file is valid.
	 */
	private boolean validateQueryFile(String xsdLocation){
		//Code needs to be written
		return true;
	}
	

	/**
	 * Returns the XMLQuery object for the required Query Name.
	 * @param queryName The query which is required
	 * @return {@link XMLQueryImpl} representing the the query object.
	 */
	public XMLQueryImpl getXMLQuery(String queryName){
		if(!readSuccess)return null;		
		return queryMap.get(queryName);
	}	
}
