package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the profile_type database table.
 * 
 */
@Entity
@Table(name="profile_type")
public class ProfileType implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public static final int PROVIDER=1;
	public static final int PROVIDER_BUSINESS=2;
	public static final int CLIENT_BUSINESS=3;
	public static final int EMPLOYEE=4;
	public static final int CONSULTANT=5;			

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="profile_type")
	private String profileType;

	//bi-directional many-to-one association to UserHasProfile
	/*@OneToMany(mappedBy="profileType")
	private List<UserHasProfile> userHasProfiles;*/

	public ProfileType() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProfileType() {
		return this.profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

	/*public List<UserHasProfile> getUserHasProfiles() {
		return this.userHasProfiles;
	}

	public void setUserHasProfiles(List<UserHasProfile> userHasProfiles) {
		this.userHasProfiles = userHasProfiles;
	}

	public UserHasProfile addUserHasProfile(UserHasProfile userHasProfile) {
		getUserHasProfiles().add(userHasProfile);
		userHasProfile.setProfileType(this);

		return userHasProfile;
	}

	public UserHasProfile removeUserHasProfile(UserHasProfile userHasProfile) {
		getUserHasProfiles().remove(userHasProfile);
		userHasProfile.setProfileType(null);

		return userHasProfile;
	}*/

}