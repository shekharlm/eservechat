/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 *
 * @author ag
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class PrivateJobHasProvidersDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Integer id;

    private JobDTO job;
    
    private ProviderProfileDTO provider;

    public JobDTO getJob() {
        return job;
    }

    public void setJob(JobDTO job) {
        this.job = job;
    }

    public ProviderProfileDTO getProvider() {
        return provider;
    }

    public void setProvider(ProviderProfileDTO provider) {
        this.provider = provider;
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrivateJobHasProvidersDTO)) {
            return false;
        }
        PrivateJobHasProvidersDTO other = (PrivateJobHasProvidersDTO) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.eServe.marketPlace.infrastructure.repository.entities.PrivateJobHasProviders[ id=" + id + " ]";
    }
    
}
