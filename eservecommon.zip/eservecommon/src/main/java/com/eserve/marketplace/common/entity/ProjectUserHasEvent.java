package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the project_user_has_events database table.
 * 
 */
@Entity
@Table(name="project_user_has_events")
public class ProjectUserHasEvent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String status;

	//bi-directional many-to-one association to Event
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="events_id", referencedColumnName = "id")
	private Event event1;

	//bi-directional many-to-one association to Event
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="shift_id", referencedColumnName = "id")
	private Event event2;

	//bi-directional many-to-one association to ProjectUserHasRole
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="project_user_id", referencedColumnName = "id")
	private ProjectUserHasRole projectUserHasRole;

	public ProjectUserHasEvent() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Event getEvent1() {
		return this.event1;
	}

	public void setEvent1(Event event1) {
		this.event1 = event1;
	}

	public Event getEvent2() {
		return this.event2;
	}

	public void setEvent2(Event event2) {
		this.event2 = event2;
	}

	public ProjectUserHasRole getProjectUserHasRole() {
		return this.projectUserHasRole;
	}

	public void setProjectUserHasRole(ProjectUserHasRole projectUserHasRole) {
		this.projectUserHasRole = projectUserHasRole;
	}

}