package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the proposal_conversation database table.
 * 
 */
@Entity
@Table(name="proposal_conversation")
public class ProposalConversation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="conversation_from")
	private String conversationFrom;

	private String description;

	//bi-directional many-to-one association to Proposal
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "proposal_id", referencedColumnName = "id")
	private Proposal proposal;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="client_user_id", referencedColumnName = "id")
	private User user1;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="provider_user_id", referencedColumnName = "id")
	private User user2;

	//bi-directional many-to-one association to ProposalConversationHasAttachment
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "proposal_conversation_id")
	private List<ProposalConversationHasAttachment> proposalConversationHasAttachments;

	public ProposalConversation() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getConversationFrom() {
		return this.conversationFrom;
	}

	public void setConversationFrom(String conversationFrom) {
		this.conversationFrom = conversationFrom;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Proposal getProposal() {
		return this.proposal;
	}

	public void setProposal(Proposal proposal) {
		this.proposal = proposal;
	}

	public User getUser1() {
		return this.user1;
	}

	public void setUser1(User user1) {
		this.user1 = user1;
	}

	public User getUser2() {
		return this.user2;
	}

	public void setUser2(User user2) {
		this.user2 = user2;
	}

	public List<ProposalConversationHasAttachment> getProposalConversationHasAttachments() {
		return this.proposalConversationHasAttachments;
	}

	public void setProposalConversationHasAttachments(List<ProposalConversationHasAttachment> proposalConversationHasAttachments) {
		this.proposalConversationHasAttachments = proposalConversationHasAttachments;
	}

	/*public ProposalConversationHasAttachment addProposalConversationHasAttachment(ProposalConversationHasAttachment proposalConversationHasAttachment) {
		getProposalConversationHasAttachments().add(proposalConversationHasAttachment);
		proposalConversationHasAttachment.setProposalConversation(this);

		return proposalConversationHasAttachment;
	}

	public ProposalConversationHasAttachment removeProposalConversationHasAttachment(ProposalConversationHasAttachment proposalConversationHasAttachment) {
		getProposalConversationHasAttachments().remove(proposalConversationHasAttachment);
		proposalConversationHasAttachment.setProposalConversation(null);

		return proposalConversationHasAttachment;
	}*/

}