package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the project_has_calendar database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ProjectHasCalendarDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Calendar
	private CalendarDTO calendar;

	//bi-directional many-to-one association to Project
	private ProjectDTO project;

	public ProjectHasCalendarDTO() {
	}

	public ProjectHasCalendarDTO(int id, CalendarDTO calendar, ProjectDTO project) {
		super();
		this.id = id;
		this.calendar = calendar;
		this.project = project;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public CalendarDTO getCalendar() {
		return this.calendar;
	}

	public void setCalendar(CalendarDTO calendar) {
		this.calendar = calendar;
	}

	public ProjectDTO getProject() {
		return this.project;
	}

	public void setProject(ProjectDTO project) {
		this.project = project;
	}

}