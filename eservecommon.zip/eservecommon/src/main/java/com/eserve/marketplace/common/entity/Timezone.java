package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the timezone database table.
 * 
 */
@Entity
@Table(name="timezone")
public class Timezone implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="timezone_abbr")
	private String timezoneAbbr;

	@Column(name="timezone_name")
	private String timezoneName;

	//bi-directional many-to-one association to User
	/*@OneToMany(mappedBy="timezone")
	private List<User> users;*/

	public Timezone() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTimezoneAbbr() {
		return this.timezoneAbbr;
	}

	public void setTimezoneAbbr(String timezoneAbbr) {
		this.timezoneAbbr = timezoneAbbr;
	}

	public String getTimezoneName() {
		return this.timezoneName;
	}

	public void setTimezoneName(String timezoneName) {
		this.timezoneName = timezoneName;
	}

	/*public List<User> getUsers() {
		return this.users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public User addUser(User user) {
		getUsers().add(user);
		user.setTimezone(this);

		return user;
	}

	public User removeUser(User user) {
		getUsers().remove(user);
		user.setTimezone(null);

		return user;
	}*/

}