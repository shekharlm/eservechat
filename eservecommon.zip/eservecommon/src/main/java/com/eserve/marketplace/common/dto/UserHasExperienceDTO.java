package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_has_experience database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserHasExperienceDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private Date endDate;

	private Date startDate;

	private String title;

	private byte verified;

	//bi-directional many-to-one association to Company
	private CompanyDTO company;

	//bi-directional many-to-one association to User
	private UserDTO user;

	public UserHasExperienceDTO() {
	}

	public UserHasExperienceDTO(int id, Date endDate, Date startDate,
			String title, byte verified, CompanyDTO company, UserDTO user) {
		super();
		this.id = id;
		this.endDate = endDate;
		this.startDate = startDate;
		this.title = title;
		this.verified = verified;
		this.company = company;
		this.user = user;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public byte getVerified() {
		return this.verified;
	}

	public void setVerified(byte verified) {
		this.verified = verified;
	}

	public CompanyDTO getCompany() {
		return this.company;
	}

	public void setCompany(CompanyDTO company) {
		this.company = company;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}