package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the virtual_accounts_has_invitation database table.
 * 
 */
@Entity
@Table(name="virtual_accounts_has_invitation")
public class VirtualAccountsHasInvitation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	//bi-directional many-to-one association to UserHasInvitation
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="user_invitation_id", referencedColumnName = "id")
	private UserHasInvitation userHasInvitation;

	//bi-directional many-to-one association to VirtualAccount
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="virtual_accounts_id", referencedColumnName = "id")
	private VirtualAccount virtualAccount;

	public VirtualAccountsHasInvitation() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public UserHasInvitation getUserHasInvitation() {
		return this.userHasInvitation;
	}

	public void setUserHasInvitation(UserHasInvitation userHasInvitation) {
		this.userHasInvitation = userHasInvitation;
	}

	public VirtualAccount getVirtualAccount() {
		return this.virtualAccount;
	}

	public void setVirtualAccount(VirtualAccount virtualAccount) {
		this.virtualAccount = virtualAccount;
	}

}