package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
/**
 * The persistent class for the company database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CompanyDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String alternateEmailId;

	private String companyName;

	private String description;

	private String emailId;
	
	private String companyVerified;

	//bi-directional many-to-one association to ClientBuisnessProfile
	private List<ClientBuisnessProfileDTO> clientBuisnessProfiles;

	//bi-directional many-to-one association to IndustryType
	private IndustryTypeDTO industryType;

	//bi-directional many-to-one association to CompanyHasAddress
	private List<CompanyHasAddressDTO> companyHasAddresses;

	//bi-directional many-to-one association to Project
	private List<ProjectDTO> projects;

	//bi-directional many-to-one association to ProviderBuisnessProfile
	private List<ProviderBusinessProfileDTO> providerBusinessProfiles;

	//bi-directional many-to-one association to UserHasExperience
	private List<UserHasExperienceDTO> userHasExperiences;

	//bi-directional many-to-one association to VirtualAccount
	private List<VirtualAccountDTO> virtualAccounts;
	
	//bi-directional many-to-one association to VirtualAccount
	private List<UserHasInvitationDTO> invitations;
	

	public CompanyDTO() {
	}

	public CompanyDTO(int id, String alternateEmailId, String companyName,
			String description, String emailId, String companyVerified,
			List<ClientBuisnessProfileDTO> clientBuisnessProfiles,
			IndustryTypeDTO industryType,
			List<CompanyHasAddressDTO> companyHasAddresses,
			List<ProjectDTO> projects,
			List<ProviderBusinessProfileDTO> providerBusinessProfiles,
			List<UserHasExperienceDTO> userHasExperiences,
			List<VirtualAccountDTO> virtualAccounts) {
		super();
		this.id = id;
		this.alternateEmailId = alternateEmailId;
		this.companyName = companyName;
		this.description = description;
		this.emailId = emailId;
		this.companyVerified = companyVerified;
		this.clientBuisnessProfiles = clientBuisnessProfiles;
		this.industryType = industryType;
		this.companyHasAddresses = companyHasAddresses;
		this.projects = projects;
		this.providerBusinessProfiles = providerBusinessProfiles;
		this.userHasExperiences = userHasExperiences;
		this.virtualAccounts = virtualAccounts;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAlternateEmailId() {
		return this.alternateEmailId;
	}

	public void setAlternateEmailId(String alternateEmailId) {
		this.alternateEmailId = alternateEmailId;
	}

	public String getCompanyName() {
		return this.companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public List<ClientBuisnessProfileDTO> getClientBuisnessProfiles() {
		return this.clientBuisnessProfiles;
	}

	public void setClientBuisnessProfiles(List<ClientBuisnessProfileDTO> clientBuisnessProfiles) {
		this.clientBuisnessProfiles = clientBuisnessProfiles;
	}

	public ClientBuisnessProfileDTO addClientBuisnessProfile(ClientBuisnessProfileDTO clientBuisnessProfile) {
		getClientBuisnessProfiles().add(clientBuisnessProfile);
		clientBuisnessProfile.setCompany(this);

		return clientBuisnessProfile;
	}

	public ClientBuisnessProfileDTO removeClientBuisnessProfile(ClientBuisnessProfileDTO clientBuisnessProfile) {
		getClientBuisnessProfiles().remove(clientBuisnessProfile);
		clientBuisnessProfile.setCompany(null);

		return clientBuisnessProfile;
	}

	public IndustryTypeDTO getIndustryType() {
		return this.industryType;
	}

	public void setIndustryType(IndustryTypeDTO industryType) {
		this.industryType = industryType;
	}

	public List<CompanyHasAddressDTO> getCompanyHasAddresses() {
		return this.companyHasAddresses;
	}

	public void setCompanyHasAddresses(List<CompanyHasAddressDTO> companyHasAddresses) {
		this.companyHasAddresses = companyHasAddresses;
	}

	public CompanyHasAddressDTO addCompanyHasAddress(CompanyHasAddressDTO companyHasAddress) {
		getCompanyHasAddresses().add(companyHasAddress);
		companyHasAddress.setCompany(this);

		return companyHasAddress;
	}

	public CompanyHasAddressDTO removeCompanyHasAddress(CompanyHasAddressDTO companyHasAddress) {
		getCompanyHasAddresses().remove(companyHasAddress);
		companyHasAddress.setCompany(null);

		return companyHasAddress;
	}

	public List<ProjectDTO> getProjects() {
		return this.projects;
	}

	public void setProjects(List<ProjectDTO> projects) {
		this.projects = projects;
	}

	public ProjectDTO addProject(ProjectDTO project) {
		getProjects().add(project);
		project.setCompany(this);

		return project;
	}

	public ProjectDTO removeProject(ProjectDTO project) {
		getProjects().remove(project);
		project.setCompany(null);

		return project;
	}

	public List<ProviderBusinessProfileDTO> getProviderBusinessProfiles() {
		return this.providerBusinessProfiles;
	}

	public void setProviderBusinessProfiles(List<ProviderBusinessProfileDTO> providerBusinessProfiles) {
		this.providerBusinessProfiles = providerBusinessProfiles;
	}

	/*public ProviderBuisnessProfileDTO addProviderBuisnessProfile(ProviderBuisnessProfileDTO providerBuisnessProfile) {
		getProviderBusinessProfiles().add(providerBuisnessProfile);
		providerBuisnessProfile.setCompany(this);

		return providerBuisnessProfile;
	}

	public ProviderBuisnessProfileDTO removeProviderBuisnessProfile(ProviderBuisnessProfileDTO providerBuisnessProfile) {
		getProviderBusinessProfiles().remove(providerBuisnessProfile);
		providerBuisnessProfile.setCompany(null);

		return providerBuisnessProfile;
	}*/

	public List<UserHasExperienceDTO> getUserHasExperiences() {
		return this.userHasExperiences;
	}

	public void setUserHasExperiences(List<UserHasExperienceDTO> userHasExperiences) {
		this.userHasExperiences = userHasExperiences;
	}

	public UserHasExperienceDTO addUserHasExperience(UserHasExperienceDTO userHasExperience) {
		getUserHasExperiences().add(userHasExperience);
		userHasExperience.setCompany(this);

		return userHasExperience;
	}

	public UserHasExperienceDTO removeUserHasExperience(UserHasExperienceDTO userHasExperience) {
		getUserHasExperiences().remove(userHasExperience);
		userHasExperience.setCompany(null);

		return userHasExperience;
	}

	public List<VirtualAccountDTO> getVirtualAccounts() {
		return this.virtualAccounts;
	}

	public void setVirtualAccounts(List<VirtualAccountDTO> virtualAccounts) {
		this.virtualAccounts = virtualAccounts;
	}

	public VirtualAccountDTO addVirtualAccount(VirtualAccountDTO virtualAccount) {
		getVirtualAccounts().add(virtualAccount);
		virtualAccount.setCompany(this);

		return virtualAccount;
	}

	public VirtualAccountDTO removeVirtualAccount(VirtualAccountDTO virtualAccount) {
		getVirtualAccounts().remove(virtualAccount);
		virtualAccount.setCompany(null);

		return virtualAccount;
	}

	public String getCompanyVerified() {
		return companyVerified;
	}

	public void setCompanyVerified(String companyVerified) {
		this.companyVerified = companyVerified;
	}

	@Override
	public String toString() {
		return "Company [id=" + id + ", alternateEmailId=" + alternateEmailId
				+ ", companyName=" + companyName + ", description="
				+ description + ", emailId=" + emailId + ", companyVerified="
				+ companyVerified + ", clientBuisnessProfiles="
				+ clientBuisnessProfiles + ", industryType=" + industryType
				+ ", companyHasAddresses=" + companyHasAddresses
				+ ", projects=" + projects + ", providerBusinessProfiles="
				+ providerBusinessProfiles + ", userHasExperiences="
				+ userHasExperiences + ", virtualAccounts=" + virtualAccounts
				+ "]";
	}

	public List<UserHasInvitationDTO> getInvitations() {
		return invitations;
	}

	public void setInvitations(List<UserHasInvitationDTO> invitations) {
		this.invitations = invitations;
	}

}