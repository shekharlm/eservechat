/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ag
 */
@Entity
@Table(name="proposal_withdrawn_reason")
public class ProposalWithdrawnReason implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    
   /* @OneToOne
    @JoinColumn(name="proposal_id",referencedColumnName="id")
    private Proposal proposal;*/
   
    @Column(name="withdraw_reason")
    private String withdrawReasons;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="withdrawn_on")
    private Date withdrawnOn;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    /*public Proposal getProposal() {
        return proposal;
    }

    public void setProposal(Proposal proposal) {
        this.proposal = proposal;
    }*/

    public String getWithdrawReasons() {
        return withdrawReasons;
    }

    public void setWithdrawReasons(String withdrawReasons) {
        this.withdrawReasons = withdrawReasons;
    }

    public Date getWithdrawnOn() {
        return withdrawnOn;
    }

    public void setWithdrawnOn(Date withdrawnOn) {
        this.withdrawnOn = withdrawnOn;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProposalWithdrawnReason)) {
            return false;
        }
        ProposalWithdrawnReason other = (ProposalWithdrawnReason) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.eServe.marketPlace.infrastructure.repository.entities.ProposalWithdrawnReason[ id=" + id + " ]";
    }
    
}
