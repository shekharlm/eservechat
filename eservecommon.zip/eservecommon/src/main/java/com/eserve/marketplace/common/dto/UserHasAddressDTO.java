package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_has_address database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserHasAddressDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Address
	private AddressDTO address;

	//bi-directional many-to-one association to AddressType
	private AddressTypeDTO addressType;

	//bi-directional many-to-one association to User
	private UserDTO user;
	
	private Boolean status;

	public UserHasAddressDTO() {
	}

	public UserHasAddressDTO(int id, AddressDTO address, AddressTypeDTO addressType,
			UserDTO user) {
		super();
		this.id = id;
		this.address = address;
		this.addressType = addressType;
		this.user = user;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public AddressDTO getAddress() {
		return this.address;
	}

	public void setAddress(AddressDTO address) {
		this.address = address;
	}

	public AddressTypeDTO getAddressType() {
		return this.addressType;
	}

	public void setAddressType(AddressTypeDTO addressType) {
		this.addressType = addressType;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

}