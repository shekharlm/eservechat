package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_settings_has_choices database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserSettingsHasChoiceDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to SettingHasChoice
	private SettingHasChoiceDTO settingHasChoice;

	//bi-directional many-to-one association to UserHasSetting
//	private UserHasSetting userHasSetting;

	public UserSettingsHasChoiceDTO() {
	}

	public UserSettingsHasChoiceDTO(int id, SettingHasChoiceDTO settingHasChoice,
			UserHasSettingDTO userHasSetting) {
		super();
		this.id = id;
		this.settingHasChoice = settingHasChoice;
//		this.userHasSetting = userHasSetting;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public SettingHasChoiceDTO getSettingHasChoice() {
		return this.settingHasChoice;
	}

	public void setSettingHasChoice(SettingHasChoiceDTO settingHasChoice) {
		this.settingHasChoice = settingHasChoice;
	}

//	public UserHasSetting getUserHasSetting() {
//		return this.userHasSetting;
//	}
//
//	public void setUserHasSetting(UserHasSetting userHasSetting) {
//		this.userHasSetting = userHasSetting;
//	}

}