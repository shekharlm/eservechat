package com.eserve.marketplace.common.util;
import java.security.MessageDigest;
import org.apache.log4j.Logger;
// Encryption Algorithm using MD5
// Through this we have to encrypt the verification link.
public class EncryptionAlgoImpl {
   private static MessageDigest md;
   //configuring log4j.
   private static final Logger logger=Logger.getLogger(EncryptionAlgoImpl.class);
   public static String cryptWithMD5(String pass){
	    logger.info("Invoking cryptWithMD5(String pass) method of EncryptionAlgo class");
	    try{
        md = MessageDigest.getInstance("MD5");
	    }catch(Exception e){
            logger.debug("Algoritm Problem");
        }
        byte[] passBytes = pass.getBytes();
        md.reset();
        byte[] digested = md.digest(passBytes);
        StringBuffer sb = new StringBuffer();
        for(int i=0;i<digested.length;i++){
            sb.append(Integer.toHexString(0xff & digested[i]));
        }
        logger.info("Returning encrypted password value");
        return sb.toString();
    } 
}