package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the job_has_calendar database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class JobHasCalendarDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Calendar
	private CalendarDTO calendar;

	//bi-directional many-to-one association to Job
	private JobDTO job;

	public JobHasCalendarDTO() {
	}

	public JobHasCalendarDTO(int id, CalendarDTO calendar, JobDTO job) {
		super();
		this.id = id;
		this.calendar = calendar;
		this.job = job;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public CalendarDTO getCalendar() {
		return this.calendar;
	}

	public void setCalendar(CalendarDTO calendar) {
		this.calendar = calendar;
	}

	public JobDTO getJob() {
		return this.job;
	}

	public void setJob(JobDTO job) {
		this.job = job;
	}

}