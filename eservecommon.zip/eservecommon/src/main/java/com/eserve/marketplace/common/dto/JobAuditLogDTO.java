package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the job_audit_log database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class JobAuditLogDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to AuditLog
	private AuditLogDTO auditLog;

	//bi-directional many-to-one association to Job
	private JobDTO job;

	public JobAuditLogDTO() {
	}

	public JobAuditLogDTO(int id, AuditLogDTO auditLog, JobDTO job) {
		super();
		this.id = id;
		this.auditLog = auditLog;
		this.job = job;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public AuditLogDTO getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(AuditLogDTO auditLog) {
		this.auditLog = auditLog;
	}

	public JobDTO getJob() {
		return this.job;
	}

	public void setJob(JobDTO job) {
		this.job = job;
	}

}