package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the job_has_proposals database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class JobHasProposalDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Job
	private JobDTO job;

	//bi-directional many-to-one association to Proposal
	private ProposalDTO proposal;

	public JobHasProposalDTO() {
	}

	public JobHasProposalDTO(int id, JobDTO job, ProposalDTO proposal) {
		super();
		this.id = id;
		this.job = job;
		this.proposal = proposal;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public JobDTO getJob() {
		return this.job;
	}

	public void setJob(JobDTO job) {
		this.job = job;
	}

	public ProposalDTO getProposal() {
		return this.proposal;
	}

	public void setProposal(ProposalDTO proposal) {
		this.proposal = proposal;
	}

}