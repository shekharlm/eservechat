package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_has_security_question database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserHasSecurityQuestionDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String securityAnswer;

	//bi-directional many-to-one association to SecurityQuestion
	private SecurityQuestionDTO securityQuestion;

	//bi-directional many-to-one association to User
	private UserDTO user;

	public UserHasSecurityQuestionDTO() {
	}

	public UserHasSecurityQuestionDTO(int id, String securityAnswer,
			SecurityQuestionDTO securityQuestion, UserDTO user) {
		super();
		this.id = id;
		this.securityAnswer = securityAnswer;
		this.securityQuestion = securityQuestion;
		this.user = user;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSecurityAnswer() {
		return this.securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

	public SecurityQuestionDTO getSecurityQuestion() {
		return this.securityQuestion;
	}

	public void setSecurityQuestion(SecurityQuestionDTO securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}