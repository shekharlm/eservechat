package com.eserve.marketplace.common.exception;

@SuppressWarnings("serial")
public class NotFoundException extends Exception{

}
