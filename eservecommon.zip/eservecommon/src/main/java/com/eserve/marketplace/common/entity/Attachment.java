package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the attachment database table.
 * 
 */
@Entity
@Table(name="attachment")
public class Attachment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="attachment_name")
	private String attachmentName;

	@Column(name="attachment_path")
	private String attachmentPath;

	//bi-directional many-to-one association to AttachmentType
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="attachment_type_id", referencedColumnName = "id")
	private AttachmentType attachmentType;

	//bi-directional many-to-one association to ProposalConversationHasAttachment
	/*@OneToMany(mappedBy="attachment")
	private List<ProposalConversationHasAttachment> proposalConversationHasAttachments;*/

	//bi-directional many-to-one association to ProposalHasAttachment
	/*@OneToMany(mappedBy="attachment")
	private List<ProposalHasAttachment> proposalHasAttachments;*/

	//bi-directional many-to-one association to UserHasAttachment
	/*@OneToMany(mappedBy="attachment")
	private List<UserHasAttachment> userHasAttachments;*/

	public Attachment() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAttachmentName() {
		return this.attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public String getAttachmentPath() {
		return this.attachmentPath;
	}

	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}

	public AttachmentType getAttachmentType() {
		return this.attachmentType;
	}

	public void setAttachmentType(AttachmentType attachmentType) {
		this.attachmentType = attachmentType;
	}

	/*public List<ProposalConversationHasAttachment> getProposalConversationHasAttachments() {
		return this.proposalConversationHasAttachments;
	}

	public void setProposalConversationHasAttachments(List<ProposalConversationHasAttachment> proposalConversationHasAttachments) {
		this.proposalConversationHasAttachments = proposalConversationHasAttachments;
	}

	public ProposalConversationHasAttachment addProposalConversationHasAttachment(ProposalConversationHasAttachment proposalConversationHasAttachment) {
		getProposalConversationHasAttachments().add(proposalConversationHasAttachment);
		proposalConversationHasAttachment.setAttachment(this);

		return proposalConversationHasAttachment;
	}

	public ProposalConversationHasAttachment removeProposalConversationHasAttachment(ProposalConversationHasAttachment proposalConversationHasAttachment) {
		getProposalConversationHasAttachments().remove(proposalConversationHasAttachment);
		proposalConversationHasAttachment.setAttachment(null);

		return proposalConversationHasAttachment;
	}*/

	/*public List<ProposalHasAttachment> getProposalHasAttachments() {
		return this.proposalHasAttachments;
	}

	public void setProposalHasAttachments(List<ProposalHasAttachment> proposalHasAttachments) {
		this.proposalHasAttachments = proposalHasAttachments;
	}

	public ProposalHasAttachment addProposalHasAttachment(ProposalHasAttachment proposalHasAttachment) {
		getProposalHasAttachments().add(proposalHasAttachment);
		proposalHasAttachment.setAttachment(this);

		return proposalHasAttachment;
	}

	public ProposalHasAttachment removeProposalHasAttachment(ProposalHasAttachment proposalHasAttachment) {
		getProposalHasAttachments().remove(proposalHasAttachment);
		proposalHasAttachment.setAttachment(null);

		return proposalHasAttachment;
	}*/

	/*public List<UserHasAttachment> getUserHasAttachments() {
		return this.userHasAttachments;
	}

	public void setUserHasAttachments(List<UserHasAttachment> userHasAttachments) {
		this.userHasAttachments = userHasAttachments;
	}

	public UserHasAttachment addUserHasAttachment(UserHasAttachment userHasAttachment) {
		getUserHasAttachments().add(userHasAttachment);
		userHasAttachment.setAttachment(this);

		return userHasAttachment;
	}

	public UserHasAttachment removeUserHasAttachment(UserHasAttachment userHasAttachment) {
		getUserHasAttachments().remove(userHasAttachment);
		userHasAttachment.setAttachment(null);

		return userHasAttachment;
	}*/

}