package com.eserve.marketplace.common.interceptor;

import java.io.Serializable;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import org.apache.log4j.Logger;

@SuppressWarnings("serial")
@Interceptor
@ILog
public class LoggingInterceptorImpl implements Serializable {
private static final Logger logger =Logger.getLogger(LoggingInterceptorImpl.class);
	@AroundInvoke
	public Object logMethodEntry(InvocationContext ctx) throws Exception {
		System.out.println("===============****InterCeptor****============");
		logger.info("Before entering method:" + ctx.getMethod().getName());
		return ctx.proceed();
	}
}