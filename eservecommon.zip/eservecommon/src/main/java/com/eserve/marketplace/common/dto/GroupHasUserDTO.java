package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the group_has_users database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class GroupHasUserDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Group
	private GroupDTO group;

	//bi-directional many-to-one association to User
	private UserDTO user;

	public GroupHasUserDTO() {
	}

	public GroupHasUserDTO(int id, GroupDTO group, UserDTO user) {
		super();
		this.id = id;
		this.group = group;
		this.user = user;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public GroupDTO getGroup() {
		return this.group;
	}

	public void setGroup(GroupDTO group) {
		this.group = group;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}