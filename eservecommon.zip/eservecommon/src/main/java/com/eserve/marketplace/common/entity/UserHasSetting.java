package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the user_has_settings database table.
 * 
 */
@Entity
@Table(name="user_has_settings")
public class UserHasSetting implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	//bi-directional many-to-one association to Setting
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="settings_id")
	private Setting setting;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	private User user;

	//bi-directional many-to-one association to UserSettingsHasChoice
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "user_has_settings_id")
	private List<UserSettingsHasChoice> userSettingsHasChoices;

	public UserHasSetting() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Setting getSetting() {
		return this.setting;
	}

	public void setSetting(Setting setting) {
		this.setting = setting;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<UserSettingsHasChoice> getUserSettingsHasChoices() {
		return this.userSettingsHasChoices;
	}

	public void setUserSettingsHasChoices(List<UserSettingsHasChoice> userSettingsHasChoices) {
		this.userSettingsHasChoices = userSettingsHasChoices;
	}

	/*public UserSettingsHasChoice addUserSettingsHasChoice(UserSettingsHasChoice userSettingsHasChoice) {
		getUserSettingsHasChoices().add(userSettingsHasChoice);
		userSettingsHasChoice.setUserHasSetting(this);

		return userSettingsHasChoice;
	}

	public UserSettingsHasChoice removeUserSettingsHasChoice(UserSettingsHasChoice userSettingsHasChoice) {
		getUserSettingsHasChoices().remove(userSettingsHasChoice);
		userSettingsHasChoice.setUserHasSetting(null);

		return userSettingsHasChoice;
	}*/

}