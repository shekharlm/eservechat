package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the setting_category database table.
 * 
 */
@Entity
@Table(name="setting_category")
public class SettingCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="category_name")
	private String categoryName;

	//bi-directional many-to-one association to SettingGroup
	/*@OneToMany(mappedBy="settingCategory")
	private List<SettingGroup> settingGroups;*/

	public SettingCategory() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategoryName() {
		return this.categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	/*public List<SettingGroup> getSettingGroups() {
		return this.settingGroups;
	}

	public void setSettingGroups(List<SettingGroup> settingGroups) {
		this.settingGroups = settingGroups;
	}

	public SettingGroup addSettingGroup(SettingGroup settingGroup) {
		getSettingGroups().add(settingGroup);
		settingGroup.setSettingCategory(this);

		return settingGroup;
	}

	public SettingGroup removeSettingGroup(SettingGroup settingGroup) {
		getSettingGroups().remove(settingGroup);
		settingGroup.setSettingCategory(null);

		return settingGroup;
	}*/

}