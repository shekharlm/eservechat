/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 *
 * @author ag
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ProposalWithdrawnReasonDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer id;
    
    private ProposalDTO proposal;
   
    private String withdrawReasons;
    
    private Date withdrawnOn;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ProposalDTO getProposal() {
        return proposal;
    }

    public void setProposal(ProposalDTO proposal) {
        this.proposal = proposal;
    }

    public String getWithdrawReasons() {
        return withdrawReasons;
    }

    public void setWithdrawReasons(String withdrawReasons) {
        this.withdrawReasons = withdrawReasons;
    }

    public Date getWithdrawnOn() {
        return withdrawnOn;
    }

    public void setWithdrawnOn(Date withdrawnOn) {
        this.withdrawnOn = withdrawnOn;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProposalWithdrawnReasonDTO)) {
            return false;
        }
        ProposalWithdrawnReasonDTO other = (ProposalWithdrawnReasonDTO) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.eServe.marketPlace.infrastructure.repository.entities.ProposalWithdrawnReason[ id=" + id + " ]";
    }
    
}
