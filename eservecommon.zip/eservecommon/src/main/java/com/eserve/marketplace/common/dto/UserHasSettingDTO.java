package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_has_settings database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserHasSettingDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Setting
	private SettingDTO setting;

	//bi-directional many-to-one association to User
	private UserDTO user;

	//bi-directional many-to-one association to UserSettingsHasChoice
	private List<UserSettingsHasChoiceDTO> userSettingsHasChoices;

	public UserHasSettingDTO() {
	}

	public UserHasSettingDTO(int id, SettingDTO setting, UserDTO user,
			List<UserSettingsHasChoiceDTO> userSettingsHasChoices) {
		super();
		this.id = id;
		this.setting = setting;
		this.user = user;
		this.userSettingsHasChoices = userSettingsHasChoices;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public SettingDTO getSetting() {
		return this.setting;
	}

	public void setSetting(SettingDTO setting) {
		this.setting = setting;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public List<UserSettingsHasChoiceDTO> getUserSettingsHasChoices() {
		return this.userSettingsHasChoices;
	}

	public void setUserSettingsHasChoices(List<UserSettingsHasChoiceDTO> userSettingsHasChoices) {
		this.userSettingsHasChoices = userSettingsHasChoices;
	}

//	public UserSettingsHasChoice addUserSettingsHasChoice(UserSettingsHasChoice userSettingsHasChoice) {
//		getUserSettingsHasChoices().add(userSettingsHasChoice);
//		userSettingsHasChoice.setUserHasSetting(this);
//
//		return userSettingsHasChoice;
//	}
//
//	public UserSettingsHasChoice removeUserSettingsHasChoice(UserSettingsHasChoice userSettingsHasChoice) {
//		getUserSettingsHasChoices().remove(userSettingsHasChoice);
//		userSettingsHasChoice.setUserHasSetting(null);
//
//		return userSettingsHasChoice;
//	}

}