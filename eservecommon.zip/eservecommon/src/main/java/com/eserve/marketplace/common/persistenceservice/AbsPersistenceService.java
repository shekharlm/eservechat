package com.eserve.marketplace.common.persistenceservice;
import java.io.Serializable;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.eserve.marketplace.common.entity.Country;
import com.eserve.marketplace.common.entity.IndustryType;
import com.eserve.marketplace.common.entity.MailTemplate;
import com.eserve.marketplace.common.entity.User;
import com.eserve.marketplace.common.entity.UserHasInvitation;
import com.eserve.marketplace.common.exception.ApplicationException;
import com.eserve.marketplace.common.exception.NotFoundException;
import com.eserve.marketplace.common.exception.PersistenceException;
import com.eserve.marketplace.common.exception.QueryNotFoundException;
import com.eserve.marketplace.common.exception.UserNotFoundException;
import com.eserve.marketplace.common.util.ApplicationConstants;
import com.eserve.marketplace.common.xml.XMLQueryImpl;
import com.eserve.marketplace.common.xml.XMLQueryReaderImpl;

@SuppressWarnings("unchecked")
public abstract class AbsPersistenceService<T extends Serializable> implements IPersistenceService<T> {
	private final Logger log=Logger.getLogger(AbsPersistenceService.class);
//	private final XMLQueryReaderImpl xmlQueryReader=new XMLQueryReaderImpl();
	@PersistenceContext(unitName="ESERVE")
	private EntityManager entityManager;
	// Through this method we can persists any type of object db.
	public void save(T t) throws ApplicationException {
		try{
			entityManager.persist(t);
		}catch(Exception exception){
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_004);
		}
	}
	// we can find user details by input emailId
	public T findUserByEmailId(String emailId) throws UserNotFoundException {
		Query userQuery = null;
		T user=null;
		try {
			userQuery=entityManager.createQuery("select u from User u where u.emailId=:emailId");
		/*	userQuery = getQueryFromXML("USER_BY_EMAIL");
			System.out.println(userQuery);
		} catch (Exception e) {
			log.error(e.toString());
		}	*/		
			userQuery.setParameter("emailId", emailId);
			user=(T) userQuery.getSingleResult();
		}catch(Exception e){
			log.error("User is unique");
			throw new UserNotFoundException();
		}
		return user;
	}
	// getting the countryList
	public List<Country> getCountryList() throws NotFoundException, QueryNotFoundException{
		List<Country> countries = null;
		Query query=null;
		try{
			query = entityManager.createQuery("from Country c");
//		query= getQueryFromXML("COUNTRIES");
		}catch(Exception e){
			throw new QueryNotFoundException("Query is not reading form xml file");
		}
		try{
		countries = query.getResultList();
		return countries;
		}catch(Exception e){
			throw new NotFoundException();
		}
		
	}
	// This is a private method which is used to get a query from xml file.
//	private Query getQueryFromXML(String queryName) throws QueryNotFoundException{
//		XMLQueryImpl query=xmlQueryReader.getXMLQuery(queryName);
//		if(query==null)
//		throw new QueryNotFoundException(queryName);
//		return entityManager.createQuery(query.getQuery_string());
//	}
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	public void update(T t) throws PersistenceException {
		try{
			entityManager.merge(t);
		}catch (Exception exception){
			throw new PersistenceException(ApplicationConstants.DEFAULT_FAILURE_MESSAGE);
		}
	}
	
	@SuppressWarnings("unchecked")
	public T findActiveUserByEmailId(String emailId)throws UserNotFoundException{
		try{
			Query query = entityManager.createQuery("select u from User u where u.accountStatus in('"+ApplicationConstants.ACTIVE_ACCOUNT_STATUS+"', '"+ApplicationConstants.REOPEN+"') and u.emailId =:email");
			query.setParameter("email", emailId);
			return (T)query.getSingleResult();
		}catch(Exception exception){
			throw new UserNotFoundException();
		}
	}
	
	public T findEntityById(Class entityName, int id)throws ApplicationException{
		try{
			return (T) entityManager.find(entityName, id);
			/*Query query = entityManager.createQuery("select e from "+ entityName + " e where e.id = :id");
			query.setParameter("id", id);
			return (T) query.getSingleResult();*/
		}catch(NoResultException noResultException){
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_006);
		}catch (Exception exception) {
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_004);
		}
	}
	
	public List<Integer> verifyUserBasicProfileType(String emailId)throws  ApplicationException {
		List<Integer> userProfileTypes = null;
		try{
			Query query = getEntityManager().createQuery("select up.profileType.id from UserHasProfile up where " +
					"up.profileType.id in ("+ ApplicationConstants.PROVIDER_PROFILE_ID +","+ApplicationConstants.PROVIDER_BUSINESS_ID+","+
					ApplicationConstants.CLIENT_BUSINESS_PROFILE_ID +","+ ApplicationConstants.EMPLOYEE_PROFILE_ID +") and up.user.emailId= :emailId");
			query.setParameter("emailId", emailId);
			userProfileTypes = query.getResultList();
		}catch (Exception exception) {
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_004);
		}
		return userProfileTypes;
	}
	
	
	public List<IndustryType> getIndustryTypes() throws ApplicationException{
		try{
			Query query = entityManager.createQuery("from IndustryType it");
			return query.getResultList();
		}catch(Exception exception){
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_004);
		}
	}
	
	public User findAdminByEmailId(String emailId) throws ApplicationException {
		try{
			Query query = entityManager.createQuery("select up.user from UserHasProfile up where up.profileType.id in ("+ApplicationConstants.PROVIDER_BUSINESS_ID+","+ApplicationConstants.CLIENT_BUSINESS_PROFILE_ID+") and up.user.emailId = :emailId");
			query.setParameter("emailId", emailId);
			return (User) query.getSingleResult();
		}catch(NoResultException noResultException){
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_006);
		}catch(Exception exception){
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_004);
		}
	}
	
	public UserHasInvitation verifyInvitation(String invitationSentTo, String invitationType, String invitationSentBy) throws ApplicationException {
		try{
			Query query = getEntityManager().createQuery("from UserHasInvitation ui where ui.emailSentTo = :invitationSentTo and ui.invitationType = :invitationType and ui.user.emailId = :invitationSentBy");
			query.setParameter("invitationSentTo", invitationSentTo);
			query.setParameter("invitationType", invitationType);
			query.setParameter("invitationSentBy", invitationSentBy);
			return (UserHasInvitation) query.getSingleResult();
		}catch(NoResultException noResultException){
			return null;
		}catch (Exception exception) {
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_004);
		}
	}
}
