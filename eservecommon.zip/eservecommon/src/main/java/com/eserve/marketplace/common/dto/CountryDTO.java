package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the country database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CountryDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String countryName;

	//bi-directional many-to-one association to Address
	private List<AddressDTO> addresses;

	//bi-directional many-to-one association to Job
	private List<JobDTO> jobs;

	private List<UserDTO> users;
	
	public CountryDTO() {
	}

	public CountryDTO(int id, String countryName) {
		super();
		this.id = id;
		this.countryName = countryName;
	
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountryName() {
		return this.countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public List<AddressDTO> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<AddressDTO> addresses) {
		this.addresses = addresses;
	}

	public List<JobDTO> getJobs() {
		return jobs;
	}

	public void setJobs(List<JobDTO> jobs) {
		this.jobs = jobs;
	}

	public List<UserDTO> getUsers() {
		return users;
	}

	public void setUsers(List<UserDTO> users) {
		this.users = users;
	}

}