package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the job_has_skills database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class JobHasSkillDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Job
	private JobDTO job;

	//bi-directional many-to-one association to Skill
	private SkillDTO skill;

	public JobHasSkillDTO() {
	}

	public JobHasSkillDTO(int id, JobDTO job, SkillDTO skill) {
		super();
		this.id = id;
		this.job = job;
		this.skill = skill;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public JobDTO getJob() {
		return this.job;
	}

	public void setJob(JobDTO job) {
		this.job = job;
	}

	public SkillDTO getSkill() {
		return this.skill;
	}

	public void setSkill(SkillDTO skill) {
		this.skill = skill;
	}

}