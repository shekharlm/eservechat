package com.eserve.marketplace.common.persistenceservice;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;

import com.eserve.marketplace.common.entity.IndustryType;
import com.eserve.marketplace.common.entity.MailTemplate;
import com.eserve.marketplace.common.entity.User;
import com.eserve.marketplace.common.entity.UserHasInvitation;
import com.eserve.marketplace.common.exception.ApplicationException;
import com.eserve.marketplace.common.exception.PersistenceException;
import com.eserve.marketplace.common.exception.UserNotFoundException;

public interface IPersistenceService<T extends Serializable> {
	public void save(T t)throws ApplicationException;
	public T findUserByEmailId(String emailId) throws UserNotFoundException;
	public EntityManager getEntityManager();
	public void update(T t)throws PersistenceException;
	public T findActiveUserByEmailId(String emailId)throws UserNotFoundException;
	public T findEntityById(Class entityName, int id)throws ApplicationException;
	public List<Integer> verifyUserBasicProfileType(String emailId)throws  ApplicationException;
	public List<IndustryType> getIndustryTypes()throws ApplicationException;
	public User findAdminByEmailId(String emailId)throws ApplicationException;
	public UserHasInvitation verifyInvitation(String invitationSentTo, String invitationType, String invitationSentBy)throws ApplicationException;
}
