package com.eserve.marketplace.common.mail;



public class MailSender {/*
	public static void sendMails() throws ApplicationException{
		try{
			ClientRequest clientRequest = null;
			clientRequest = new ClientRequest("http://localhost:8080/eServe.marketPlace.infrastructure.scheduler-web/scheduler/mail/sendmail");
			clientRequest.accept(MediaType.APPLICATION_JSON);
			clientRequest.get(Response.class);
		}catch (Exception e){
			throw new ApplicationException(ApplicationConstants.ES_AM_PR_R_015);
		}
	}
*/}
