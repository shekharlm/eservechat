package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_skill_rating database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserSkillRatingDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Rating
	private RatingDTO rating;

	//bi-directional many-to-one association to UserHasSkill
	private UserHasSkillDTO userHasSkill;

	public UserSkillRatingDTO() {
	}

	public UserSkillRatingDTO(int id, RatingDTO rating, UserHasSkillDTO userHasSkill) {
		super();
		this.id = id;
		this.rating = rating;
		this.userHasSkill = userHasSkill;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public RatingDTO getRating() {
		return this.rating;
	}

	public void setRating(RatingDTO rating) {
		this.rating = rating;
	}

	public UserHasSkillDTO getUserHasSkill() {
		return this.userHasSkill;
	}

	public void setUserHasSkill(UserHasSkillDTO userHasSkill) {
		this.userHasSkill = userHasSkill;
	}

}