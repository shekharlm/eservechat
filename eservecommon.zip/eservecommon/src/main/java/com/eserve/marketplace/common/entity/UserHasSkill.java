package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the user_has_skills database table.
 * 
 */
@Entity
@Table(name="user_has_skills")
public class UserHasSkill implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="additional_comments")
	private String additionalComments;

	@Column(name="relevant_exp")
	private int relevantExp;

	//bi-directional many-to-one association to Skill
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "skill_id", referencedColumnName = "id")
	private Skill skill;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;

	//bi-directional many-to-one association to UserSkillRating
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "user_skills_id")
	private List<UserSkillRating> userSkillRatings;

	public UserHasSkill() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdditionalComments() {
		return this.additionalComments;
	}

	public void setAdditionalComments(String additionalComments) {
		this.additionalComments = additionalComments;
	}

	public int getRelevantExp() {
		return this.relevantExp;
	}

	public void setRelevantExp(int relevantExp) {
		this.relevantExp = relevantExp;
	}

	public Skill getSkill() {
		return this.skill;
	}

	public void setSkill(Skill skill) {
		this.skill = skill;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<UserSkillRating> getUserSkillRatings() {
		return this.userSkillRatings;
	}

	public void setUserSkillRatings(List<UserSkillRating> userSkillRatings) {
		this.userSkillRatings = userSkillRatings;
	}

	/*public UserSkillRating addUserSkillRating(UserSkillRating userSkillRating) {
		getUserSkillRatings().add(userSkillRating);
		userSkillRating.setUserHasSkill(this);

		return userSkillRating;
	}

	public UserSkillRating removeUserSkillRating(UserSkillRating userSkillRating) {
		getUserSkillRatings().remove(userSkillRating);
		userSkillRating.setUserHasSkill(null);

		return userSkillRating;
	}*/

}