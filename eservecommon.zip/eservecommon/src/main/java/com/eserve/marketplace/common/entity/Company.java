package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the company database table.
 * 
 */
@Entity
@Table(name="company")
public class Company implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="alternate_email_id")
	private String alternateEmailId;

	@Column(name="company_name")
	private String companyName;

	private String description;

	@Column(name="email_id")
	private String emailId;
	
	@Column(name="company_verified")
	private String companyVerified; 

	//bi-directional many-to-one association to ClientBuisnessProfile
	/*@OneToMany(mappedBy="company")
	private List<ClientBuisnessProfile> clientBuisnessProfiles;*/

	//bi-directional many-to-one association to IndustryType
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="industry_type_id", referencedColumnName = "id")
	private IndustryType industryType;

	//bi-directional many-to-one association to CompanyHasAddress
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "company_id")
	private List<CompanyHasAddress> companyHasAddresses;

	//bi-directional many-to-one association to Project
	/*@OneToMany(mappedBy="company")
	private List<Project> projects;*/

	//bi-directional many-to-one association to ProviderBuisnessProfile
	/*@OneToMany(mappedBy="company")
	private List<ProviderBuisnessProfile> providerBusinessProfiles;*/

	//bi-directional many-to-one association to UserHasExperience
	/*@OneToMany(mappedBy="company")
	private List<UserHasExperience> userHasExperiences;*/

	//bi-directional many-to-one association to VirtualAccount
	/*@OneToMany(mappedBy="company")
	private List<VirtualAccount> virtualAccounts;*/
	
	//bi-directional many-to-one association to VirtualAccount
	/*@OneToMany(mappedBy="company")
	private List<UserHasInvitation> invitations;*/
	
	public Company() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAlternateEmailId() {
		return this.alternateEmailId;
	}

	public void setAlternateEmailId(String alternateEmailId) {
		this.alternateEmailId = alternateEmailId;
	}

	public String getCompanyName() {
		return this.companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/*public List<ClientBuisnessProfile> getClientBuisnessProfiles() {
		return this.clientBuisnessProfiles;
	}

	public void setClientBuisnessProfiles(List<ClientBuisnessProfile> clientBuisnessProfiles) {
		this.clientBuisnessProfiles = clientBuisnessProfiles;
	}

	public ClientBuisnessProfile addClientBuisnessProfile(ClientBuisnessProfile clientBuisnessProfile) {
		getClientBuisnessProfiles().add(clientBuisnessProfile);
		clientBuisnessProfile.setCompany(this);

		return clientBuisnessProfile;
	}

	public ClientBuisnessProfile removeClientBuisnessProfile(ClientBuisnessProfile clientBuisnessProfile) {
		getClientBuisnessProfiles().remove(clientBuisnessProfile);
		clientBuisnessProfile.setCompany(null);

		return clientBuisnessProfile;
	}
*/
	public IndustryType getIndustryType() {
		return this.industryType;
	}

	public void setIndustryType(IndustryType industryType) {
		this.industryType = industryType;
	}

	public List<CompanyHasAddress> getCompanyHasAddresses() {
		return this.companyHasAddresses;
	}

	public void setCompanyHasAddresses(List<CompanyHasAddress> companyHasAddresses) {
		this.companyHasAddresses = companyHasAddresses;
	}

	/*public CompanyHasAddress addCompanyHasAddress(CompanyHasAddress companyHasAddress) {
		getCompanyHasAddresses().add(companyHasAddress);
		companyHasAddress.setCompany(this);

		return companyHasAddress;
	}

	public CompanyHasAddress removeCompanyHasAddress(CompanyHasAddress companyHasAddress) {
		getCompanyHasAddresses().remove(companyHasAddress);
		companyHasAddress.setCompany(null);

		return companyHasAddress;
	}*/

	/*public List<Project> getProjects() {
		return this.projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	public Project addProject(Project project) {
		getProjects().add(project);
		project.setCompany(this);

		return project;
	}

	public Project removeProject(Project project) {
		getProjects().remove(project);
		project.setCompany(null);

		return project;
	}

	public List<ProviderBuisnessProfile> getProviderBusinessProfiles() {
		return this.providerBusinessProfiles;
	}

	public void setProviderBusinessProfiles(List<ProviderBuisnessProfile> providerBusinessProfiles) {
		this.providerBusinessProfiles = providerBusinessProfiles;
	}

	public ProviderBuisnessProfile addProviderBuisnessProfile(ProviderBuisnessProfile providerBuisnessProfile) {
		getProviderBusinessProfiles().add(providerBuisnessProfile);
		providerBuisnessProfile.setCompany(this);

		return providerBuisnessProfile;
	}

	public ProviderBuisnessProfile removeProviderBuisnessProfile(ProviderBuisnessProfile providerBuisnessProfile) {
		getProviderBusinessProfiles().remove(providerBuisnessProfile);
		providerBuisnessProfile.setCompany(null);

		return providerBuisnessProfile;
	}*/

	/*public List<UserHasExperience> getUserHasExperiences() {
		return this.userHasExperiences;
	}

	public void setUserHasExperiences(List<UserHasExperience> userHasExperiences) {
		this.userHasExperiences = userHasExperiences;
	}

	public UserHasExperience addUserHasExperience(UserHasExperience userHasExperience) {
		getUserHasExperiences().add(userHasExperience);
		userHasExperience.setCompany(this);

		return userHasExperience;
	}

	public UserHasExperience removeUserHasExperience(UserHasExperience userHasExperience) {
		getUserHasExperiences().remove(userHasExperience);
		userHasExperience.setCompany(null);

		return userHasExperience;
	}*/

	/*public List<VirtualAccount> getVirtualAccounts() {
		return this.virtualAccounts;
	}

	public void setVirtualAccounts(List<VirtualAccount> virtualAccounts) {
		this.virtualAccounts = virtualAccounts;
	}

	public VirtualAccount addVirtualAccount(VirtualAccount virtualAccount) {
		getVirtualAccounts().add(virtualAccount);
		virtualAccount.setCompany(this);

		return virtualAccount;
	}

	public VirtualAccount removeVirtualAccount(VirtualAccount virtualAccount) {
		getVirtualAccounts().remove(virtualAccount);
		virtualAccount.setCompany(null);

		return virtualAccount;
	}*/

	public String getCompanyVerified() {
		return companyVerified;
	}

	public void setCompanyVerified(String companyVerified) {
		this.companyVerified = companyVerified;
	}

	/*public List<UserHasInvitation> getInvitations() {
		return invitations;
	}

	public void setInvitations(List<UserHasInvitation> invitations) {
		this.invitations = invitations;
	}*/

}