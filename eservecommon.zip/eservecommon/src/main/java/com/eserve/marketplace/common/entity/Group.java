package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the group database table.
 * 
 */
@Entity
@Table(name="groups")
public class Group implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="group_name")
	private String groupName;

	//bi-directional many-to-one association to CalendarHasPermission
	/*@OneToMany(mappedBy="group")
	private List<CalendarHasPermission> calendarHasPermissions;*/

	//bi-directional many-to-one association to GroupHasUser
	/*@OneToMany(mappedBy="group")
	private List<GroupHasUser> groupHasUsers;*/

	public Group() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/*public List<CalendarHasPermission> getCalendarHasPermissions() {
		return this.calendarHasPermissions;
	}

	public void setCalendarHasPermissions(List<CalendarHasPermission> calendarHasPermissions) {
		this.calendarHasPermissions = calendarHasPermissions;
	}

	public CalendarHasPermission addCalendarHasPermission(CalendarHasPermission calendarHasPermission) {
		getCalendarHasPermissions().add(calendarHasPermission);
		calendarHasPermission.setGroup(this);

		return calendarHasPermission;
	}

	public CalendarHasPermission removeCalendarHasPermission(CalendarHasPermission calendarHasPermission) {
		getCalendarHasPermissions().remove(calendarHasPermission);
		calendarHasPermission.setGroup(null);

		return calendarHasPermission;
	}*/

	/*public List<GroupHasUser> getGroupHasUsers() {
		return this.groupHasUsers;
	}

	public void setGroupHasUsers(List<GroupHasUser> groupHasUsers) {
		this.groupHasUsers = groupHasUsers;
	}

	public GroupHasUser addGroupHasUser(GroupHasUser groupHasUser) {
		getGroupHasUsers().add(groupHasUser);
		groupHasUser.setGroup(this);

		return groupHasUser;
	}

	public GroupHasUser removeGroupHasUser(GroupHasUser groupHasUser) {
		getGroupHasUsers().remove(groupHasUser);
		groupHasUser.setGroup(null);

		return groupHasUser;
	}*/

}