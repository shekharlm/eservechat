package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the user_settings_has_choices database table.
 * 
 */
@Entity
@Table(name="user_settings_has_choices")
public class UserSettingsHasChoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	//bi-directional many-to-one association to SettingHasChoice
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="setting_has_choices_id", referencedColumnName = "id")
	private SettingHasChoice settingHasChoice;

	//bi-directional many-to-one association to UserHasSetting
//	@ManyToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name="user_has_settings_id", referencedColumnName = "id")
//	private UserHasSetting userHasSetting;

	public UserSettingsHasChoice() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public SettingHasChoice getSettingHasChoice() {
		return this.settingHasChoice;
	}

	public void setSettingHasChoice(SettingHasChoice settingHasChoice) {
		this.settingHasChoice = settingHasChoice;
	}

	/*public UserHasSetting getUserHasSetting() {
		return this.userHasSetting;
	}

	public void setUserHasSetting(UserHasSetting userHasSetting) {
		this.userHasSetting = userHasSetting;
	}*/

}