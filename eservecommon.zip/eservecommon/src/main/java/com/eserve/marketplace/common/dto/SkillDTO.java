package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import java.util.List;


/**
 * The persistent class for the skill database table.
 * 
 */
public class SkillDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String skill;

	//bi-directional many-to-one association to JobHasSkill
	private List<JobHasSkillDTO> jobHasSkills;

	//bi-directional many-to-one association to SkillType
	private SkillTypeDTO skillType;

	//bi-directional many-to-one association to UserHasSkill
	private List<UserHasSkillDTO> userHasSkills;

	//bi-directional many-to-one association to IndustryHasSkills
	private List<IndustryHasSkillsDTO> industryHasSkills;
	
	public SkillDTO() {
	}

	public SkillDTO(int id, String skill, List<JobHasSkillDTO> jobHasSkills,
			SkillTypeDTO skillType, List<UserHasSkillDTO> userHasSkills,
			List<IndustryHasSkillsDTO> industryHasSkills) {
		super();
		this.id = id;
		this.skill = skill;
		this.jobHasSkills = jobHasSkills;
		this.skillType = skillType;
		this.userHasSkills = userHasSkills;
		this.industryHasSkills = industryHasSkills;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSkill() {
		return this.skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public List<JobHasSkillDTO> getJobHasSkills() {
		return this.jobHasSkills;
	}

	public void setJobHasSkills(List<JobHasSkillDTO> jobHasSkills) {
		this.jobHasSkills = jobHasSkills;
	}

	public JobHasSkillDTO addJobHasSkill(JobHasSkillDTO jobHasSkill) {
		getJobHasSkills().add(jobHasSkill);
		jobHasSkill.setSkill(this);

		return jobHasSkill;
	}

	public JobHasSkillDTO removeJobHasSkill(JobHasSkillDTO jobHasSkill) {
		getJobHasSkills().remove(jobHasSkill);
		jobHasSkill.setSkill(null);

		return jobHasSkill;
	}

	public SkillTypeDTO getSkillType() {
		return this.skillType;
	}

	public void setSkillType(SkillTypeDTO skillType) {
		this.skillType = skillType;
	}

	public List<UserHasSkillDTO> getUserHasSkills() {
		return this.userHasSkills;
	}

	public void setUserHasSkills(List<UserHasSkillDTO> userHasSkills) {
		this.userHasSkills = userHasSkills;
	}

	public UserHasSkillDTO addUserHasSkill(UserHasSkillDTO userHasSkill) {
		getUserHasSkills().add(userHasSkill);
		userHasSkill.setSkill(this);

		return userHasSkill;
	}

	public UserHasSkillDTO removeUserHasSkill(UserHasSkillDTO userHasSkill) {
		getUserHasSkills().remove(userHasSkill);
		userHasSkill.setSkill(null);

		return userHasSkill;
	}

	public List<IndustryHasSkillsDTO> getIndustryHasSkills() {
		return industryHasSkills;
	}

	public void setIndustryHasSkills(List<IndustryHasSkillsDTO> industryHasSkills) {
		this.industryHasSkills = industryHasSkills;
	}

}