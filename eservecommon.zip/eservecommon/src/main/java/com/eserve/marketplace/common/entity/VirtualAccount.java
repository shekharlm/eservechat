package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the virtual_accounts database table.
 * 
 */
@Entity
@Table(name="virtual_accounts")
public class VirtualAccount implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Temporal(TemporalType.DATE)
	@Column(name="account_active_since")
	private Date accountActiveSince;

	@Column(name="account_status")
	private Byte accountStatus;

	@Column(name="import_status")
	private Byte importStatus;

	//bi-directional many-to-one association to ConsultantProfile
	/*@OneToMany(mappedBy="virtualAccount")
	private List<ConsultantProfile> consultantProfiles;*/

	//bi-directional many-to-one association to EmployeeProfile
	/*@OneToMany(mappedBy="virtualAccount")
	private List<EmployeeProfile> employeeProfiles;*/

	//bi-directional many-to-one association to Company
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "company_id", referencedColumnName = "id")
	private Company company;

	//bi-directional many-to-one association to User
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;

	//bi-directional many-to-one association to VirtualAccountsHasInvitation
	/*@OneToMany(mappedBy="virtualAccount")
	private List<VirtualAccountsHasInvitation> virtualAccountsHasInvitations;*/

	public VirtualAccount() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getAccountActiveSince() {
		return this.accountActiveSince;
	}

	public void setAccountActiveSince(Date accountActiveSince) {
		this.accountActiveSince = accountActiveSince;
	}

	public Byte getAccountStatus() {
		return this.accountStatus;
	}

	public void setAccountStatus(Byte accountStatus) {
		this.accountStatus = accountStatus;
	}

	public Byte getImportStatus() {
		return this.importStatus;
	}

	public void setImportStatus(Byte importStatus) {
		this.importStatus = importStatus;
	}

	/*public List<ConsultantProfile> getConsultantProfiles() {
		return this.consultantProfiles;
	}

	public void setConsultantProfiles(List<ConsultantProfile> consultantProfiles) {
		this.consultantProfiles = consultantProfiles;
	}

	public ConsultantProfile addConsultantProfile(ConsultantProfile consultantProfile) {
		getConsultantProfiles().add(consultantProfile);
		consultantProfile.setVirtualAccount(this);

		return consultantProfile;
	}

	public ConsultantProfile removeConsultantProfile(ConsultantProfile consultantProfile) {
		getConsultantProfiles().remove(consultantProfile);
		consultantProfile.setVirtualAccount(null);

		return consultantProfile;
	}*/

	/*public List<EmployeeProfile> getEmployeeProfiles() {
		return this.employeeProfiles;
	}

	public void setEmployeeProfiles(List<EmployeeProfile> employeeProfiles) {
		this.employeeProfiles = employeeProfiles;
	}

	public EmployeeProfile addEmployeeProfile(EmployeeProfile employeeProfile) {
		getEmployeeProfiles().add(employeeProfile);
		employeeProfile.setVirtualAccount(this);

		return employeeProfile;
	}

	public EmployeeProfile removeEmployeeProfile(EmployeeProfile employeeProfile) {
		getEmployeeProfiles().remove(employeeProfile);
		employeeProfile.setVirtualAccount(null);

		return employeeProfile;
	}*/

	public Company getCompany() {
		return this.company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/*public List<VirtualAccountsHasInvitation> getVirtualAccountsHasInvitations() {
		return this.virtualAccountsHasInvitations;
	}

	public void setVirtualAccountsHasInvitations(List<VirtualAccountsHasInvitation> virtualAccountsHasInvitations) {
		this.virtualAccountsHasInvitations = virtualAccountsHasInvitations;
	}

	public VirtualAccountsHasInvitation addVirtualAccountsHasInvitation(VirtualAccountsHasInvitation virtualAccountsHasInvitation) {
		getVirtualAccountsHasInvitations().add(virtualAccountsHasInvitation);
		virtualAccountsHasInvitation.setVirtualAccount(this);

		return virtualAccountsHasInvitation;
	}

	public VirtualAccountsHasInvitation removeVirtualAccountsHasInvitation(VirtualAccountsHasInvitation virtualAccountsHasInvitation) {
		getVirtualAccountsHasInvitations().remove(virtualAccountsHasInvitation);
		virtualAccountsHasInvitation.setVirtualAccount(null);

		return virtualAccountsHasInvitation;
	}*/

}