package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the case_priority database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CasePriorityDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String priority;

	//bi-directional many-to-one association to Case
	private List<CaseDTO> cases;

	public CasePriorityDTO() {
	}

	public CasePriorityDTO(int id, String priority, List<CaseDTO> cases) {
		super();
		this.id = id;
		this.priority = priority;
		this.cases = cases;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPriority() {
		return this.priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public List<CaseDTO> getCases() {
		return this.cases;
	}

	public void setCases(List<CaseDTO> cases) {
		this.cases = cases;
	}

	public CaseDTO addCas(CaseDTO cas) {
		getCases().add(cas);
		cas.setCasePriority(this);

		return cas;
	}

	public CaseDTO removeCas(CaseDTO cas) {
		getCases().remove(cas);
		cas.setCasePriority(null);

		return cas;
	}

	@Override
	public String toString() {
		return "CasePriority [id=" + id + ", priority=" + priority + ", cases="
				+ cases + "]";
	}

}