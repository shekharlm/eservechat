package com.eserve.marketplace.common.util;
import java.util.Calendar;
import java.util.Date;
public class DateUtils {
	public static boolean compareTwoDates(Date expiryDate,Date currentDate){
		boolean datesStatus=false;
		if(currentDate.before(expiryDate)){
			datesStatus=true;
			}
		if(currentDate.after(expiryDate)){
			datesStatus=false;
		}
		if(currentDate.equals(expiryDate)){
			datesStatus=true;
		}
			return datesStatus;
		}
	 public static Date getCurrentDate() {
		 Date currentDate = new Date();
		 return currentDate;
	    }
	 public static Date getCurrentDateWithFiveDaysAdded(){
		 Date expiryDate = new Date();  
		    Calendar cal = Calendar.getInstance();  
		    cal.setTime(expiryDate);  
		    cal.add(Calendar.DATE, 5);
		    expiryDate = cal.getTime();
		    return expiryDate;
	  }
	}
