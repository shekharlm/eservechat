package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown=true)
public class OtherSkillDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String skillName;

	private byte status;

	private UserDTO user;
	
	private UserDTO adminUser;

	public OtherSkillDTO() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSkillName() {
		return this.skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public byte getStatus() {
		return this.status;
	}

	public void setStatus(byte status) {
		this.status = status;
	}

	public UserDTO getUser() {
		return user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public UserDTO getAdminUser() {
		return adminUser;
	}

	public void setAdminUser(UserDTO adminUser) {
		this.adminUser = adminUser;
	}
}