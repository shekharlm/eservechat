package com.eserve.marketplace.common.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the calendar_has_events database table.
 * 
 */
@Entity
@Table(name="calendar_has_events")
public class CalendarHasEvent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="status_type")
	private String statusType;

	//bi-directional many-to-one association to Calendar
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "calendar_id", referencedColumnName = "id")
	private Calendar calendar;

	//bi-directional many-to-one association to Event
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="events_id", referencedColumnName = "id")
	private Event event;

	public CalendarHasEvent() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStatusType() {
		return this.statusType;
	}

	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}

	public Calendar getCalendar() {
		return this.calendar;
	}

	public void setCalendar(Calendar calendar) {
		this.calendar = calendar;
	}

	public Event getEvent() {
		return this.event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}

}