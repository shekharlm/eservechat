package com.eserve.marketplace.common.exception;

@SuppressWarnings("serial")
public class DuplicateRecordException extends Exception {
	public DuplicateRecordException(){}
}
