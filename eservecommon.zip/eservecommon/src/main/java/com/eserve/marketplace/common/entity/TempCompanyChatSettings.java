package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "temp_company_chat_settings")
public class TempCompanyChatSettings implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	private int id;

	@Column(name = "company_id")
	private int companyId;
	@Column(name = "company_time_zone")
	private String timeZone;
	@Column(name = "company_start_working_hours")
	private int companyStartWorkHours;
	@Column(name = "company_end_working_hours")
	private int companyEndWorkHours;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public int getCompanyStartWorkHours() {
		return companyStartWorkHours;
	}

	public void setCompanyStartWorkHours(int companyStartWorkHours) {
		this.companyStartWorkHours = companyStartWorkHours;
	}

	public int getCompanyEndWorkHours() {
		return companyEndWorkHours;
	}

	public void setCompanyEndWorkHours(int companyEndWorkHours) {
		this.companyEndWorkHours = companyEndWorkHours;
	}

}
