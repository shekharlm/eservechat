package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the provider_buisness_profile database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ProviderBusinessProfileDTO  implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id = 0;

	private String keywords = "";

	private float minimumHourlyRate = 0;

	private String overview = "";

	private String paymentTerms = "";

	private String serviceDescription = "";

	private String tagline = "";
	

	//bi-directional many-to-one association to Company
	private CompanyDTO company;

//	bi-directional many-to-one association to User
	private UserDTO user;

	public ProviderBusinessProfileDTO(int id, String keywords,
			float minimumHourlyRate, String overview, String paymentTerms,
			String serviceDescription, String tagline
			,CompanyDTO company,	UserDTO user
			) {
		super();
		this.id = id;
		this.keywords = keywords;
		this.minimumHourlyRate = minimumHourlyRate;
		this.overview = overview;
		this.paymentTerms = paymentTerms;
		this.serviceDescription = serviceDescription;
		this.tagline = tagline;
		this.company = company;
		this.user = user;
	}

	public ProviderBusinessProfileDTO() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getKeywords() {
		return this.keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public float getMinimumHourlyRate() {
		return this.minimumHourlyRate;
	}

	public void setMinimumHourlyRate(float minimumHourlyRate) {
		this.minimumHourlyRate = minimumHourlyRate;
	}

	public String getOverview() {
		return this.overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public String getPaymentTerms() {
		return this.paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getServiceDescription() {
		return this.serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public String getTagline() {
		return this.tagline;
	}

	public void setTagline(String tagline) {
		this.tagline = tagline;
	}

	public CompanyDTO getCompany() {
		return this.company;
	}

	public void setCompany(CompanyDTO company) {
		this.company = company;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}