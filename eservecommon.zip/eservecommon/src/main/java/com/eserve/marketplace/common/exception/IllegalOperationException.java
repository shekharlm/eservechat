package com.eserve.marketplace.common.exception;

@SuppressWarnings("serial")
public class IllegalOperationException extends Exception {
	private StringBuilder messageString;
	public IllegalOperationException(String message) {
		// TODO Auto-generated constructor stub
		messageString=new StringBuilder("Operation Not allowed: "+message);
	}
	public String toString(){
		return messageString.toString();
	}

}
