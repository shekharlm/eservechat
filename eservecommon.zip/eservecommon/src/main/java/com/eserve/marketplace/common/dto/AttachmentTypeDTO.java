package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the attachment_type database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class AttachmentTypeDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private String attachmentType;

	//bi-directional many-to-one association to Attachment
	private List<AttachmentDTO> attachments;

	public AttachmentTypeDTO() {
	}

	public AttachmentTypeDTO(int id, String attachmentType,
			List<AttachmentDTO> attachments) {
		super();
		this.id = id;
		this.attachmentType = attachmentType;
		this.attachments = attachments;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAttachmentType() {
		return this.attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public List<AttachmentDTO> getAttachments() {
		return this.attachments;
	}

	public void setAttachments(List<AttachmentDTO> attachments) {
		this.attachments = attachments;
	}

	public AttachmentDTO addAttachment(AttachmentDTO attachment) {
		getAttachments().add(attachment);
		attachment.setAttachmentType(this);

		return attachment;
	}

	public AttachmentDTO removeAttachment(AttachmentDTO attachment) {
		getAttachments().remove(attachment);
		attachment.setAttachmentType(null);

		return attachment;
	}

	@Override
	public String toString() {
		return "AttachmentType [id=" + id + ", attachmentType="
				+ attachmentType + ", attachments=" + attachments + "]";
	}

}