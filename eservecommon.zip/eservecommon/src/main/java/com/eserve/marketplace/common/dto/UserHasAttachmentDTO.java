package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the user_has_attachments database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserHasAttachmentDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to Attachment
	private AttachmentDTO attachment;

	//bi-directional many-to-one association to User
	private UserDTO user;

	public UserHasAttachmentDTO() {
	}

	public UserHasAttachmentDTO(int id, AttachmentDTO attachment, UserDTO user) {
		super();
		this.id = id;
		this.attachment = attachment;
		this.user = user;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public AttachmentDTO getAttachment() {
		return this.attachment;
	}

	public void setAttachment(AttachmentDTO attachment) {
		this.attachment = attachment;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}