package com.eserve.marketplace.common.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the setting_has_choices database table.
 * 
 */
@Entity
@Table(name="setting_has_choices")
public class SettingHasChoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String choice;

	//bi-directional many-to-one association to Setting
	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="settings_id", referencedColumnName = "id")
	private Setting setting;*/

	//bi-directional many-to-one association to UserSettingsHasChoice
	/*@OneToMany(mappedBy="settingHasChoice")
	private List<UserSettingsHasChoice> userSettingsHasChoices;*/

	@Column(name="is_default")
	private int isDefault;
	
	public SettingHasChoice() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getChoice() {
		return this.choice;
	}

	public void setChoice(String choice) {
		this.choice = choice;
	}

	/*public Setting getSetting() {
		return this.setting;
	}

	public void setSetting(Setting setting) {
		this.setting = setting;
	}*/

	/*public List<UserSettingsHasChoice> getUserSettingsHasChoices() {
		return this.userSettingsHasChoices;
	}

	public void setUserSettingsHasChoices(List<UserSettingsHasChoice> userSettingsHasChoices) {
		this.userSettingsHasChoices = userSettingsHasChoices;
	}

	public UserSettingsHasChoice addUserSettingsHasChoice(UserSettingsHasChoice userSettingsHasChoice) {
		getUserSettingsHasChoices().add(userSettingsHasChoice);
		userSettingsHasChoice.setSettingHasChoice(this);

		return userSettingsHasChoice;
	}

	public UserSettingsHasChoice removeUserSettingsHasChoice(UserSettingsHasChoice userSettingsHasChoice) {
		getUserSettingsHasChoices().remove(userSettingsHasChoice);
		userSettingsHasChoice.setSettingHasChoice(null);

		return userSettingsHasChoice;
	}*/

	public int getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(int isDefault) {
		this.isDefault = isDefault;
	}

}