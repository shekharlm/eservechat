package com.eserve.marketplace.common.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the case database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class CaseDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	private int moduleHasTasksId;

	private String subject;

	//bi-directional many-to-one association to CasePriority
	private CasePriorityDTO casePriority;

	//bi-directional many-to-one association to CaseStatus
	private CaseStatusDTO caseStatus;

	//bi-directional many-to-one association to User
	private UserDTO user;

	//bi-directional many-to-one association to CaseAttachment
	private List<CaseAttachmentDTO> caseAttachments;

	public CaseDTO() {
	}

	public CaseDTO(int id, int moduleHasTasksId, String subject,
			CasePriorityDTO casePriority, CaseStatusDTO caseStatus, UserDTO user,
			List<CaseAttachmentDTO> caseAttachments) {
		super();
		this.id = id;
		this.moduleHasTasksId = moduleHasTasksId;
		this.subject = subject;
		this.casePriority = casePriority;
		this.caseStatus = caseStatus;
		this.user = user;
		this.caseAttachments = caseAttachments;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getModuleHasTasksId() {
		return this.moduleHasTasksId;
	}

	public void setModuleHasTasksId(int moduleHasTasksId) {
		this.moduleHasTasksId = moduleHasTasksId;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public CasePriorityDTO getCasePriority() {
		return this.casePriority;
	}

	public void setCasePriority(CasePriorityDTO casePriority) {
		this.casePriority = casePriority;
	}

	public CaseStatusDTO getCaseStatus() {
		return this.caseStatus;
	}

	public void setCaseStatus(CaseStatusDTO caseStatus) {
		this.caseStatus = caseStatus;
	}

	public UserDTO getUser() {
		return this.user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

	public List<CaseAttachmentDTO> getCaseAttachments() {
		return this.caseAttachments;
	}

	public void setCaseAttachments(List<CaseAttachmentDTO> caseAttachments) {
		this.caseAttachments = caseAttachments;
	}

	public CaseAttachmentDTO addCaseAttachment(CaseAttachmentDTO caseAttachment) {
		getCaseAttachments().add(caseAttachment);
		caseAttachment.setCase(this);

		return caseAttachment;
	}

	public CaseAttachmentDTO removeCaseAttachment(CaseAttachmentDTO caseAttachment) {
		getCaseAttachments().remove(caseAttachment);
		caseAttachment.setCase(null);

		return caseAttachment;
	}

	@Override
	public String toString() {
		return "Case [id=" + id + ", moduleHasTasksId=" + moduleHasTasksId
				+ ", subject=" + subject + ", casePriority=" + casePriority
				+ ", caseStatus=" + caseStatus + ", user=" + user
				+ ", caseAttachments=" + caseAttachments + "]";
	}

}