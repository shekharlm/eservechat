package com.eserve.marketplace.common.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * The persistent class for the project_audit_log database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ProjectAuditLogDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;

	//bi-directional many-to-one association to AuditLog
	private AuditLogDTO auditLog;

	//bi-directional many-to-one association to Project
	private ProjectDTO project;

	public ProjectAuditLogDTO() {
	}

	public ProjectAuditLogDTO(int id, AuditLogDTO auditLog, ProjectDTO project) {
		super();
		this.id = id;
		this.auditLog = auditLog;
		this.project = project;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public AuditLogDTO getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(AuditLogDTO auditLog) {
		this.auditLog = auditLog;
	}

	public ProjectDTO getProject() {
		return this.project;
	}

	public void setProject(ProjectDTO project) {
		this.project = project;
	}

}