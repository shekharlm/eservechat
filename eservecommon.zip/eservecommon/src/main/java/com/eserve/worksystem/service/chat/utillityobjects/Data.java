package com.eserve.worksystem.service.chat.utillityobjects;

import java.io.Serializable;
import java.util.Date;
public final class Data implements Serializable {
private String chatId;
private String messageTxt;
private Author author;
private long timeStamp;
public Data() {
this(new Author(), "");
}

public Data(Author author, String messageTxt) {
this.author = author;
this.messageTxt = messageTxt;
this.timeStamp = new Date().getTime();
}

public String getChatId() {
return chatId;
}

public void setChatId(String chatId) {
this.chatId = chatId;
}

public String getMessageTxt() {
return messageTxt;
}

public Author getAuthor() {
return author;
}

public void setAuthor(Author author) {
this.author = author;
}

public void setMessageTxt(String messageTxt) {
this.messageTxt = messageTxt;
}

public long getTimeStamp() {
return timeStamp;
}

public void setTimeStamp(long timeStamp) {
this.timeStamp = timeStamp;
}

}