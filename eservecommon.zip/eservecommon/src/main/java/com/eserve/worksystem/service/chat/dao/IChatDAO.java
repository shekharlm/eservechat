package com.eserve.worksystem.service.chat.dao;
import com.eserve.marketplace.common.entity.TempCompanyChatSettings;
import com.eserve.marketplace.common.exception.NotFoundException;

public interface IChatDAO {
	public TempCompanyChatSettings getCompanyChatSetting(int iCompanyId) throws NotFoundException;	
}