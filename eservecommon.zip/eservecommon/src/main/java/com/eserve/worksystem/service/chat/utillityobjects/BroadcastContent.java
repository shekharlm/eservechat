package com.eserve.worksystem.service.chat.utillityobjects;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class BroadcastContent<T> {
	private String subscriberId;
	private String version;
	private String groupId;
	private String messageType;
	private T message;
	
	@JsonProperty("agent-sup id")
	private String agentSupId;

	public BroadcastContent() {
		super();
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public T getMessage() {
		return message;
	}

	public void setMessage(T message) {
		this.message = message;
	}

	public String getAgentSupId() {
		return agentSupId;
	}
	
	public void setAgentSupId(String agentSupId) {
		this.agentSupId = agentSupId;
	}
}