package com.security.rest;

import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.eserve.marketplace.common.entity.User;

public interface IAuthentication {
	public Response login(@QueryParam("userName")String userName, @QueryParam("password")String password);
	public Response logout();
	public Response userRegistration(User user);
	public Response checkAuthentication();
	
}
